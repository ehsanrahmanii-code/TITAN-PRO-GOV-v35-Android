#!/usr/bin/env python3
"""Honest accuracy report of the projection and the entry/exit levels on REAL candles (needs internet), walk-forward, no look-ahead.

    python tools/forecast_eval.py                         # watchlist, 1h
    python tools/forecast_eval.py --tf 4h --coins BTCUSDT,ETHUSDT
    python tools/forecast_eval.py --synthetic             # self-test on random walks (no edge exists there by construction)
"""
import argparse
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from app.analysis import fceval  # noqa: E402


def synth(seed: int, n: int = 700):
    r = np.random.default_rng(seed)
    px = 100 * np.exp(np.cumsum(r.normal(0, .01, n)))
    o = np.r_[px[0], px[:-1]]
    return pd.DataFrame({"open_time": pd.date_range("2026-01-01", periods=n, freq="1h"), "open": o, "high": np.maximum(o, px) * 1.003, "low": np.minimum(o, px) * .997, "close": px, "volume": r.uniform(100, 200, n)})


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tf", default="1h")
    ap.add_argument("--coins", default="BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT,DOGEUSDT")
    ap.add_argument("--synthetic", action="store_true")
    a = ap.parse_args()
    coins = [c.strip().upper() for c in a.coins.split(",") if c.strip()]
    from app.data import market
    for i, c in enumerate(coins):
        df = synth(i + 1) if a.synthetic else market.closed_only(market.fetch_klines(c, a.tf, 1000), a.tf)
        r = fceval.evaluate(df, c, a.tf)
        fceval._save(f"{c}:{a.tf}", r)
        if r.get("error"):
            print(c, r["error"]); continue
        d, k, lv = r["direction"], r["cone"], r["levels"]
        print(f"\n{c} {a.tf}  origins={r['origins']}")
        print(f"  جهت کندل: n={d['n_strong']} درستی={d['hit_strong']} z={d['z_vs_coinflip']} {'← لبهٔ آماری' if d['has_edge'] else '← بدون لبهٔ معنادار'}")
        for b in d["reliability"]:
            print(f"    اطمینان {b['edge']}: n={b['n']} ادعا={b['claimed']} واقعی={b['hit']}")
        print(f"  مخروط: پوشش۸۰٪ افق۳={k['cov80_h3']} افق۱۲={k['cov80_h12']} · پوشش۵۰٪={k['cov50_h12']} · خطای میانه={k['median_err_pct_h12']}٪")
        print(f"  سطوح سیگنال:   {lv['signal']}")
        print(f"  ورود بهینه:    {lv['optimised']}  پرنشده={lv['optimised_unfilled']}")


if __name__ == "__main__":
    main()
