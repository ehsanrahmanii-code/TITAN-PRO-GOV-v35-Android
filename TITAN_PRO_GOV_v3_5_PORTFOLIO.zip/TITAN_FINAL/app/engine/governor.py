"""TITAN PRO Clean — Central Governor (PRO V84 logic + V84.3 hardened gates).

Single decision authority:
  upstream modules = evidence only
  Governor = sole publisher of LONG / SHORT / WAIT

Improvements from full TITAN PRO V84 (edge_lab / canonical / evidence fusion):
  - Asymmetric SHORT thresholds (shorts need stronger edge & margin)
  - Higher data_trust & pattern weights (calibrated PRO defaults)
  - Independent support count + contradiction score
  - Min independent confirmations before publish
  - Confidence formula that penalizes contradiction and low support
  - Regime / structure soft conflict awareness
  - x10 quality + timing gates retained and tightened

Fast, pure-python, no heavy runtime layers or DB learning loop.
"""
from __future__ import annotations
from typing import Any

try:
    from app.engine import learn as _learn
except Exception:  # noqa: BLE001
    _learn = None
try:
    from app.analysis import smc as _smc
except Exception:  # noqa: BLE001
    _smc = None
try:
    from app.engine import calibrate as _cal
except Exception:  # noqa: BLE001
    _cal = None
try:
    from app.analysis import orderflow as _of
except Exception:  # noqa: BLE001
    _of = None
try:
    from app.analysis import regime as _reg
except Exception:  # noqa: BLE001
    _reg = None
try:
    from app.analysis import edge as _edge
except Exception:  # noqa: BLE001
    _edge = None

VERSION = "PRO-CLEAN-GOVERNOR-1.8.0-CALIBRATED"

# Calibrated from PRO V84 central_governor + edge_lab defaults
# (htf best; ltf/forecast weaker; data_trust high)
# v3.4-PRO: added smc_confluence, order_flow, regime channels
WEIGHTS = {
    "htf_trend": 1.55,      # 4h + 1d direction
    "mtf_setup": 1.05,      # 1h structure/setup
    "ltf_trigger": 0.55,    # 15m timing
    "momentum": 0.90,       # RSI / ADX / score strength
    "structure": 1.25,      # EMA stack, VWAP, regime
    "volume_flow": 0.70,    # x10 klinger/vortex + x11 rvol + force (raised)
    "derivatives": 0.85,    # funding / OI bias
    "pattern": 0.70,        # raised toward V84 (was 0.55)
    "forecast": 0.45,       # mild
    "context": 0.90,        # F&G, liq, crowd
    "x_layer": 0.75,        # x10 timing + x12 complementary (raised)
    "data_trust": 1.35,     # V84 weight
    "smc_confluence": 1.10, # ICT/SMC: OB/FVG/sweep/CHoCH/BOS — high weight, real edge
    "order_flow": 0.80,     # CVD divergence + volume profile position
    "regime": 0.65,         # statistical regime edge (Hurst/efficiency/fractal)
}

# Asymmetric thresholds (V84 edge_lab / central_governor style)
MIN_EDGE_LONG = 0.15
MIN_EDGE_SHORT = 0.18          # shorts require clearer edge
MIN_MARGIN = 0.30
MIN_MARGIN_SHORT = 0.34        # extra margin for shorts
MIN_TRUST = 52.0
# Opportunity tiers: a trade that fails only SOFT gates is published as a "probe" (half size, clearly labelled) instead of a blank WAIT.
PROBE_ENABLED = True
PROBE_MIN_EDGE_LONG = 0.07
PROBE_MIN_EDGE_SHORT = 0.10
PROBE_MIN_TRUST = 45.0
PROBE_MIN_SUPPORT = 3
PROBE_MAX_CONTRADICTION = 0.45
HARD_VETO_KEYS = ("اعتماد داده", "اندازه‌گیری‌شده منفی", "نقدینگی ضعیف", "تضاد شواهد", "R:R زیر کف", "بافت بازار به‌شدت", "تایم‌فریم بزرگ مخالف",
                  "ساختار/رژیم مخالف", "کیفیت بازار پایین", "اجماع چندتایم‌فریمی")
MIN_SUPPORT = 2                # at least 2 independent evidence families must agree
MAX_CONTRADICTION = 0.62       # above this → force WAIT even if edge is ok
MIN_GRADE_FOR_PUBLISH = {"A", "B"}

# Strong evidence threshold for support/oppose counting
STRONG_EV = 0.18


def _clip(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def _tf_side_score(side: str, score: float) -> float:
    """Map a TF signal to [-1, +1]."""
    s = (score or 0.0) / 100.0
    if side not in ("LONG", "SHORT"):
        return _clip(s * 0.6, -0.12, 0.12)            # below the publish threshold but still a (weak) lean, not a zero
    if side == "LONG":
        return _clip(max(0.05, s) if score > 0 else 0.15)
    return _clip(min(-0.05, -abs(s)) if score < 0 else -0.15)


def _evidence_from_tfs(sigs: dict[str, dict]) -> dict[str, float]:
    """Build HTF / MTF / LTF evidence from multi-TF signals."""
    def one(tf: str) -> float:
        s = sigs.get(tf) or {}
        return _tf_side_score(str(s.get("side") or "WAIT"), float(s.get("score") or 0.0))

    htf = 0.55 * one("1d") + 0.45 * one("4h")
    mtf = one("1h")
    ltf = one("15m")
    # hard HTF veto softener: if both 1d and 4h oppose mtf strongly, crush mtf
    if htf * mtf < 0 and abs(htf) > 0.25:
        mtf *= 0.25
    return {"htf_trend": _clip(htf), "mtf_setup": _clip(mtf), "ltf_trigger": _clip(ltf)}


def _momentum_ev(sigs: dict[str, dict]) -> float:
    vals = []
    for tf, s in sigs.items():
        ind = s.get("indicators") or {}
        rsi = ind.get("rsi")
        adx = ind.get("adx")
        score = float(s.get("score") or 0.0)
        v = score / 80.0
        if rsi is not None:
            if rsi >= 70:
                v -= 0.15
            elif rsi <= 30:
                v += 0.10 if score > 0 else -0.05
        if adx is not None and adx < 15:
            v *= 0.6  # weak trend
        vals.append(_clip(v))
    return sum(vals) / len(vals) if vals else 0.0


def _structure_ev(sigs: dict[str, dict]) -> float:
    """Direction agreement across timeframes: (LONG count − SHORT count) / TF count. (The old formula turned a LONG minority
    into BEARISH evidence.) Trending regimes on ≥2 timeframes amplify it."""
    sides = [str((s or {}).get("side") or "WAIT") for s in sigs.values()]
    n = max(1, len(sides))
    base = (sides.count("LONG") - sides.count("SHORT")) / n
    if base == 0:
        return 0.0
    regimes = [str((s or {}).get("regime") or "") for s in sigs.values()]
    if regimes.count("trend") >= 2:
        base *= 1.15
    return _clip(base)


_DERIV_KEYS = {"funding": 1.0, "ls": 0.6, "oi": 1.0, "basis": 0.4}      # positioning of the futures market
_CTX_KEYS = {"book": 0.7, "sent": 0.5}                                        # order-book pressure + sentiment


def _parts_ev(ctx: dict | None, keys: dict[str, float]) -> float:
    """Weighted sum of the already direction-aware context parts (context.evaluate) over the group's FULL weight, so thin data
    gives a small value and a source is never counted twice (derivatives and context used to share the same numbers)."""
    if not ctx:
        return 0.0
    tot = sum(keys.values())
    acc = sum(float(p.get("v") or 0.0) * keys[p["k"]] for p in (ctx.get("parts") or []) if p.get("k") in keys)
    return _clip(acc / tot) if tot else 0.0


def _deriv_ev(ctx: dict | None) -> float:
    return _parts_ev(ctx, _DERIV_KEYS)


def _context_ev(ctx: dict | None) -> float:
    return _parts_ev(ctx, _CTX_KEYS)


def _forecast_ev(fcs: dict[str, dict], side_hint: str) -> float:
    if not fcs:
        return 0.0
    votes = []
    for tf, f in fcs.items():
        pu = (f or {}).get("prob_up_stat", (f or {}).get("prob_up"))      # untilted + calibrated: the market-view tilt is already counted by the HTF evidence
        if isinstance(pu, (int, float)) and 0.0 <= pu <= 1.0 and (f or {}).get("candles"):
            q = ((f or {}).get("cal") or {}).get("quality")
            rel = 0.6 if q is None else 0.4 + 0.6 * float(q)             # an unreliable projection speaks softly
            votes.append(_clip((float(pu) - 0.5) * 4.0 * rel))
            continue
        d = str((f or {}).get("direction") or "").upper()
        if d in ("UP", "LONG", "BULL", "BULLISH"):
            votes.append(1.0)
        elif d in ("DOWN", "SHORT", "BEAR", "BEARISH"):
            votes.append(-1.0)
        else:
            votes.append(0.0)
    if not votes:
        return 0.0
    return _clip(sum(votes) / len(votes) * 0.8)


def _data_trust(sigs: dict[str, dict], ctx: dict | None) -> float:
    """0..1 trust. Penalize missing TFs / bad liquidity / low coverage."""
    n = len(sigs)
    trust = min(1.0, n / 4.0) * 0.7 + 0.3
    if ctx is not None and ctx.get("liq_ok") is False:
        trust *= 0.75
    if ctx is not None and float(ctx.get("coverage") or 1.0) < 0.3:
        trust *= 0.85
    # extra penalty if primary TF missing
    if "1h" not in sigs and "4h" not in sigs:
        trust *= 0.80
    return max(0.0, min(1.0, trust))


def _primary_sig(sigs: dict[str, dict]) -> dict:
    for tf in ("1h", "4h", "15m", "1d"):
        if tf in sigs and isinstance(sigs[tf], dict):
            return sigs[tf]
    return next(iter(sigs.values()), {}) if sigs else {}


def _x10_quality(sigs: dict[str, dict]) -> float | None:
    s = _primary_sig(sigs)
    x = ((s.get("extras") or {}).get("x10") or {})
    q = x.get("quality")
    try:
        return float(q) if q is not None else None
    except (TypeError, ValueError):
        return None


def _volume_flow_ev(sigs: dict[str, dict]) -> float:
    """From x10 klinger/vortex + x11 rvol — real participation, not zero placeholder."""
    s = _primary_sig(sigs)
    ex = s.get("extras") or {}
    x10 = (ex.get("x10") or {}).get("items") or {}
    x11 = (ex.get("x11") or {}).get("items") or {}
    votes = []
    for k in ("klinger", "vortex"):
        it = x10.get(k) or {}
        if it.get("s") is not None:
            votes.append(float(it["s"]))
    rvol = x11.get("rvol") or {}
    if rvol.get("s") is not None:
        votes.append(float(rvol["s"]) * 0.8)
    # force index from x12
    x12 = (ex.get("x12") or {}).get("items") or {}
    if (x12.get("force") or {}).get("s") is not None:
        votes.append(float(x12["force"]["s"]) * 0.7)
    if not votes:
        return 0.0
    return _clip(sum(votes) / len(votes))


def _pattern_ev(sigs: dict[str, dict]) -> float:
    s = _primary_sig(sigs)
    ps = ((s.get("extras") or {}).get("pat") or {})
    sc = ps.get("score")
    try:
        sc = float(sc)
    except (TypeError, ValueError):
        return 0.0
    return _clip(sc / 100.0)


def _x_layer_ev(sigs: dict[str, dict]) -> float:
    """Blend x10 timing (direction-aware strength) and x12 complementary score."""
    s = _primary_sig(sigs)
    ex = s.get("extras") or {}
    x10 = ex.get("x10") or {}
    x12 = ex.get("x12") or {}
    votes = []
    try:
        timing = float(x10.get("timing") or 0.0)
        votes.append(_clip(timing / 100.0))
    except (TypeError, ValueError):
        pass
    try:
        flow = float(x10.get("flow") or 0.0)
        votes.append(_clip(flow / 100.0) * 0.6)
    except (TypeError, ValueError):
        pass
    try:
        sc12 = float(x12.get("score") or 0.0)
        votes.append(_clip(sc12 / 100.0))
    except (TypeError, ValueError):
        pass
    if not votes:
        return 0.0
    return _clip(sum(votes) / len(votes))


# ── v3.4-PRO: new evidence channels (SMC, order-flow, regime) ──────────────
def _smc_ev(sigs: dict[str, dict], side_hint: str = "") -> float:
    """Smart-money-concepts edge from the primary TF's smc score.
    Uses confluence_for_side when a candidate side is known, else the raw score."""
    s = _primary_sig(sigs)
    smc = (s.get("extras") or {}).get("smc") or {}
    score = smc.get("smc_score")
    try:
        score = float(score) if score is not None else 0.0
    except (TypeError, ValueError):
        score = 0.0
    return _clip(score)


def _order_flow_ev(sigs: dict[str, dict]) -> float:
    """Order-flow edge: CVD divergence + volume-profile position."""
    s = _primary_sig(sigs)
    of = (s.get("extras") or {}).get("order_flow") or {}
    try:
        return _clip(float(of.get("score") or 0.0))
    except (TypeError, ValueError):
        return 0.0


def _regime_ev(sigs: dict[str, dict]) -> float:
    """Statistical regime edge (Hurst/efficiency/fractal)."""
    s = _primary_sig(sigs)
    reg = (s.get("extras") or {}).get("regime") or {}
    try:
        return _clip(float(reg.get("edge") or 0.0))
    except (TypeError, ValueError):
        return 0.0


def _support_and_contradiction(ev: dict[str, float], side: str) -> tuple[int, int, float]:
    """Count independent strong evidence families for/against candidate side.

    Returns (support_count, oppose_count, contradiction_score 0..1).
    """
    if side not in ("LONG", "SHORT"):
        return 0, 0, 0.0
    support = 0
    oppose = 0
    families = (
        "htf_trend", "mtf_setup", "ltf_trigger", "momentum", "structure",
        "volume_flow", "derivatives", "pattern", "context", "x_layer",
    )
    for k in families:
        v = float(ev.get(k, 0.0) or 0.0)
        if abs(v) < STRONG_EV:
            continue
        agrees = (v > 0 and side == "LONG") or (v < 0 and side == "SHORT")
        if agrees:
            support += 1
        else:
            oppose += 1
    total = support + oppose
    contrad = (oppose / total) if total > 0 else 0.0
    return support, oppose, contrad


def govern(
    sigs: dict[str, dict],
    fcs: dict[str, dict] | None = None,
    ctx: dict | None = None,
    grade: dict | None = None,
    symbol: str | None = None,
) -> dict[str, Any]:
    """Central decision.

    Returns published side, edge, margin, trust, components, reasons, vetoes,
    plus support / contradiction diagnostics (V84-style).
    """
    fcs = fcs or {}
    grade = grade or {}
    ev: dict[str, float] = {}
    ev.update(_evidence_from_tfs(sigs))
    ev["momentum"] = _momentum_ev(sigs)
    ev["structure"] = _structure_ev(sigs)
    ev["volume_flow"] = _volume_flow_ev(sigs)
    ev["derivatives"] = _deriv_ev(ctx)
    ev["pattern"] = _pattern_ev(sigs)
    ev["forecast"] = _forecast_ev(fcs, "")
    ev["context"] = _context_ev(ctx)
    ev["x_layer"] = _x_layer_ev(sigs)
    # v3.4-PRO: new professional evidence channels
    ev["smc_confluence"] = _smc_ev(sigs)
    ev["order_flow"] = _order_flow_ev(sigs)
    ev["regime"] = _regime_ev(sigs)
    trust = _data_trust(sigs, ctx)
    # quality from x10: choppy markets reduce trust
    q = _x10_quality(sigs)
    if q is not None:
        trust *= 0.75 + 0.25 * (q / 100.0)
    ev["data_trust"] = (trust - 0.5) * 2.0  # map to [-1,1] contribution channel

    # Weighted edge in [-1, +1] — optional soft tilt from lightweight learning
    weights = dict(WEIGHTS)
    if _learn is not None:
        try:
            weights = _learn.apply_tilts(weights)
        except Exception:  # noqa: BLE001
            pass
    num = 0.0
    den = 0.0
    l_mass = s_mass = 0.0
    for k, w in weights.items():
        if k not in ev or k == "data_trust":          # trust is NOT a direction: as a signed vote it added a constant bullish bias to every coin
            continue
        v = float(ev[k])
        num += w * v
        den += w
        l_mass += w * max(0.0, v)
        s_mass += w * max(0.0, -v)
    edge = (num / den) if den else 0.0
    edge = _clip(edge * (0.7 + 0.3 * trust))          # poor data shrinks the edge instead of voting
    # margin = how one-sided the evidence is (0 = evenly split, 1 = unanimous). The old |long-short| was just |edge| again.
    margin = abs(l_mass - s_mass) / (l_mass + s_mass) if (l_mass + s_mass) > 1e-9 else 0.0

    side = "WAIT"
    reasons: list[str] = []
    vetoes: list[str] = []

    # Publish gates — asymmetric (V84)
    long_ok = edge >= MIN_EDGE_LONG and margin >= MIN_MARGIN and trust * 100 >= MIN_TRUST
    short_ok = edge <= -MIN_EDGE_SHORT and margin >= MIN_MARGIN_SHORT and trust * 100 >= MIN_TRUST

    if long_ok:
        side = "LONG"
        reasons.append(f"لبه صعودی {edge:+.2f} با حاشیه {margin:.2f}")
    elif short_ok:
        side = "SHORT"
        reasons.append(f"لبه نزولی {edge:+.2f} با حاشیه {margin:.2f}")
    else:
        if abs(edge) < (MIN_EDGE_LONG if edge >= 0 else MIN_EDGE_SHORT):
            vetoes.append(f"لبه ناکافی ({edge:+.2f})")
        need_m = MIN_MARGIN if edge >= 0 else MIN_MARGIN_SHORT
        if margin < need_m:
            vetoes.append(f"حاشیه کم ({margin:.2f} < {need_m})")
        if trust * 100 < MIN_TRUST:
            vetoes.append(f"اعتماد داده پایین ({trust*100:.0f})")

    # Independent support + contradiction (from V84 Canonical / Evidence Fusion)
    support, oppose, contrad = _support_and_contradiction(ev, side)
    if side != "WAIT":
        if support < MIN_SUPPORT:
            vetoes.append(f"پشتیبانی مستقل ناکافی ({support} < {MIN_SUPPORT})")
            side = "WAIT"
        elif contrad >= MAX_CONTRADICTION:
            vetoes.append(f"تضاد شواهد بالا ({contrad:.0%})")
            side = "WAIT"
        else:
            if support >= 4:
                reasons.append(f"پشتیبانی قوی ({support} خانواده)")
            elif support >= 3:
                reasons.append(f"پشتیبانی خوب ({support})")

    # The grade/consensus was computed for the multi-timeframe consensus side: a governor edge pointing the OTHER way must not borrow its approval
    gs = str(grade.get("side") or "")
    if side in ("LONG", "SHORT") and gs in ("LONG", "SHORT") and gs != side:
        vetoes.append(f"اجماع چندتایم‌فریمی ({gs}) با لبهٔ حاکم ({side}) هم‌جهت نیست")
        side = "WAIT"

    # Grade gate
    g = str(grade.get("grade") or "")
    if side != "WAIT" and g and g not in MIN_GRADE_FOR_PUBLISH:
        vetoes.append(f"درجه {g} برای انتشار کافی نیست")
        side = "WAIT"

    # Soft RR / friction awareness (validated_decisions spirit, no hard DB)
    # If grade carries an effective R:R and it is weak while edge is only moderate → WAIT
    try:
        rr = float(grade.get("rr") or 0.0)
    except (TypeError, ValueError):
        rr = 0.0
    if side != "WAIT" and rr > 0 and rr < 1.25 and abs(edge) < 0.30:
        vetoes.append(f"R:R ضعیف ({rr:.2f}) با لبه متوسط")
        side = "WAIT"
    if side != "WAIT" and rr > 0 and rr < 1.08:
        vetoes.append(f"R:R زیر کف قابل قبول ({rr:.2f})")
        side = "WAIT"

    # Soft same-side overlap / cooldown (V84 edge_lab spirit via siglog)
    if side != "WAIT" and _learn is not None and symbol:
        try:
            ov = _learn.same_side_overlap(symbol, side)
            if not ov.get("ok", True):
                vetoes.append(str(ov.get("reason") or "همپوشانی همان‌سمت"))
                side = "WAIT"
        except Exception:  # noqa: BLE001
            pass

    # BTC correlation filter (V84 technicals_core — high-vol high-beta alts)
    if side != "WAIT" and _smc is not None and ctx and symbol:
        try:
            bf = _smc.apply_btc_filter(
                symbol,
                side,
                float(ctx.get("atr_pct") or 0.0),
                str(ctx.get("btc_side") or "WAIT"),
                ctx.get("btc_corr") if isinstance(ctx.get("btc_corr"), dict) else None,
            )
            if bf.get("blocked"):
                vetoes.append(str(bf.get("reason") or "فیلتر همبستگی BTC"))
                side = "WAIT"
        except Exception:  # noqa: BLE001
            pass

    # Context hard veto
    if side != "WAIT" and ctx:
        bias = float(ctx.get("bias") or 0.0)
        if side == "LONG" and bias <= -0.55:
            vetoes.append("بافت بازار به‌شدت مخالف LONG")
            side = "WAIT"
        if side == "SHORT" and bias >= 0.55:
            vetoes.append("بافت بازار به‌شدت مخالف SHORT")
            side = "WAIT"
        if ctx.get("liq_ok") is False and abs(edge) < 0.35:
            vetoes.append("نقدینگی ضعیف")
            side = "WAIT"

    # HTF hard oppose
    htf = ev.get("htf_trend", 0.0)
    if side == "LONG" and htf <= -0.30:
        vetoes.append("تایم‌فریم بزرگ مخالف LONG")
        side = "WAIT"
    if side == "SHORT" and htf >= 0.30:
        vetoes.append("تایم‌فریم بزرگ مخالف SHORT")
        side = "WAIT"

    # Structure/regime soft conflict (inspired by V84 soft weights)
    struct = ev.get("structure", 0.0)
    if side == "LONG" and struct <= -0.35 and abs(edge) < 0.32:
        vetoes.append("ساختار/رژیم مخالف LONG")
        side = "WAIT"
    if side == "SHORT" and struct >= 0.35 and abs(edge) < 0.32:
        vetoes.append("ساختار/رژیم مخالف SHORT")
        side = "WAIT"

    # x10 quality gate — do not publish trend trades in pure chop
    if side != "WAIT" and q is not None and q < 28:
        vetoes.append(f"کیفیت بازار پایین (x10={q:.0f}) → سیگنال روندی معتبر نیست")
        side = "WAIT"

    # timing conflict: strong opposite timing from x10 → WAIT on weak edge
    s1 = _primary_sig(sigs)
    try:
        timing = float(((s1.get("extras") or {}).get("x10") or {}).get("timing") or 0.0)
    except (TypeError, ValueError):
        timing = 0.0
    if side == "LONG" and timing <= -40 and abs(edge) < 0.28:
        vetoes.append(f"زمان‌بندی ورود مخالف LONG (timing={timing:.0f})")
        side = "WAIT"
    if side == "SHORT" and timing >= 40 and abs(edge) < 0.28:
        vetoes.append(f"زمان‌بندی ورود مخالف SHORT (timing={timing:.0f})")
        side = "WAIT"

    # Confidence (V84 Canonical style: edge + trust + support − contradiction − quality)
    conf = (
        abs(edge) * 100 * 0.55
        + trust * 22
        + support * 5.5
        - oppose * 3.5
        - contrad * 22
        + abs(ev.get("x_layer", 0)) * 10
    )
    conf = max(0.0, min(95.0, conf))
    if side == "WAIT":
        conf = min(conf, 48.0)
    elif q is not None:
        conf = min(95.0, conf * (0.82 + 0.18 * (q / 100.0)))
    # timing alignment boost
    if side == "LONG" and timing >= 25:
        conf = min(95.0, conf + 4)
        reasons.append(f"زمان‌بندی x10 هم‌جهت ({timing:.0f})")
    elif side == "SHORT" and timing <= -25:
        conf = min(95.0, conf + 4)
        reasons.append(f"زمان‌بندی x10 هم‌جهت ({timing:.0f})")

    # Outcome calibration: measure what this confidence band / side really delivered on the logged signals.
    # Blocks only a clearly negative measured expectancy; with too little data nothing changes.
    cal: dict[str, Any] = {"state": "insufficient"}
    if side != "WAIT" and _cal is not None:
        try:
            cal = _cal.assess(side, conf, rr if rr > 0 else None)
            if cal.get("block"):
                vetoes.append(f"امید ریاضی اندازه‌گیری‌شده منفی است ({cal['ev_r']:+.2f}R، برد واقعی ≈ {cal['p_win']:.0%} روی {cal['n_ref']} نتیجه)")
                side = "WAIT"
                conf = min(conf, 48.0)
            elif cal.get("state") == "calibrated":
                w_cal = min(0.5, cal["n_ref"] / 80.0)               # the more own outcomes, the more the measured rate counts
                conf = max(0.0, min(95.0, (1 - w_cal) * conf + w_cal * cal["p_win"] * 100))
                reasons.append(f"برد واقعی این بازه ≈ {cal['p_win']:.0%} (n={cal['n_ref']}) · امید ریاضی {cal['ev_r']:+.2f}R")
        except Exception:  # noqa: BLE001 - calibration is advisory; it must never break a decision
            cal = {"state": "error"}

    # Tier: "full" = every gate passed; "probe" = only soft gates failed, direction supported by independent families -> half-size opportunity
    tier = "full" if side in ("LONG", "SHORT") else "none"
    if side == "WAIT" and PROBE_ENABLED and not any(k in v for v in vetoes for k in HARD_VETO_KEYS) and trust * 100 >= PROBE_MIN_TRUST \
            and support >= PROBE_MIN_SUPPORT and contrad <= PROBE_MAX_CONTRADICTION \
            and ((edge >= PROBE_MIN_EDGE_LONG) or (edge <= -PROBE_MIN_EDGE_SHORT)):
        side = "LONG" if edge > 0 else "SHORT"
        tier = "probe"
        conf = min(conf, 58.0)
        reasons.insert(0, f"فرصت احتمالی با نیمهٔ ریسک (لبه {edge:+.2f}) — شرط‌های نرم کامل نیست: " + " · ".join(vetoes[:2]))

    # Component breakdown for UI
    components = {k: round(float(ev.get(k, 0.0)), 3) for k in WEIGHTS}
    top = sorted(components.items(), key=lambda x: abs(x[1]), reverse=True)[:4]
    for k, v in top:
        if abs(v) >= 0.12:
            reasons.append(f"{k}: {v:+.2f}")

    return {
        "version": VERSION,
        "side": side,
        "edge": round(edge, 4),
        "margin": round(margin, 4),
        "trust": round(trust * 100, 1),
        "confidence": round(conf, 1),
        "calibration": cal,
        "support": support,
        "oppose": oppose,
        "contradiction": round(contrad, 3),
        "components": components,
        "reasons": reasons[:7],
        "vetoes": vetoes[:7],
        "published": side in ("LONG", "SHORT"),
        "tier": tier,
        "size_mult": 0.5 if tier == "probe" else 1.0,
    }
