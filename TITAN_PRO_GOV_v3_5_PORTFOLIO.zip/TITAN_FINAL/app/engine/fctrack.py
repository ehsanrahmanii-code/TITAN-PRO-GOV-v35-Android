"""Forward verification of the projections (stored ONLY in ZZZ/forecast_track.json).

Every time a new bar closes, the projection made for (symbol, timeframe) is recorded: its 10/25/50/75/90 % band for the
forming candle, +3 and +11 candles ahead. When those candles later close, the REAL close is compared with the band.
The result is an honest live answer to "how often is the real price inside the drawn cone?" and "does the median path point
the right way?" — it is shown next to every projection and never used to hide a bad result.
"""
from __future__ import annotations
import json
import os
import threading
import time

from app.config import DATA_DIR, TF_MS

_FILE = DATA_DIR / "forecast_track.json"
_LOCK = threading.RLock()
_STATE: dict = {"loaded": False, "entries": [], "dirty": False, "saved": 0.0}
MAX_ENTRIES = 1200
DIR_STEPS = 24                           # how many future candles get a stored direction call that is judged later
STEPS = (0, 3, 11)                       # candle indexes (0 = the candle forming when the projection was made)


def _load() -> None:
    if _STATE["loaded"]:
        return
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        _STATE["entries"] = [e for e in (raw.get("entries") if isinstance(raw, dict) else []) if isinstance(e, dict)]
    except Exception:                                                     # noqa: BLE001
        _STATE["entries"] = []
    _STATE["loaded"] = True


def _save(force: bool = False) -> None:
    if not _STATE["dirty"] or (not force and time.time() - _STATE["saved"] < 20):
        return
    tmp = _FILE.with_name(_FILE.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        tmp.write_text(json.dumps({"entries": _STATE["entries"][-MAX_ENTRIES:]}, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _FILE)
        _STATE["dirty"], _STATE["saved"] = False, time.time()
    except OSError:
        pass


def flush() -> None:
    with _LOCK:
        _save(True)


def record(sym: str, tf: str, fc: dict | None, last_open_ms: int | None) -> bool:
    """Store the projection made on the bar whose open time is `last_open_ms` (once per bar)."""
    if not fc or not fc.get("candles") or not last_open_ms or tf not in TF_MS:
        return False
    bands, ref = fc.get("bands") or {}, fc.get("ref_price")
    if not bands.get("p50") or not ref:
        return False
    with _LOCK:
        _load()
        for e in reversed(_STATE["entries"][-400:]):
            if e.get("sym") == sym and e.get("tf") == tf and e.get("t0") == int(last_open_ms):
                return False
        n = len(bands["p50"])
        steps = {}
        for j in STEPS:
            if j < n:
                steps[str(j)] = {k: bands[k][j] for k in ("p10", "p25", "p50", "p75", "p90") if k in bands}
        dirp = [float(x) for x in (fc.get("step_dir") or [])[:DIR_STEPS]]
        _STATE["entries"].append({"sym": sym, "tf": tf, "t0": int(last_open_ms), "ref": float(ref), "made": int(time.time()), "steps": steps, "res": {}, "dirp": dirp, "dres": {}})
        if len(_STATE["entries"]) > MAX_ENTRIES:
            _STATE["entries"] = _STATE["entries"][-MAX_ENTRIES:]
        _STATE["dirty"] = True
        _save()
    return True


def resolve(sym: str, tf: str, df) -> int:
    """Fill in real outcomes from CLOSED candles `df` (columns open_time, close). Returns the number of newly resolved points."""
    if df is None or len(df) == 0 or tf not in TF_MS:
        return 0
    ms = TF_MS[tf]
    try:
        import pandas as pd
        opens = pd.DatetimeIndex(df["open_time"]).as_unit("ns").asi8 // 1_000_000
        close = {int(o): float(c) for o, c in zip(opens[-80:], df["close"].values[-80:])}
    except Exception:                                                     # noqa: BLE001
        return 0
    n = 0
    with _LOCK:
        _load()
        for e in _STATE["entries"][-500:]:
            if e.get("sym") != sym or e.get("tf") != tf:
                continue
            for j, b in (e.get("steps") or {}).items():
                if j in e["res"]:
                    continue
                c = close.get(int(e["t0"]) + (int(j) + 1) * ms)
                if c is None:
                    continue
                ref = float(e["ref"])
                e["res"][j] = {"close": c, "in80": bool(b["p10"] <= c <= b["p90"]), "in50": bool(b["p25"] <= c <= b["p75"]),
                               "dir": bool((b["p50"] > ref) == (c > ref)) if abs(b["p50"] - ref) > 1e-12 else None,
                               "err_pct": round(abs(c - b["p50"]) / ref * 100, 4)}
                n += 1
        for e in _STATE["entries"][-500:]:                               # candle-by-candle direction: predicted vs real
            if e.get("sym") != sym or e.get("tf") != tf or not e.get("dirp"):
                continue
            dres = e.setdefault("dres", {})
            for j, pj in enumerate(e["dirp"]):
                if str(j) in dres:
                    continue
                t = int(e["t0"]) + (j + 1) * ms
                c = close.get(t)
                prev = float(e["ref"]) if j == 0 else close.get(t - ms)
                if c is None or prev is None:
                    continue
                dres[str(j)] = {"t": t, "p": round(pj, 3), "up": bool(c > prev), "ok": bool((c > prev) == (pj > 0.5)), "weak": bool(abs(pj - 0.5) < 0.03)}
                n += 1
        if n:
            _STATE["dirty"] = True
            _save()
    return n


def marks(sym: str, tf: str, limit: int = 80) -> list[dict]:
    """Resolved per-candle direction calls for the chart (one per bar: the most recent projection that covered it)."""
    best: dict[int, dict] = {}
    with _LOCK:
        _load()
        for e in _STATE["entries"]:
            if e.get("sym") != sym or e.get("tf") != tf:
                continue
            for j, r in (e.get("dres") or {}).items():
                t = int(r["t"])
                if t not in best or int(j) < best[t]["j"]:
                    best[t] = {"t": t, "j": int(j), "pred": 1 if r["p"] > 0.5 else -1, "p": r["p"], "ok": r["ok"], "weak": r["weak"]}
    return sorted(best.values(), key=lambda m: m["t"])[-limit:]


def scoreboard(sym: str, tf: str, last_n: int = 14) -> dict:
    """Plain-language track record of the per-candle direction calls for ONE coin/timeframe (what the chart's ✓/✗ arrows add up to)."""
    import math
    ms = marks(sym, tf, 400)
    strong = [m for m in ms if not m["weak"]]
    n = len(strong)
    ok = sum(1 for m in strong if m["ok"])
    streak_kind, streak_len = None, 0
    for m in reversed(strong):
        k = "ok" if m["ok"] else "bad"
        if streak_kind is None:
            streak_kind = k
        if k != streak_kind:
            break
        streak_len += 1
    z = (ok - n / 2.0) / (math.sqrt(n) / 2.0) if n else 0.0
    if n < 20:
        verdict, level = f"نمونهٔ زنده هنوز کم است ({n} از حداقل ۲۰ کندل قضاوت‌شده)", "thin"
    elif z <= -1.3:
        verdict, level = "جهت کندل‌ها در این ارز/تایم‌فریم بدتر از شانس بوده؛ سیستم اطمینان جهت را خودکار کم کرده است", "bad"
    elif z >= 1.3:
        verdict, level = "جهت کندل‌ها در این ارز/تایم‌فریم بهتر از شانس بوده است", "good"
    else:
        verdict, level = "جهت تک‌تک کندل‌ها نزدیک به شانس است؛ به مخروط، احتمال‌ها و سطوح تکیه کنید نه به رنگ یک کندل", "chance"
    return {"n": n, "ok": ok, "bad": n - ok, "hit": round(ok / n, 3) if n else None, "z": round(z, 2), "n_weak": len(ms) - n,
            "streak": {"kind": streak_kind, "len": streak_len}, "last": [{"t": m["t"], "ok": m["ok"], "pred": m["pred"]} for m in strong[-last_n:]],
            "verdict": verdict, "level": level}


def live_adjust(sym: str, tf: str) -> dict:
    """Live track record of THIS coin and timeframe: direction hit rate of the strong calls and coverage of the 10-90 % cone."""
    ms = marks(sym, tf, 400)
    strong = [m for m in ms if not m["weak"]]
    st = stats(tf, sym)
    return {"n_dir": len(strong), "hit": round(sum(m["ok"] for m in strong) / len(strong), 3) if strong else None, "n_cov": st["n"], "cov80": st["cov80"]}


def stats(tf: str | None = None, sym: str | None = None) -> dict:
    """Aggregate real-world hit rates (optionally for one timeframe / symbol)."""
    with _LOCK:
        _load()
        rs = [r for e in _STATE["entries"] if (tf is None or e.get("tf") == tf) and (sym is None or e.get("sym") == sym) for r in (e.get("res") or {}).values()]
        pending = sum(1 for e in _STATE["entries"] if (tf is None or e.get("tf") == tf) and (sym is None or e.get("sym") == sym) and len(e.get("res") or {}) < len(e.get("steps") or {}))
    n = len(rs)
    if not n:
        return {"n": 0, "pending": pending, "cov80": None, "cov50": None, "dir_hit": None, "mae_pct": None}
    dirs = [r["dir"] for r in rs if r.get("dir") is not None]
    return {"n": n, "pending": pending, "cov80": round(sum(r["in80"] for r in rs) / n, 3), "cov50": round(sum(r["in50"] for r in rs) / n, 3),
            "dir_hit": round(sum(dirs) / len(dirs), 3) if dirs else None, "mae_pct": round(sum(r["err_pct"] for r in rs) / n, 3)}


def summary() -> dict:
    return {"all": stats(), "by_tf": {tf: stats(tf) for tf in TF_MS if tf in ("15m", "1h", "4h", "1d")}, "file": _FILE.name}
