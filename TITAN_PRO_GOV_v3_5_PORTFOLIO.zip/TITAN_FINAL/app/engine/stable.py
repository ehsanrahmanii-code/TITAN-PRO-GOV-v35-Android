"""Signal persistence — a published signal must live until the market actually invalidates it.

Problem this solves
-------------------
`governor.govern()` is stateless: every scan re-decides from scratch, so a 1h BUY could turn into WAIT (or SELL) a few
minutes later only because one evidence family wobbled.  This module is the memory around the governor:

* ACTIVATE   a raw LONG/SHORT must be seen continuously for a short confirmation time before it is published
             (kills one-scan blips; time-based, so every caller in the same scan agrees).
* HOLD       once published, the side and its LEVELS (entry / stop / TP1-3) are locked.  A raw WAIT does not cancel it
             until the signal has lived its minimum hold AND the raw view stayed WAIT for a full bar of that timeframe.
* FLIP       an opposite raw signal replaces a live one only if it is a full-tier signal, strong enough, confirmed for a
             while and the minimum hold has passed.  Until then the live signal stays and the pending flip is reported.
* TERMINATE  the live price touching the stop ("stopped") or TP3 ("completed") ends it at once, and the same side cannot
             re-arm before a new closed bar.
* SANITY     levels that are mis-ordered for their side (stop on the wrong side, targets inverted, absurd risk) are never
             locked and never published.

State lives only in `<DATA_DIR>/signal_state.json` (atomic write, throttled).
"""
from __future__ import annotations
import json
import os
import threading
import time

from app.config import DATA_DIR, TF_MS, SIGNAL_VALID_BARS

_FILE = DATA_DIR / "signal_state.json"
_LOCK = threading.RLock()
_ST: dict = {"loaded": False, "sig": {}, "cand": {}, "dirty": False, "saved": 0.0}

MIN_HOLD_BARS = {"15m": 2.0, "1h": 2.0, "4h": 1.5, "1d": 1.0}     # a published signal lives at least this many bars of its own timeframe
WAIT_CONFIRM_BARS = 1.0                                           # raw WAIT must last this many bars before a live signal is dropped
FLIP_CONFIRM_BARS = 0.5                                           # opposite raw signal must persist this long to replace a live one
FLIP_MIN_CONF = 58.0                                              # … and be at least this confident
ACTIVATE_MIN_SEC, ACTIVATE_MAX_SEC, ACTIVATE_FRAC = 90.0, 300.0, 0.08
GAP_RESET_SEC = 240.0                                             # candidate not seen for this long → confirmation restarts
HISTORY_MAX = 200
ENABLED = True                                                    # tests / emergency switch: False → the raw governor verdict is returned untouched
IMMEDIATE_CONF = 68.0                                             # a full-tier signal at least this confident is published at once (no confirmation delay)


def _bar_s(tf: str) -> float:
    return TF_MS.get(tf, 3_600_000) / 1000.0


def _load() -> None:
    if _ST["loaded"]:
        return
    try:
        raw = json.loads(_FILE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            _ST["sig"] = {k: v for k, v in (raw.get("sig") or {}).items() if isinstance(v, dict)}
            _ST["hist"] = [h for h in (raw.get("hist") or []) if isinstance(h, dict)][-HISTORY_MAX:]
    except Exception:                                                  # noqa: BLE001
        _ST["sig"] = {}
    _ST.setdefault("hist", [])
    _ST["loaded"] = True


def _save(force: bool = False) -> None:
    if not _ST["dirty"] or (not force and time.time() - _ST["saved"] < 15):
        return
    tmp = _FILE.with_name(_FILE.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        tmp.write_text(json.dumps({"sig": _ST["sig"], "hist": _ST.get("hist", [])[-HISTORY_MAX:]}, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _FILE)
        _ST["dirty"], _ST["saved"] = False, time.time()
    except OSError:
        pass


def flush() -> None:
    with _LOCK:
        _save(True)


def reset() -> None:
    """Forget every live signal (tests / explicit user action)."""
    with _LOCK:
        _ST.update(loaded=True, sig={}, cand={}, hist=[], dirty=True)
        _save(True)


# ── level sanity ────────────────────────────────────────────────────────────
def levels_sane(side: str, entry, stop, tps, price=None, atr=None) -> tuple[bool, list[str]]:
    """Check that entry / stop / targets are consistent for `side`.  Returns (ok, problems-in-Persian)."""
    probs: list[str] = []
    try:
        e, s = float(entry), float(stop)
        t = [float(x) for x in tps]
    except (TypeError, ValueError):
        return False, ["سطوح معامله ناقص یا نامعتبر است"]
    if min([e, s] + t) <= 0 or len(t) < 1:
        return False, ["سطوح معامله ناقص یا نامعتبر است"]
    if side == "LONG":
        if not s < e:
            probs.append("حدضرر خرید باید پایین‌تر از ورود باشد")
        if not all(x > e for x in t) or any(b <= a for a, b in zip(t, t[1:])):
            probs.append("اهداف خرید باید بالاتر از ورود و صعودی باشند")
    elif side == "SHORT":
        if not s > e:
            probs.append("حدضرر فروش باید بالاتر از ورود باشد")
        if not all(x < e for x in t) or any(b >= a for a, b in zip(t, t[1:])):
            probs.append("اهداف فروش باید پایین‌تر از ورود و نزولی باشند")
    else:
        return False, ["جهت نامعتبر"]
    risk = abs(e - s)
    if atr and float(atr) > 0 and not probs:
        r_atr = risk / float(atr)
        if r_atr < 0.25:
            probs.append(f"حدضرر بیش از حد نزدیک است ({r_atr:.2f} ATR)")
        elif r_atr > 7.0:
            probs.append(f"حدضرر بیش از حد دور است ({r_atr:.1f} ATR)")
        if price and abs(e - float(price)) / float(atr) > 4.0:
            probs.append("نقطهٔ ورود بیش از ۴ ATR از قیمت زنده فاصله دارد")
    if not probs and risk > 0 and abs(t[0] - e) < 0.3 * risk:
        probs.append("هدف اول نسبت به ریسک بسیار نزدیک است")
    return (not probs), probs


def _plan_of(plan: dict | None) -> dict | None:
    if not plan:
        return None
    try:
        out = {k: float(plan[k]) for k in ("entry", "stop", "tp1", "tp2", "tp3")}
    except (KeyError, TypeError, ValueError):
        return None
    if plan.get("risk_reward") is not None or plan.get("rr") is not None:
        out["rr"] = plan.get("risk_reward", plan.get("rr"))
    return out


def _hit(side: str, plan: dict | None, price: float | None) -> str | None:
    if not plan or not price:
        return None
    if side == "LONG":
        return "stopped" if price <= plan["stop"] else "completed" if price >= plan["tp3"] else None
    return "stopped" if price >= plan["stop"] else "completed" if price <= plan["tp3"] else None


def _view(st: dict | None, now: float, **extra) -> dict:
    base = {"held": False, "state": "none", "since": None, "valid_until": None, "plan": None, "pending": None, "reason": "", "tier": "none"}
    if st:
        base.update(since=st.get("since"), valid_until=st.get("valid_until"), plan=st.get("plan"), tier=st.get("tier", "full"),
                    age_s=int(now - st.get("since", now)), conf=st.get("conf"))
    base.update(extra)
    return base


def current(sym: str, tf: str) -> dict | None:
    with _LOCK:
        _load()
        st = _ST["sig"].get(f"{sym}|{tf}")
        return dict(st) if st and st.get("active") else None


def history(limit: int = 60) -> list[dict]:
    with _LOCK:
        _load()
        return list(_ST.get("hist", []))[-limit:]


def _close(key: str, st: dict, why: str, now: float, price: float | None) -> None:
    st["active"] = False
    st["closed"] = {"t": now, "why": why, "price": price}
    h = _ST.setdefault("hist", [])
    h.append({"key": key, "side": st["side"], "since": st["since"], "closed": now, "why": why, "plan": st.get("plan"), "price": price, "conf": st.get("conf")})
    del h[:-HISTORY_MAX]


def resolve(sym: str, tf: str, raw_side: str, conf: float = 0.0, tier: str = "full", plan: dict | None = None, price: float | None = None,
            atr: float | None = None, last_open: int | None = None, now: float | None = None) -> dict:
    """Turn the governor's instantaneous verdict into a persistent one.

    Returns {side, held, state, since, valid_until, plan, pending, reason, tier}. `side` is what must be published; `plan` the locked levels.
    `state` ∈ new | confirming | active | holding | flip_pending | flipped | stopped | completed | none.
    """
    now = float(now or time.time())
    key = f"{sym}|{tf}"
    bar = _bar_s(tf)
    raw_side = raw_side if raw_side in ("LONG", "SHORT") else "WAIT"
    lp = _plan_of(plan)
    if not ENABLED:
        return _view(None, now, side=raw_side, state="off")
    with _LOCK:
        _load()
        st = _ST["sig"].get(key)
        cand = _ST["cand"].get(key)
        # 1) a live signal ends the moment the market proves it right/wrong
        if st and st.get("active"):
            hit = _hit(st["side"], st.get("plan"), price)
            if hit:
                _close(key, st, hit, now, price)
                _ST["dirty"] = True
                _save()
                cand = None
                _ST["cand"].pop(key, None)
                st = _ST["sig"][key]
                if raw_side == st["side"] and last_open is not None and st.get("anchor") is not None and int(last_open) <= int(st["anchor"]):
                    return _view(None, now, side="WAIT", state=hit, reason=("حدضرر لمس شد" if hit == "stopped" else "هدف سوم رسید") + " — منتظر کندل بستهٔ جدید برای سیگنال تازه")
                if raw_side == "WAIT" or raw_side == st["side"]:
                    return _view(None, now, side="WAIT", state=hit, reason="حدضرر لمس شد" if hit == "stopped" else "هدف سوم رسید")
        # 2) a closed signal's side cannot re-arm inside the same closed bar
        if st and not st.get("active") and raw_side == st.get("side") and (st.get("closed") or {}).get("why") in ("stopped", "completed") \
                and last_open is not None and st.get("anchor") is not None and int(last_open) <= int(st["anchor"]):
            return _view(None, now, side="WAIT", state=(st["closed"]["why"]), reason="این سیگنال در همین کندل پایان یافته؛ منتظر کندل بستهٔ جدید")

        active = bool(st and st.get("active"))
        # 3) live signal + current raw verdict
        if active:
            held_s = st["side"]
            if raw_side == held_s:                                    # confirmed again → refresh, keep locked levels
                st["wait_since"] = st["opp_since"] = None
                st["conf"] = round(0.7 * float(st.get("conf") or conf) + 0.3 * conf, 1) if conf else st.get("conf")
                if lp and not st.get("plan"):
                    ok, _ = levels_sane(held_s, lp["entry"], lp["stop"], (lp["tp1"], lp["tp2"], lp["tp3"]), price, atr)
                    if ok:
                        st["plan"] = lp
                horizon = (int(last_open) / 1000.0 + bar * (1 + SIGNAL_VALID_BARS.get(tf, 4))) if last_open else now + bar * SIGNAL_VALID_BARS.get(tf, 4)
                st["valid_until"] = max(float(st.get("valid_until") or 0), horizon)
                st["seen"] = now
                _ST["dirty"] = True
                _save()
                return _view(st, now, side=held_s, state="active", held=False, reason="سیگنال تأیید و فعال است")
            min_hold = MIN_HOLD_BARS.get(tf, 2.0) * bar
            lived = now - float(st["since"])
            if raw_side == "WAIT" or tier == "probe":                 # nothing decisive → keep, drop only after a full WAIT bar
                st["opp_since"] = None
                if st.get("wait_since") is None:
                    st["wait_since"] = now
                waited = now - float(st["wait_since"])
                if lived >= min_hold and waited >= WAIT_CONFIRM_BARS * bar and now >= float(st.get("valid_until") or 0):
                    _close(key, st, "faded", now, price)
                    _ST["dirty"] = True
                    _save()
                    return _view(None, now, side="WAIT", state="none", reason="تحلیل برای یک کندل کامل تأیید نشد و اعتبار سیگنال تمام شد")
                _ST["dirty"] = True
                _save()
                left = max(0.0, max(min_hold - lived, WAIT_CONFIRM_BARS * bar - waited))
                return _view(st, now, side=held_s, state="holding", held=True,
                             reason=f"سیگنال حفظ شده است؛ تحلیل لحظه‌ای فعلاً تأیید نمی‌کند (حداقل {int(left // 60)} دقیقهٔ دیگر برای بازبینی)")
            # opposite full-tier signal
            if st.get("opp_since") is None or st.get("opp_side") != raw_side:
                st["opp_since"], st["opp_side"] = now, raw_side
            opp_for = now - float(st["opp_since"])
            if lived >= min_hold and opp_for >= FLIP_CONFIRM_BARS * bar and conf >= FLIP_MIN_CONF and lp:
                ok, probs = levels_sane(raw_side, lp["entry"], lp["stop"], (lp["tp1"], lp["tp2"], lp["tp3"]), price, atr)
                if ok:
                    _close(key, st, "flipped", now, price)
                    return _activate(key, raw_side, conf, tier, lp, last_open, now, tf, bar, state="flipped", reason="جهت سیگنال برگشت و تأیید شد")
            pend = {"side": raw_side, "for_s": int(opp_for), "need_s": int(FLIP_CONFIRM_BARS * bar), "conf": round(conf, 1),
                    "min_conf": FLIP_MIN_CONF, "min_hold_left_s": int(max(0.0, min_hold - lived))}
            _ST["dirty"] = True
            _save()
            return _view(st, now, side=held_s, state="flip_pending", held=True, pending=pend,
                         reason=f"سیگنال مخالف ({raw_side}) در حال تأیید است ولی هنوز کافی نیست؛ سیگنال فعلی حفظ می‌شود")
        # 4) no live signal: confirm a candidate
        if raw_side == "WAIT":
            _ST["cand"].pop(key, None)
            return _view(None, now, side="WAIT", state="none")
        if lp:
            ok, probs = levels_sane(raw_side, lp["entry"], lp["stop"], (lp["tp1"], lp["tp2"], lp["tp3"]), price, atr)
            if not ok:
                _ST["cand"].pop(key, None)
                return _view(None, now, side="WAIT", state="none", reason="سطوح معامله نامعتبر: " + "؛ ".join(probs[:2]))
        if not cand or cand.get("side") != raw_side or now - float(cand.get("last", 0)) > GAP_RESET_SEC:
            cand = {"side": raw_side, "since": now, "last": now}
        cand["last"] = now
        _ST["cand"][key] = cand
        need = min(ACTIVATE_MAX_SEC, max(ACTIVATE_MIN_SEC, ACTIVATE_FRAC * bar))
        if tier == "full" and conf >= IMMEDIATE_CONF:                 # strong, fully-gated signal: no waiting, the opportunity is not lost
            need = 0.0
        seen_for = now - float(cand["since"])
        if seen_for < need:
            return _view(None, now, side="WAIT", state="confirming",
                         pending={"side": raw_side, "for_s": int(seen_for), "need_s": int(need)}, reason=f"سیگنال {raw_side} در حال تأیید ({int(need - seen_for)} ثانیهٔ دیگر)")
        _ST["cand"].pop(key, None)
        return _activate(key, raw_side, conf, tier, lp, last_open, now, tf, bar, state="new", reason="سیگنال جدید تأیید و ثبت شد")


def _activate(key: str, side: str, conf: float, tier: str, lp: dict | None, last_open: int | None, now: float, tf: str, bar: float, *, state: str, reason: str) -> dict:
    valid = (int(last_open) / 1000.0 + bar * (1 + SIGNAL_VALID_BARS.get(tf, 4))) if last_open else now + bar * SIGNAL_VALID_BARS.get(tf, 4)
    st = {"active": True, "side": side, "since": now, "seen": now, "conf": round(conf, 1), "tier": tier if tier in ("full", "probe") else "full", "plan": lp,
          "anchor": int(last_open) if last_open else None, "valid_until": max(valid, now + MIN_HOLD_BARS.get(tf, 2.0) * bar), "wait_since": None, "opp_since": None}
    _ST["sig"][key] = st
    _ST["dirty"] = True
    _save()
    return _view(st, now, side=side, state=state, held=False, reason=reason)


def summary() -> dict:
    with _LOCK:
        _load()
        act = {k: {"side": v["side"], "since": v["since"], "valid_until": v.get("valid_until"), "conf": v.get("conf")} for k, v in _ST["sig"].items() if v.get("active")}
        return {"active": act, "n_active": len(act), "history": list(_ST.get("hist", []))[-20:], "file": _FILE.name}
