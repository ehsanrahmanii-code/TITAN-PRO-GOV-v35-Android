"""Portfolio-level risk analytics (pure functions, no I/O, no network).

• underwater()      – equity -> drawdown curve (depth, duration under water, recovery needed)
• corr_matrix()     – return correlation of the coins held, clusters of coins that move together, effective number of independent bets
• cluster_heat()    – open risk grouped by correlated cluster and direction (what a desk calls "concentration")
• weekly_report()   – this week vs the previous one, by coin / side / grade / regime / hour, and which slices to switch off (statistically, not by feel)
"""
from __future__ import annotations
import math
import time
from typing import Any

import numpy as np


# ── drawdown ────────────────────────────────────────────────────────────────
def underwater(points: list[dict], key: str = "eq") -> dict[str, Any]:
    """points: [{t, eq}] oldest first. Returns the drawdown curve and its summary."""
    pts = [(float(p.get("t") or 0.0), float(p[key])) for p in (points or []) if isinstance(p, dict) and p.get(key) is not None and float(p[key]) > 0]
    if len(pts) < 2:
        return {"n": len(pts), "curve": [], "max_dd_pct": 0.0, "cur_dd_pct": 0.0, "peak": pts[0][1] if pts else 0.0, "under_water_h": 0.0, "recovery_needed_pct": 0.0}
    peak, peak_t, curve, mdd, mdd_t = pts[0][1], pts[0][0], [], 0.0, pts[0][0]
    for t, e in pts:
        if e >= peak:
            peak, peak_t = e, t
        dd = (peak - e) / peak * 100.0
        if dd > mdd:
            mdd, mdd_t = dd, t
        curve.append({"t": t, "eq": round(e, 2), "dd": round(dd, 3)})
    cur = curve[-1]["dd"]
    step = max(1, len(curve) // 160)                                  # the UI never needs more than ~160 points
    thin = curve[::step]
    if thin[-1] is not curve[-1]:
        thin.append(curve[-1])
    return {"n": len(curve), "curve": thin, "max_dd_pct": round(mdd, 2), "max_dd_t": mdd_t, "cur_dd_pct": round(cur, 2), "peak": round(peak, 2),
            "under_water_h": round(max(0.0, (pts[-1][0] - peak_t)) / 3600.0, 1) if cur > 0 else 0.0,
            "recovery_needed_pct": round((1.0 / (1.0 - cur / 100.0) - 1.0) * 100.0, 2) if cur < 100 else 0.0}


# ── correlation ─────────────────────────────────────────────────────────────
def _log_returns(closes: np.ndarray) -> np.ndarray:
    c = np.asarray(closes, dtype=float)
    c = c[np.isfinite(c) & (c > 0)]
    return np.diff(np.log(c)) if len(c) > 2 else np.array([])


def corr_matrix(closes: dict[str, Any], min_obs: int = 30, threshold: float = 0.7) -> dict[str, Any]:
    """closes: {symbol: close series}. Series are aligned on their LAST n observations (same timeframe assumed).
    Ledoit-Wolf-style shrinkage toward the average correlation keeps a short sample from producing spurious 0.99 / -0.9 values."""
    rets = {s: _log_returns(c) for s, c in (closes or {}).items()}
    rets = {s: r for s, r in rets.items() if len(r) >= min_obs}
    syms = sorted(rets)
    if len(syms) < 2:
        return {"symbols": syms, "matrix": [[1.0] * len(syms) for _ in syms], "clusters": [[s] for s in syms], "eff_bets": float(len(syms)), "avg_corr": 0.0, "n_obs": 0}
    n = min(len(r) for r in rets.values())
    X = np.vstack([rets[s][-n:] for s in syms])
    sd = X.std(axis=1)
    keep = sd > 1e-12                                                  # a flat series has no correlation
    syms = [s for s, k in zip(syms, keep) if k]
    X = X[keep]
    if len(syms) < 2:
        return {"symbols": syms, "matrix": [[1.0] * len(syms) for _ in syms], "clusters": [[s] for s in syms], "eff_bets": float(len(syms)), "avg_corr": 0.0, "n_obs": int(n)}
    C = np.corrcoef(X)
    k = len(syms)
    off = C[~np.eye(k, dtype=bool)]
    avg = float(off.mean())
    lam = float(min(0.5, max(0.05, k / (k + n / 2.0))))               # more coins / fewer observations -> shrink harder
    S = (1 - lam) * C + lam * (avg * np.ones((k, k)) + (1 - avg) * np.eye(k))
    np.fill_diagonal(S, 1.0)
    S = np.clip(S, -1.0, 1.0)
    # clusters: connected components of the |corr| > threshold graph
    parent = list(range(k))

    def find(a: int) -> int:
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    for i in range(k):
        for j in range(i + 1, k):
            if S[i, j] > threshold:
                parent[find(i)] = find(j)
    groups: dict[int, list[str]] = {}
    for i, s in enumerate(syms):
        groups.setdefault(find(i), []).append(s)
    ev = np.clip(np.linalg.eigvalsh(S), 1e-9, None)
    eff = float(ev.sum() ** 2 / (ev ** 2).sum())                      # participation ratio: 1 = everything is one bet, k = fully independent
    return {"symbols": syms, "matrix": [[round(float(v), 3) for v in row] for row in S], "clusters": sorted(groups.values(), key=lambda g: -len(g)),
            "eff_bets": round(eff, 2), "avg_corr": round(avg, 3), "n_obs": int(n), "shrink": round(lam, 2)}


def cluster_heat(positions: list[dict], clusters: list[list[str]], equity: float) -> list[dict]:
    """Open risk (% of equity, same-direction sums) per correlated cluster. positions: [{symbol, side, risk_usd}]."""
    where = {s: i for i, g in enumerate(clusters) for s in g}
    acc: dict[tuple, dict] = {}
    for p in positions or []:
        sym, side = p.get("symbol"), str(p.get("side") or "").upper()
        if sym not in where or side not in ("LONG", "SHORT"):
            continue
        key = (where[sym], side)
        e = acc.setdefault(key, {"coins": [], "side": side, "risk_usd": 0.0})
        e["coins"].append(sym)
        e["risk_usd"] += float(p.get("risk_usd") or 0.0)
    out = [{"coins": e["coins"], "side": e["side"], "risk_pct": round(e["risk_usd"] / equity * 100.0, 2) if equity > 0 else 0.0} for e in acc.values()]
    return sorted(out, key=lambda z: -z["risk_pct"])


# ── weekly report ───────────────────────────────────────────────────────────
def _agg(rows: list[dict]) -> dict:
    n = len(rows)
    if not n:
        return {"n": 0, "win": 0.0, "avg_r": 0.0, "pf": 0.0, "pnl": 0.0, "t": 0.0}
    r = np.array([float(x.get("r") or 0.0) for x in rows])
    pnl = np.array([float(x.get("pnl") or 0.0) for x in rows])
    gp, gl = float(pnl[pnl > 0].sum()), float(-pnl[pnl <= 0].sum())
    sd = float(r.std(ddof=1)) if n > 1 else 0.0
    return {"n": n, "win": round(float((pnl > 0).mean() * 100), 1), "avg_r": round(float(r.mean()), 3),
            "pf": round(gp / gl, 2) if gl > 0 else (99.0 if gp > 0 else 0.0), "pnl": round(float(pnl.sum()), 2),
            "t": round(float(r.mean() / (sd / math.sqrt(n))), 2) if sd > 0 else 0.0}


def _by(rows: list[dict], fn) -> dict[str, dict]:
    g: dict[str, list] = {}
    for x in rows:
        k = fn(x)
        if k not in (None, ""):
            g.setdefault(str(k), []).append(x)
    return {k: _agg(v) for k, v in sorted(g.items())}


def suggestions(slices: dict[str, dict[str, dict]], min_n: int = 8) -> list[dict]:
    """Switch-off / keep candidates from the numbers: a slice is only judged with >= min_n trades and a t-statistic, never from a handful of results."""
    out = []
    for dim, groups in slices.items():
        for name, a in groups.items():
            if a["n"] < min_n:
                continue
            if a["avg_r"] < 0 and a["t"] <= -1.0:
                out.append({"dim": dim, "name": name, "action": "off", "why": f"{a['n']} معامله، میانگین {a['avg_r']:+.2f}R، t={a['t']:+.1f} — زیان معنادار", **a})
            elif a["avg_r"] < 0 and a["pf"] < 0.8:
                out.append({"dim": dim, "name": name, "action": "watch", "why": f"{a['n']} معامله، PF {a['pf']} — زیر نظر بگیرید", **a})
            elif a["avg_r"] > 0.15 and a["t"] >= 1.64:
                out.append({"dim": dim, "name": name, "action": "keep", "why": f"{a['n']} معامله، میانگین {a['avg_r']:+.2f}R، t={a['t']:+.1f} — برتری معنادار", **a})
    order = {"off": 0, "watch": 1, "keep": 2}
    return sorted(out, key=lambda z: (order[z["action"]], z["avg_r"]))


def weekly_report(history: list[dict], now: float | None = None, days: int = 7) -> dict[str, Any]:
    now = float(now or time.time())
    span = days * 86400.0
    h = [x for x in (history or []) if x.get("closed_at")]
    cur = [x for x in h if now - span <= float(x["closed_at"]) <= now]
    prev = [x for x in h if now - 2 * span <= float(x["closed_at"]) < now - span]
    slices = {
        "symbol": _by(cur, lambda x: str(x.get("symbol", "")).replace("USDT", "")),
        "side": _by(cur, lambda x: x.get("side")),
        "grade": _by(cur, lambda x: x.get("grade")),
        "regime": _by(cur, lambda x: x.get("regime")),
        "hour": _by(cur, lambda x: time.strftime("%H", time.gmtime(float(x["closed_at"]))) if x.get("closed_at") else None),
        "reason": _by(cur, lambda x: x.get("reason")),
    }
    # suggestions use ALL history so a quiet week cannot hide a long-standing leak
    all_slices = {"symbol": _by(h, lambda x: str(x.get("symbol", "")).replace("USDT", "")), "side": _by(h, lambda x: x.get("side")),
                  "grade": _by(h, lambda x: x.get("grade")), "regime": _by(h, lambda x: x.get("regime"))}
    this, last = _agg(cur), _agg(prev)
    delta = {k: round(this[k] - last[k], 3) for k in ("win", "avg_r", "pnl")}
    best = max(cur, key=lambda x: float(x.get("pnl") or 0.0), default=None)
    worst = min(cur, key=lambda x: float(x.get("pnl") or 0.0), default=None)
    slim = lambda x: ({"symbol": x.get("symbol"), "side": x.get("side"), "pnl": x.get("pnl"), "r": x.get("r"), "reason": x.get("reason")} if x else None)
    return {"days": days, "this": this, "prev": last, "delta": delta, "slices": slices, "suggestions": suggestions(all_slices),
            "best": slim(best), "worst": slim(worst), "enough": this["n"] >= 5}
