"""Professional Smart Money Concepts (SMC) engine.

A complete ICT/SMC toolkit — what institutional desks actually look at:
  • Order Blocks (bullish/bearish) with mitigation tracking
  • Fair Value Gaps (imbalance) — 3-candle gap logic
  • Breaker Blocks (failed OB that becomes opposite support/resistance)
  • Liquidity sweeps / stop-hunts (equal highs/lows taken then reversed)
  • Change of Character (CHoCH) — internal trend shift
  • Break of Structure (BOS) — continuation confirmation
  • Premium/Discount zones via dealing range
  • Mitigation detection (price returned to unfilled OB)
  • Confluence score: how many SMC factors align with a proposed side

Keeps the original lightweight interface (detect_order_blocks_fvg) for
backwards compatibility, but adds the full detect() function used by the
upgraded governor/grade pipeline.
"""
from __future__ import annotations
from typing import Any
import math

import numpy as np
import pandas as pd


def _atr_series(df: pd.DataFrame, n: int = 14) -> pd.Series:
    h, l, c = df["high"], df["low"], df["close"]
    tr = pd.concat([(h - l), (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, min_periods=n, adjust=False).mean()


# ── swing-point detection (fractal pivots) ──────────────────────────────────
def _swings(high: np.ndarray, low: np.ndarray, left: int = 2, right: int = 2) -> tuple[list, list]:
    """Return (swing_highs, swing_lows) as lists of (index, price)."""
    n = len(high)
    sh, sl = [], []
    for i in range(left, n - right):
        win_h = high[i - left:i + right + 1]
        win_l = low[i - left:i + right + 1]
        if high[i] == win_h.max() and list(win_h).count(high[i]) == 1:
            sh.append((i, float(high[i])))
        if low[i] == win_l.min() and list(win_l).count(low[i]) == 1:
            sl.append((i, float(low[i])))
    return sh, sl


# ── structure: BOS / CHoCH ──────────────────────────────────────────────────
def _structure(high, low, close, swings_h, swings_l):
    """Detect Break of Structure (continuation) and Change of Character (reversal).

    Returns dict with last_bos, last_choch, trend (bullish/bearish/range).
    """
    n = len(close)
    if len(swings_h) < 2 or len(swings_l) < 2:
        return {"trend": "range", "last_bos": None, "last_choch": None, "bias": 0.0}
    last_sh = swings_h[-1]
    last_sl = swings_l[-1]
    prev_sh = swings_h[-2]
    prev_sl = swings_l[-2]
    px = float(close[-1])
    # bullish structure: HH + HL → price breaks above last HH
    bos = None
    choch = None
    trend = "range"
    # determine the current directional regime from last two swings
    hh = last_sh[1] > prev_sh[1]
    hl = last_sl[1] > prev_sl[1]
    lh = last_sh[1] < prev_sh[1]
    ll = last_sl[1] < prev_sl[1]
    if hh and hl:
        trend = "bullish"
    elif lh and ll:
        trend = "bearish"
    # BOS: continuation break
    if trend == "bullish" and px > last_sh[1] and last_sh[0] >= n - 5:
        bos = {"type": "bullish_bos", "level": last_sh[1], "index": last_sh[0]}
    elif trend == "bearish" and px < last_sl[1] and last_sl[0] >= n - 5:
        bos = {"type": "bearish_bos", "level": last_sl[1], "index": last_sl[0]}
    # CHoCH: counter-trend break of the most recent opposing swing
    if trend == "bullish" and px < last_sl[1] and last_sl[0] >= n - 3:
        choch = {"type": "bearish_choch", "level": last_sl[1], "index": last_sl[0]}
        trend = "bearish_reversal"
    elif trend == "bearish" and px > last_sh[1] and last_sh[0] >= n - 3:
        choch = {"type": "bullish_choch", "level": last_sh[1], "index": last_sh[0]}
        trend = "bullish_reversal"
    bias = 1.0 if "bullish" in trend else -1.0 if "bearish" in trend else 0.0
    return {"trend": trend, "last_bos": bos, "last_choch": choch, "bias": bias,
            "last_swing_high": last_sh, "last_swing_low": last_sl}


# ── Order Blocks with mitigation ────────────────────────────────────────────
def _order_blocks(d: pd.DataFrame, atr: pd.Series, lookback: int = 40) -> list[dict]:
    """Bullish OB = last down candle before a strong up impulse (its body is the OB).
       Bearish OB = last up candle before a strong down impulse.
       Mitigation = price has returned to the OB since it formed."""
    o, h, l, c = (d[k].astype(float) for k in ("open", "high", "low", "close"))
    n = len(d)
    obs = []
    start = max(2, n - lookback)
    future_max = h.rolling(lookback, min_periods=1).max().shift(-1).bfill()
    future_min = l.rolling(lookback, min_periods=1).min().shift(-1).bfill()
    for i in range(start, n - 1):
        atr_i = float(atr.iloc[i]) or (float(c.iloc[i]) * 0.002)
        move = float(c.iloc[i + 1] - c.iloc[i])
        body_prev = float(c.iloc[i] - o.iloc[i])
        # bullish OB: candle i is down, next candle is strong up
        if body_prev < 0 and move > 1.3 * atr_i:
            ob_lo, ob_hi = float(min(o.iloc[i], c.iloc[i])), float(h.iloc[i])
            # mitigation: did a later candle trade back into the OB?
            mit = False
            if i + 2 < n:
                later_lo = float(l.iloc[i + 2:].min())
                if later_lo <= ob_hi:
                    mit = True
            obs.append({"type": "bullish_ob", "low": round(ob_lo, 8), "high": round(ob_hi, 8),
                        "mid": round((ob_lo + ob_hi) / 2, 8), "index": i, "mitigated": mit,
                        "fresh": not mit})
        # bearish OB
        if body_prev > 0 and move < -1.3 * atr_i:
            ob_lo, ob_hi = float(l.iloc[i]), float(max(o.iloc[i], c.iloc[i]))
            mit = False
            if i + 2 < n:
                later_hi = float(h.iloc[i + 2:].max())
                if later_hi >= ob_lo:
                    mit = True
            obs.append({"type": "bearish_ob", "low": round(ob_lo, 8), "high": round(ob_hi, 8),
                        "mid": round((ob_lo + ob_hi) / 2, 8), "index": i, "mitigated": mit,
                        "fresh": not mit})
    return obs


# ── Fair Value Gaps ─────────────────────────────────────────────────────────
def _fvgs(d: pd.DataFrame, atr: pd.Series, lookback: int = 40) -> list[dict]:
    o, h, l, c = (d[k].astype(float) for k in ("open", "high", "low", "close"))
    n = len(d)
    fvgs = []
    start = max(2, n - lookback)
    for i in range(start, n):
        atr_i = float(atr.iloc[i]) or (float(c.iloc[i]) * 0.002)
        # bullish FVG: low[i] > high[i-2]  (gap between candle i-2 high and candle i low)
        if float(l.iloc[i]) > float(h.iloc[i - 2]):
            glo, ghi = float(h.iloc[i - 2]), float(l.iloc[i])
            if ghi - glo > 0.1 * atr_i:
                # check if filled later
                filled = False
                if i + 1 < n:
                    later_lo = float(l.iloc[i + 1:].min())
                    if later_lo <= ghi:
                        filled = True
                fvgs.append({"type": "bullish_fvg", "low": round(glo, 8), "high": round(ghi, 8),
                             "mid": round((glo + ghi) / 2, 8), "index": i, "filled": filled, "fresh": not filled})
        # bearish FVG: high[i] < low[i-2]
        if float(h.iloc[i]) < float(l.iloc[i - 2]):
            glo, ghi = float(h.iloc[i]), float(l.iloc[i - 2])
            if ghi - glo > 0.1 * atr_i:
                filled = False
                if i + 1 < n:
                    later_hi = float(h.iloc[i + 1:].max())
                    if later_hi >= glo:
                        filled = True
                fvgs.append({"type": "bearish_fvg", "low": round(glo, 8), "high": round(ghi, 8),
                             "mid": round((glo + ghi) / 2, 8), "index": i, "filled": filled, "fresh": not filled})
    return fvgs


# ── Breaker Blocks ──────────────────────────────────────────────────────────
def _breaker_blocks(obs: list[dict], d: pd.DataFrame, atr: pd.Series) -> list[dict]:
    """A breaker block = an order block that FAILED (price broke through it),
    then became opposite-side resistance/support. Bullish OB that broke below
    its low becomes a bearish breaker (resistance)."""
    if not obs:
        return []
    h, l = d["high"].astype(float).values, d["low"].astype(float).values
    n = len(d)
    breakers = []
    for ob in obs:
        i = ob["index"]
        if i + 3 >= n:
            continue
        later = l[i + 1:] if "bullish" in ob["type"] else h[i + 1:]
        if len(later) == 0:
            continue
        # bullish OB broken → becomes bearish breaker (resistance above)
        if "bullish" in ob["type"] and float(later.min()) < ob["low"]:
            breakers.append({"type": "bearish_breaker", "low": ob["low"], "high": ob["high"],
                             "mid": ob["mid"], "index": i})
        # bearish OB broken → becomes bullish breaker (support below)
        if "bearish" in ob["type"] and float(later.max()) > ob["high"]:
            breakers.append({"type": "bullish_breaker", "low": ob["low"], "high": ob["high"],
                             "mid": ob["mid"], "index": i})
    return breakers


# ── Liquidity sweeps / stop hunts ───────────────────────────────────────────
def _liquidity_sweeps(d: pd.DataFrame, swings_h: list, swings_l: list, atr: pd.Series) -> list[dict]:
    """Detect equal highs/lows that get taken (swept) followed by reversal.
    A bullish sweep: price dips below a prior equal low then closes back above → stop hunt of shorts.
    A bearish sweep: price pokes above a prior equal high then closes back below → stop hunt of longs."""
    h, l, c = (d[k].astype(float).values for k in ("high", "low", "close"))
    n = len(d)
    sweeps = []
    # equal highs/lows: cluster swings within 0.1 ATR
    def _equal(items, tol):
        out = []
        for idx, (i, p) in enumerate(items):
            cluster = [(i, p)]
            for j in range(idx + 1, min(idx + 4, len(items))):
                if abs(items[j][1] - p) <= tol:
                    cluster.append(items[j])
            if len(cluster) >= 2 and cluster not in [x["cluster"] for x in out]:
                out.append({"cluster": cluster, "level": p, "first_idx": cluster[0][0], "last_idx": cluster[-1][0]})
        return out
    tol = float(atr.iloc[-1]) * 0.15 if len(atr) else 0.0
    eq_h = _equal(swings_h[-6:], tol)
    eq_l = _equal(swings_l[-6:], tol)
    # check if the LAST candle swept an equal high/low
    last_i = n - 1
    for eh in eq_h:
        if last_i > eh["last_idx"] and h[last_i] > eh["level"] and c[last_i] < eh["level"]:
            sweeps.append({"type": "bearish_sweep", "level": round(eh["level"], 8), "index": last_i,
                           "note": "شکار نقدینگی بالایی"})
    for el in eq_l:
        if last_i > el["last_idx"] and l[last_i] < el["level"] and c[last_i] > el["level"]:
            sweeps.append({"type": "bullish_sweep", "level": round(el["level"], 8), "index": last_i,
                           "note": "شکار نقدینگی پایینی"})
    return sweeps


# ── Dealing range → premium/discount ────────────────────────────────────────
def _dealing_range(swings_h, swings_l, price):
    """The most recent significant swing high to swing low defines the range.
    > 50% = premium (good for SHORTs), < 50% = discount (good for LONGs)."""
    if not swings_h or not swings_l:
        return {"premium": 0.5, "zone": "mid", "range_high": 0, "range_low": 0}
    rh = swings_h[-1][1]
    rl = swings_l[-1][1]
    if rh <= rl:
        return {"premium": 0.5, "zone": "mid", "range_high": rh, "range_low": rl}
    premium = (price - rl) / (rh - rl) if rh > rl else 0.5
    zone = "premium" if premium > 0.65 else "discount" if premium < 0.35 else "mid"
    return {"premium": round(premium, 3), "zone": zone, "range_high": rh, "range_low": rl}


# ── Backwards-compatible single function ────────────────────────────────────
def detect_order_blocks_fvg(df: pd.DataFrame, lookback: int = 40) -> dict[str, Any]:
    """Backwards-compatible OB/FVG detector (kept for technicals.py).
    Returns {order_blocks, fvgs, nearest_ob, nearest_fvg, price, smc_score, ...}."""
    full = detect(df, lookback)
    # shape into the old contract
    obs = [{"type": "bullish_ob" if "bullish" in ob["type"] else "bearish_ob",
            "kind": "bull" if "bullish" in ob["type"] else "bear",
            "lo": ob["low"], "hi": ob["high"], "mid": ob["mid"]} for ob in full["order_blocks"]]
    fvgs = [{"type": "bullish_fvg" if "bullish" in f["type"] else "bearish_fvg",
             "kind": "bull" if "bullish" in f["type"] else "bear",
             "lo": f["low"], "hi": f["high"], "mid": f["mid"]} for f in full["fvgs"]]
    price = full["price"]
    # also include structure for technicals.extras merge
    return {
        "order_blocks": obs, "fvgs": fvgs,
        "nearest_ob": obs[0] if obs else None,
        "nearest_fvg": fvgs[0] if fvgs else None,
        "price": price,
        "structure": {"trend": full["structure"]["trend"], "last_bos": full["structure"]["last_bos"],
                      "last_choch": full["structure"]["last_choch"],
                      "last_low": full["structure"]["last_swing_low"][1] if full["structure"]["last_swing_low"] else None,
                      "last_high": full["structure"]["last_swing_high"][1] if full["structure"]["last_swing_high"] else None},
        "smc_score": full["smc_score"],
    }


# ── Full detection (the upgraded entry point) ───────────────────────────────
def detect(df: pd.DataFrame, lookback: int = 60) -> dict[str, Any]:
    """Full SMC analysis. Pure dataframe, no network."""
    empty = {
        "order_blocks": [], "fvgs": [], "breakers": [], "sweeps": [], "structure": {},
        "dealing_range": {}, "smc_score": 0.0, "smc_signal": "neutral", "price": 0.0,
        "confluences": [], "notes": [],
    }
    try:
        if df is None or len(df) < 30:
            return empty
        d = df.tail(max(lookback + 10, 40)).reset_index(drop=True)
        h, l, c = (d[k].astype(float).values for k in ("high", "low", "close"))
        atr = _atr_series(d).bfill().fillna(0.0)
        price = float(c[-1])
        swings_h, swings_l = _swings(h, l, left=2, right=2)
        structure = _structure(h, l, c, swings_h, swings_l)
        obs = _order_blocks(d, atr, lookback)
        fvgs = _fvgs(d, atr, lookback)
        breakers = _breaker_blocks(obs, d, atr)
        sweeps = _liquidity_sweeps(d, swings_h, swings_l, atr)
        dealing = _dealing_range(swings_h, swings_l, price)
        # ── nearest (unmitigated) zones to price ────────────────────────────
        def _dist(z):
            mid = float(z.get("mid") or price)
            return abs(price - mid)
        fresh_obs = [ob for ob in obs if ob.get("fresh")]
        fresh_fvgs = [f for f in fvgs if f.get("fresh")]
        fresh_obs.sort(key=_dist)
        fresh_fvgs.sort(key=_dist)
        nearest_ob = fresh_obs[0] if fresh_obs else (obs[0] if obs else None)
        nearest_fvg = fresh_fvgs[0] if fresh_fvgs else (fvgs[0] if fvgs else None)
        nearest_breaker = sorted(breakers, key=_dist)[0] if breakers else None
        last_sweep = sweeps[-1] if sweeps else None
        # ── confluence score (-1..+1) ───────────────────────────────────────
        score = 0.0
        notes = []
        # structure bias
        score += structure["bias"] * 0.3
        if structure["trend"] in ("bullish", "bullish_reversal"):
            notes.append("ساختار صعودی (BOS/CHoCH)")
        elif structure["trend"] in ("bearish", "bearish_reversal"):
            notes.append("ساختار نزولی (BOS/CHoCH)")
        # CHoCH boost (strongest reversal signal)
        if structure["last_choch"]:
            ch = structure["last_choch"]
            if "bullish" in ch["type"]:
                score += 0.35
                notes.append("تغییر شخصیت (CHoCH) صعودی")
            elif "bearish" in ch["type"]:
                score -= 0.35
                notes.append("تغییر شخصیت (CHoCH) نزولی")
        # BOS confirmation
        if structure["last_bos"]:
            b = structure["last_bos"]
            if "bullish" in b["type"]:
                score += 0.2
                notes.append("شکست ساختار صعودی (BOS)")
            elif "bearish" in b["type"]:
                score -= 0.2
                notes.append("شکست ساختار نزولی (BOS)")
        # premium/discount
        zone = dealing["zone"]
        if zone == "discount":
            score += 0.15
            notes.append("ناحیه تخفیف (مناسب خرید)")
        elif zone == "premium":
            score -= 0.15
            notes.append("ناحیه پرمیوم (مناسب فروش)")
        # nearest fresh OB
        if nearest_ob:
            t = nearest_ob["type"]
            mid = float(nearest_ob["mid"])
            if abs(price - mid) / price < 0.006:  # within 0.6%
                if "bullish" in t:
                    score += 0.18
                    notes.append("واکنش به Order Block صعودی تازه")
                else:
                    score -= 0.18
                    notes.append("واکنش به Order Block نزولی تازه")
        # nearest fresh FVG
        if nearest_fvg:
            t = nearest_fvg["type"]
            mid = float(nearest_fvg["mid"])
            if abs(price - mid) / price < 0.006:
                if "bullish" in t:
                    score += 0.12
                    notes.append("داخل FVG صعودی تازه")
                else:
                    score -= 0.12
                    notes.append("داخل FVG نزولی تازه")
        # liquidity sweep (very strong reversal signal)
        if last_sweep:
            t = last_sweep["type"]
            if "bullish" in t:
                score += 0.3
                notes.append("شکار نقدینگی پایینی (واکنش صعودی)")
            elif "bearish" in t:
                score -= 0.3
                notes.append("شکار نقدینگی بالایی (واکنش نزولی)")
        # breaker block
        if nearest_breaker and abs(price - float(nearest_breaker["mid"])) / price < 0.005:
            t = nearest_breaker["type"]
            if "bullish" in t:
                score += 0.15
                notes.append("واکنش به بریکر بلاک صعودی")
            else:
                score -= 0.15
                notes.append("واکنش به بریکر بلاک نزولی")
        score = max(-1.0, min(1.0, score))
        signal = "bullish" if score >= 0.25 else "bearish" if score <= -0.25 else "neutral"
        return {
            "order_blocks": obs[:6], "fvgs": fvgs[:6], "breakers": breakers[:4],
            "sweeps": sweeps, "structure": {**structure,
                "last_swing_high": swings_h[-1] if swings_h else None,
                "last_swing_low": swings_l[-1] if swings_l else None},
            "dealing_range": dealing,
            "nearest_ob": nearest_ob, "nearest_fvg": nearest_fvg,
            "nearest_breaker": nearest_breaker, "last_sweep": last_sweep,
            "smc_score": round(score, 3), "smc_signal": signal,
            "confluences": notes, "notes": notes, "price": round(price, 8),
        }
    except Exception:  # noqa: BLE001
        return empty


# ── Confluence helper for the governor ──────────────────────────────────────
def confluence_for_side(side: str, smc: dict, price: float) -> tuple[float, list[str]]:
    """Return (boost -0.3..+0.3, matching_note_list) for a proposed side."""
    if not smc or side not in ("LONG", "SHORT"):
        return 0.0, []
    score = float(smc.get("smc_score") or 0.0)
    signal = smc.get("smc_signal") or "neutral"
    want = "bullish" if side == "LONG" else "bearish"
    boost = 0.0
    notes = []
    if signal == want:
        boost = 0.25 * abs(score) * (1 if want == "bullish" else 1)
        notes.append(f"هم‌جهت SMC ({signal}، score {score:+.2f})")
    elif signal != "neutral" and signal != want:
        boost = -0.2 * abs(score)
        notes.append(f"مخالف SMC ({signal})")
    # CHoCH alignment
    ch = (smc.get("structure") or {}).get("last_choch")
    if ch:
        if want in str(ch.get("type")):
            boost += 0.08
            notes.append("CHoCH هم‌جهت")
        elif want not in str(ch.get("type")) and "choch" in str(ch.get("type")):
            boost -= 0.06
    # liquidity sweep alignment
    sw = smc.get("last_sweep")
    if sw and want in str(sw.get("type")):
        boost += 0.1
        notes.append("شکار نقدینگی هم‌جهت")
    # dealing range
    zone = (smc.get("dealing_range") or {}).get("zone")
    if zone == "discount" and side == "LONG":
        boost += 0.05
        notes.append("ورود در ناحیه تخفیف")
    elif zone == "premium" and side == "SHORT":
        boost += 0.05
        notes.append("ورود در ناحیه پرمیوم")
    elif zone == "premium" and side == "LONG":
        boost -= 0.04
    elif zone == "discount" and side == "SHORT":
        boost -= 0.04
    return max(-0.3, min(0.3, boost)), notes


# ── BTC correlation filter (kept for compatibility) ─────────────────────────
def btc_corr_from_closes(alt_close: pd.Series, btc_close: pd.Series, lookback: int = 48) -> dict[str, Any]:
    try:
        a = alt_close.astype(float).pct_change().dropna().tail(lookback)
        b = btc_close.astype(float).pct_change().dropna().tail(lookback)
        n = min(len(a), len(b))
        if n < 12:
            return {"corr": 0.0, "samples": n, "regime": "insufficient"}
        av = a.tail(n).values
        bv = b.tail(n).values
        if float(np.std(av)) < 1e-12 or float(np.std(bv)) < 1e-12:
            return {"corr": 0.0, "samples": n, "regime": "flat"}
        corr = float(np.corrcoef(av, bv)[0, 1])
        if not math.isfinite(corr):
            corr = 0.0
        regime = "high_beta" if corr >= 0.75 else "decoupled" if corr < 0.35 else "normal"
        return {"corr": round(corr, 3), "samples": n, "regime": regime}
    except Exception:  # noqa: BLE001
        return {"corr": 0.0, "samples": 0, "regime": "error"}


def apply_btc_filter(symbol: str, side: str, atr_pct: float, btc_side: str, corr_info: dict | None) -> dict[str, Any]:
    info = corr_info or {"corr": 0.0, "regime": "unknown"}
    corr = float(info.get("corr") or 0.0)
    regime = str(info.get("regime") or "")
    out = {"blocked": False, "reason": "", "corr": corr, "regime": regime}
    sym = str(symbol or "").upper().replace("/", "")
    if sym in ("BTCUSDT", "BTC"):
        return out
    if side not in ("LONG", "SHORT"):
        return out
    if atr_pct < 1.2 or corr < 0.70:
        return out
    btc = str(btc_side or "WAIT").upper()
    if side == "LONG" and btc == "SHORT":
        out["blocked"] = True
        out["reason"] = f"همبستگی بالا با BTC ({corr:.2f}) و روند BTC نزولی در نوسان بالا"
    elif side == "SHORT" and btc == "LONG":
        out["blocked"] = True
        out["reason"] = f"همبستگی بالا با BTC ({corr:.2f}) و روند BTC صعودی در نوسان بالا"
    return out


def smc_score_boost(side: str, smc: dict, price: float) -> tuple[float, str]:
    """Backwards-compatible boost from nearest OB/FVG alignment."""
    if side not in ("LONG", "SHORT") or not smc or price <= 0:
        return 0.0, ""
    boost, notes = confluence_for_side(side, smc, price)
    return boost, " · ".join(notes) if notes else ""
