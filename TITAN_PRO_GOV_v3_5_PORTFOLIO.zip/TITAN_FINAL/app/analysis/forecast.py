"""Probabilistic projection v3 — "Candle Forge".

What the old v2 did wrong (and what v3 does about it)
------------------------------------------------------
* The forming candle was ignored: the projection started from the last CLOSE, not from the live price and the real open /
  high / low of the candle that is forming right now.  v3 anchors candle 0 to the live price and the elapsed fraction of the
  bar, so the join between real and projected candles is exact.
* Wicks were drawn independently of bodies and of the volatility regime.  v3 bootstraps WHOLE candles (shock, gap, upper wick,
  lower wick together, in short blocks so clustering survives) normalised by the volatility that was in force when they happened.
* Volatility was close-to-close EWMA only.  v3 uses a range-aware (Garman-Klass blended) EWMA, GARCH(1,1) dynamics inside every
  simulated path, and an hour-of-day / day-of-week volatility profile (shrunk) for the exact clock time of every future bar.
* Nothing checked whether the cone was honest.  v3 runs a walk-forward calibration on the coin's own history for every
  (symbol, timeframe, closed bar): it measures the real coverage of the 10-90 % band, fits a volatility scale, shrinks the drift
  towards what actually carried information and shrinks the up-probability by its measured reliability.
* The projection ignored the market around it.  v3 accepts a "view" (higher-timeframe consensus) and applies a bounded
  exponential tilt (importance weights) to the simulated paths; the untilted, calibrated statistics stay available
  (`prob_up_stat`) so the central governor never counts the same evidence twice.
* Entry / exit levels were only scored, never optimised.  v3 runs the planner laboratory on the SAME paths and ships the best
  entry (fill probability, expected R after costs) next to the signal's own levels, plus a level-by-level reality check.

Everything is deterministic per candle (seeded by symbol + last bar) and is a distribution, not a promise.
"""
from __future__ import annotations
import threading
import time
import zlib
from typing import Any
import numpy as np
import pandas as pd

from app.config import FORECAST_CANDLES, MC_PATHS, PARTIALS, EDGE_HORIZON, TF_MS, SIGNAL_VALID_BARS, TF_WEIGHT

QS = (5, 10, 25, 50, 75, 90, 95)
QN = tuple(f"p{q}" for q in QS)
_LN2K = 2.0 * np.log(2.0) - 1.0
GARCH_A, GARCH_B = 0.07, 0.91          # innovation / persistence of the in-path volatility dynamics
BLOCK_P = 0.34                          # probability to start a new bootstrap block (mean block length ~3 candles)
LAMBDA_MAX = 0.30                       # strongest allowed tilt of the path distribution (in terminal-sigma units)
SAFETY = (1.04, 1.12)                   # cone width safety factor at 3 and >=12 bars (out-of-sample coverage correction)
CAL_H = 12                              # calibration horizon (bars)
CAL_PATHS = 140
ENGINE = "v3"

_CAL: dict[tuple, dict] = {}
_CAL_LOCK = threading.Lock()
_CAL_MAX = 500

# Frozen simulation per closed bar: the projected candles of a bar are drawn ONCE (when the bar closes / first scan) and stay
# identical while that bar is forming — they are only revised when the live price leaves the simulated cone (max 2 times, >= 150 s apart).
FREEZE = True
REVISE_MAX, REVISE_GAP_S, REVISE_BAND = 2, 150.0, (1.0, 99.0)
DIR_PICK_W = 10.0                      # weight of per-candle direction agreement when choosing the displayed typical path (candidates are already the paths closest to the median, so the cone is respected)
_SIM: dict[tuple, dict] = {}
_SIM_LOCK = threading.Lock()
_SIM_MAX = 400


def _r(x: float) -> float:
    """Round to 8 significant digits (round(x, 8) destroys SHIB/PEPE-class prices)."""
    return float(f"{float(x):.8g}")


def _atr_arr(df) -> float:
    h, l, c = df["high"].values, df["low"].values, df["close"].values
    tr = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    return float(np.mean(tr[-14:])) if len(tr) >= 14 else float(np.mean(tr)) if len(tr) else 0.0


# ── timeframe helpers ───────────────────────────────────────────────────────
def _open_ms(df) -> np.ndarray:
    try:
        return np.asarray(pd.DatetimeIndex(df["open_time"]).as_unit("ns").asi8 // 1_000_000, dtype=np.int64)
    except Exception:                                                     # noqa: BLE001
        return np.arange(len(df), dtype=np.int64) * 3_600_000


def _tf_ms(df, tf: str | None, ms: np.ndarray | None = None) -> tuple[str, int]:
    if tf in TF_MS:
        return tf, int(TF_MS[tf])
    ms = _open_ms(df) if ms is None else ms
    step = int(np.median(np.diff(ms))) if len(ms) > 2 else 3_600_000
    best = min(TF_MS, key=lambda k: abs(TF_MS[k] - step))
    return best, int(TF_MS[best])


def _bucket(ms, tf: str) -> np.ndarray:
    ms = np.asarray(ms, dtype=np.int64)
    if tf == "1d":
        return ((ms // 86_400_000) + 3) % 7                               # Monday = 0
    if tf == "4h":
        return (((ms // 3_600_000) % 24) // 4).astype(np.int64)
    return ((ms // 3_600_000) % 24).astype(np.int64)


def _nbuckets(tf: str) -> int:
    return 7 if tf == "1d" else 6 if tf == "4h" else 24


# ── features (computed once per frame, strictly causal) ─────────────────────
def _features(df: pd.DataFrame, tf: str, ms: np.ndarray) -> dict:
    o = np.clip(df["open"].values.astype(float), 1e-12, None)
    c = np.clip(df["close"].values.astype(float), 1e-12, None)
    h = np.clip(df["high"].values.astype(float), 1e-12, None)
    l = np.clip(df["low"].values.astype(float), 1e-12, None)
    h = np.maximum(h, np.maximum(o, c))
    l = np.minimum(l, np.minimum(o, c))
    n = len(c)
    c_prev = np.r_[o[0], c[:-1]]
    r = np.log(c / c_prev)
    gap = np.log(o / c_prev)
    body = np.log(c / o)
    gk = np.clip(0.5 * np.log(h / l) ** 2 - _LN2K * body ** 2, 0.0, None)
    v = np.nan_to_num(0.5 * gk + 0.5 * r * r)
    warm = min(20, max(5, n // 4))
    s = float(np.mean(v[:warm])) + 1e-14
    var_prev, ev = np.empty(n), np.empty(n)
    for i in range(n):                                                    # var_prev[i] is known BEFORE bar i is observed
        var_prev[i] = s
        s = 0.94 * s + 0.06 * v[i]
        ev[i] = s
    tr = np.maximum(h - l, np.maximum(np.abs(h - c_prev), np.abs(l - c_prev)))
    atr = pd.Series(tr).rolling(14, min_periods=1).mean().values
    ema21 = pd.Series(c).ewm(span=21, adjust=False).mean().values
    return {"n": n, "o": o, "c": c, "h": h, "l": l, "r": r, "gap": gap, "v": v, "var_prev": var_prev, "ev": ev, "atr": atr, "ema21": ema21,
            "u": np.log(h / np.maximum(o, c)), "lw": np.log(np.minimum(o, c) / l), "ms": ms, "bucket": _bucket(ms, tf), "nb": _nbuckets(tf), "warm": warm}


def _build(F: dict, t: int, tf: str) -> dict:
    """Distribution model from bars [0:t] only (no look-ahead, so the same function serves calibration and the live projection)."""
    w0 = F["warm"]
    vp, v, bk = F["var_prev"][:t], F["v"][:t], F["bucket"][:t]
    nb = F["nb"]
    prof = np.ones(nb)
    if t >= 100:                                                          # intraday / weekly volatility profile, shrunk towards 1
        ratio = np.clip(v[w0:] / vp[w0:], 0.0, 9.0)
        cnt = np.bincount(bk[w0:], minlength=nb).astype(float)
        sm = np.bincount(bk[w0:], weights=ratio, minlength=nb)
        mean_all = float(ratio.mean()) + 1e-12
        k = 24.0 if tf == "1d" else 8.0
        prof = np.sqrt(np.clip((sm + k * mean_all) / (cnt + k) / mean_all, 0.45, 2.2))
    scale = np.sqrt(vp) * prof[bk]
    scale = np.maximum(scale, 1e-9)
    z = np.clip(F["r"][:t] / scale, -5, 5)[w0:]
    z = (z - z.mean()) / (z.std() + 1e-12)
    g = np.clip(F["gap"][:t] / scale, -4, 4)[w0:]
    u = np.clip(F["u"][:t] / scale, 0, 8)[w0:]
    lw = np.clip(F["lw"][:t] / scale, 0, 8)[w0:]
    vt = v[-250:]
    lv = float(np.mean(np.clip(vt, 0, np.percentile(vt, 99)))) + 1e-14
    r = F["r"][:t]
    c = F["c"][:t]
    yy = np.log(c[-60:])
    xx = np.arange(len(yy), dtype=float)
    slope, icpt = np.polyfit(xx, yy, 1) if len(yy) >= 10 else (0.0, 0.0)
    res_sd = float(np.std(yy - (slope * xx + icpt))) + 1e-12
    tstat = slope / (res_sd / (np.std(xx) * np.sqrt(len(xx)) + 1e-12))
    trend = float(np.clip(abs(tstat) / 12.0, 0.0, 1.0))
    mu0 = 0.25 * float(np.mean(r[-40:])) + 0.15 * float(np.mean(r[-10:]))
    return {"prof": prof, "z": z, "g": g, "u": u, "l": lw, "lv": lv, "var0": float(F["ev"][t - 1]), "mu0": mu0, "trend": trend,
            "mu_keep": 0.92 + 0.055 * trend, "pull0": 0.035 * (1.0 - 0.8 * trend), "ema21": float(F["ema21"][t - 1]), "atr": float(F["atr"][t - 1]),
            "last_close": float(c[-1])}


def _paths(M: dict, bk_f: np.ndarray, N: int, P: int, rng, vs=1.0, ds: float = 1.0, start: float | None = None, rem: float | None = None) -> dict:
    """P simulated paths of N candles. `rem` (0..1) = fraction of candle 0 still to be played (forming candle); candle 0 then starts at `start` (the live price)."""
    nz = len(M["z"])
    idx = np.empty((P, N), dtype=np.int64)
    idx[:, 0] = rng.integers(0, nz, size=P)
    new = rng.random((P, N)) < BLOCK_P
    rnd = rng.integers(0, nz, size=(P, N))
    for i in range(1, N):
        nxt = idx[:, i - 1] + 1
        nxt = np.where(nxt >= nz, rnd[:, i], nxt)
        idx[:, i] = np.where(new[:, i], rnd[:, i], nxt)
    Z, G, U, W = M["z"][idx], M["g"][idx], M["u"][idx], M["l"][idx]
    omega = (1.0 - GARCH_A - GARCH_B) * M["lv"]
    start = float(M["last_close"] if start is None else start)
    tgt = np.log(max(M["ema21"], 1e-12))
    cur = np.full(P, np.log(start))
    var = np.full(P, M["var0"])
    prof_f = M["prof"][bk_f]
    opens, highs, lows, closes, logp = (np.empty((P, N)) for _ in range(5))
    for i in range(N):
        frac = float(rem) if (i == 0 and rem is not None) else 1.0
        sc = np.sqrt(var) * prof_f[i] * (float(vs[i]) if isinstance(vs, np.ndarray) else vs) * np.sqrt(frac)
        drift = ds * (M["mu0"] * (M["mu_keep"] ** i) + M["pull0"] * (0.9 ** i) * (tgt - cur)) * frac
        o_log = cur if i == 0 else cur + G[:, i] * sc
        c_log = cur + sc * Z[:, i] + drift
        o_, c_ = np.exp(o_log), np.exp(c_log)
        opens[:, i], closes[:, i] = o_, c_
        highs[:, i] = np.maximum(o_, c_) * np.exp(U[:, i] * sc)
        lows[:, i] = np.minimum(o_, c_) * np.exp(-W[:, i] * sc)
        logp[:, i] = c_log
        var = omega + var * (GARCH_A * Z[:, i] ** 2 + GARCH_B)
        cur = c_log
    return {"opens": opens, "highs": highs, "lows": lows, "closes": closes, "logp": logp}


def vs_curve(vs3: float, vs12: float, N: int) -> np.ndarray:
    """Volatility scale per step: interpolated in log-horizon between the 3-bar and the 12-bar calibration (flat outside)."""
    h = np.arange(1, N + 1, dtype=float)
    w = np.clip((np.log(h) - np.log(3.0)) / (np.log(12.0) - np.log(3.0)), 0.0, 1.0)
    # out-of-sample safety: in-sample calibration under-covers a little (measured with tools/forecast_eval.py on iid and GARCH-t series)
    return (vs3 + (vs12 - vs3) * w) * (SAFETY[0] + (SAFETY[1] - SAFETY[0]) * w)


# ── walk-forward calibration ────────────────────────────────────────────────
def _default_cal(n: int = 0, why: str = "history too short") -> dict:
    return {"vs": 1.0, "vs3": 1.0, "skill_rw": None, "cov80_h3": None, "ds": 0.5, "dir_shrink": 0.7, "cov80": None, "cov50": None, "hit": None, "n_hit": 0, "brier_skill": None, "bias_sigma": None,
            "mae_pct": None, "quality": None, "n": n, "horizon": CAL_H, "note": why}


def _cal_origins(n: int) -> list[int]:
    t0, last = 90, n - CAL_H
    if last - t0 < 12:
        return []
    step = max(3, (last - t0) // 30)
    return list(range(t0, last + 1, step))


def calibrate(F: dict, tf: str, tfms: int, seed_key: str) -> dict:
    n = F["n"]
    ck = (seed_key, tf, int(F["ms"][-1]), n)
    with _CAL_LOCK:
        hit = _CAL.get(ck)
    if hit is not None:
        return hit
    origins = _cal_origins(n)
    if len(origins) < 10:
        return _default_cal(n)
    H, P = CAL_H, CAL_PATHS
    stats = []
    for t in origins:
        M = _build(F, t, tf)
        ms_last = int(F["ms"][t - 1])
        bk_f = _bucket(ms_last + tfms * (np.arange(H) + 1), tf)
        seed = zlib.crc32(f"{seed_key}|cal|{t}".encode()) & 0x7FFFFFFF
        c0 = float(F["c"][t - 1])
        real = float(np.log(F["c"][t + H - 1] / c0))
        stats.append((M, bk_f, seed, c0, real))

    def run(vs: float, ds: float) -> list[np.ndarray]:
        out = []
        for M, bk_f, seed, c0, _ in stats:
            sim = _paths(M, bk_f, H, P, np.random.default_rng(seed), vs, ds, start=c0)
            out.append(np.log(sim["closes"][:, H - 1] / c0))
        return out

    real = np.array([s[4] for s in stats])
    real3 = np.array([float(np.log(F["c"][t + 2] / F["c"][t - 1])) for t in origins])
    sdv = {}

    def run(vs, ds) -> list[np.ndarray]:
        out = []
        for M, bk_f, seed, c0, _ in stats:
            sim = _paths(M, bk_f, H, P, np.random.default_rng(seed), vs, ds, start=c0)
            out.append(np.log(sim["closes"] / c0))                       # (P, H) log-returns from the last close
        return out

    def fit_scale(T, rl, k, n_eff):
        tk = [t[:, k] for t in T]
        m = np.array([t.mean() for t in tk]); sd = np.array([t.std() for t in tk]) + 1e-12
        z = (rl - m) / sd
        rms = float(np.sqrt(np.mean(z ** 2))); mad = float(np.median(np.abs(z - np.median(z))) / 0.6745)
        sf = float(np.sqrt(max(rms, 0.3) * max(mad, 0.3)))
        return float(np.clip(1.0 + (np.clip(sf, 0.65, 1.7) - 1.0) * n_eff / (n_eff + 6.0), 0.65, 1.7)), m, z
    nn = len(real)
    n_eff = nn / 2.0                                                      # overlapping windows
    T1 = run(1.0, 1.0)
    vs12, m1, zrel = fit_scale(T1, real, H - 1, n_eff)
    vs3, _, _ = fit_scale(T1, real3, 2, n_eff)
    # drift: Bayesian shrink of the regression slope of realised on expected move towards 0.5 (momentum rarely carries full weight)
    smm = float(np.sum(m1 * m1)) + 1e-18
    b_raw = float(np.sum(m1 * real) / smm)
    var_b = max(float(np.var(real) + 1e-18) / smm * (nn / n_eff), 1e-6)      # overlapping windows -> inflate the slope uncertainty
    p0, s0 = 0.5, 0.5
    ds = float(np.clip((p0 / s0 ** 2 + b_raw / var_b) / (1 / s0 ** 2 + 1 / var_b), 0.0, 1.2))
    curve = vs_curve(vs3, vs12, H)
    T2 = run(curve, ds)
    t12 = [t[:, H - 1] for t in T2]
    t3 = [t[:, 2] for t in T2]
    pit = np.array([(np.sum(t < r_) + 0.5 * np.sum(t == r_)) / len(t) for t, r_ in zip(t12, real)])
    pit3 = np.array([(np.sum(t < r_) + 0.5 * np.sum(t == r_)) / len(t) for t, r_ in zip(t3, real3)])
    cov80_3 = float(np.mean((pit3 > 0.1) & (pit3 < 0.9)))
    pu = np.array([float(np.mean(t > 0)) for t in t12])
    up = (real > 0).astype(float)
    cov80 = float(np.mean((pit > 0.1) & (pit < 0.9)))
    cov50 = float(np.mean((pit > 0.25) & (pit < 0.75)))
    dev = pu - 0.5
    sdev = float(np.sum(dev * dev)) + 1e-9
    s_raw = float(np.sum(dev * (up - 0.5)) / sdev)
    var_s = max(0.25 / sdev * 2.0, 1e-6)
    dir_shrink = float(np.clip((0.7 / 0.3 ** 2 + s_raw / var_s) / (1 / 0.3 ** 2 + 1 / var_s), 0.25, 1.0))
    pcal = 0.5 + dir_shrink * dev
    brier = float(np.mean((pcal - up) ** 2))
    skill = 1.0 - brier / 0.25
    mask = np.abs(dev) > 0.05
    hit = float(np.mean((pu[mask] > 0.5) == (up[mask] > 0.5))) if mask.sum() >= 5 else None
    med2 = np.array([float(np.median(t)) for t in t12])
    # pinball-loss skill against a plain Gaussian random walk with the same EWMA volatility (> 0 means the model beats the naive cone)
    qs_ = np.array([0.1, 0.25, 0.5, 0.75, 0.9])
    from math import erf, sqrt as _sq
    zq = np.array([-1.2816, -0.6745, 0.0, 0.6745, 1.2816])
    def pin(qv, r_):
        d_ = r_ - qv
        return float(np.mean(np.maximum(qs_ * d_, (qs_ - 1) * d_)))
    lm = lr_ = 0.0
    for t, r_, o_ in zip(t12, real, origins):
        lm += pin(np.quantile(t, qs_), r_)
        lr_ += pin(zq * float(np.sqrt(F["ev"][o_ - 1] * H)), r_)
    skill_rw = 1.0 - lm / (lr_ + 1e-18)
    q = 0.5 * float(np.clip(1 - abs(cov80 - 0.8) / 0.2, 0, 1)) + 0.25 * float(np.clip(0.5 + skill * 4.0, 0, 1)) + 0.25 * float(np.clip(0.5 + skill_rw * 3.0, 0, 1))
    cal = {"vs": round(vs12, 3), "vs3": round(vs3, 3), "ds": round(ds, 3), "dir_shrink": round(dir_shrink, 3), "cov80": round(cov80, 3), "cov80_h3": round(cov80_3, 3), "cov50": round(cov50, 3),
           "hit": None if hit is None else round(hit, 3), "n_hit": int(mask.sum()), "brier_skill": round(skill, 3), "skill_rw": round(float(skill_rw), 3), "bias_sigma": round(float(np.mean(zrel)), 3),
           "mae_pct": round(float(np.mean(np.abs(np.exp(real) - np.exp(med2)))) * 100, 3), "quality": round(q, 3), "n": int(nn), "horizon": H, "note": None}
    with _CAL_LOCK:
        if len(_CAL) >= _CAL_MAX:
            for k in list(_CAL)[: _CAL_MAX // 4]:
                _CAL.pop(k, None)
        _CAL[ck] = cal
    return cal


# ── weighted statistics ─────────────────────────────────────────────────────
def _wq(A: np.ndarray, w: np.ndarray | None, qs) -> np.ndarray:
    """Weighted quantiles (qs in percent) along axis 0 of (P, N) -> (len(qs), N)."""
    if w is None:
        return np.percentile(A, qs, axis=0)
    order = np.argsort(A, axis=0)
    As = np.take_along_axis(A, order, 0)
    ws = w[order]
    cw = (np.cumsum(ws, axis=0) - 0.5 * ws) / ws.sum(axis=0)
    out = np.empty((len(qs), A.shape[1]))
    for j in range(A.shape[1]):
        out[:, j] = np.interp(np.asarray(qs) / 100.0, cw[:, j], As[:, j])
    return out


def _wq1(a: np.ndarray, w: np.ndarray | None, q: float) -> float:
    return float(_wq(a[:, None], w, [q])[0, 0])


def _wm(a: np.ndarray, w: np.ndarray | None) -> float:
    return float(np.average(a, weights=w)) if w is not None else float(np.mean(a))


def _tilt_weights(logp_end: np.ndarray, lam: float) -> np.ndarray | None:
    if abs(lam) < 1e-6:
        return None
    z = (logp_end - logp_end.mean()) / (logp_end.std() + 1e-12)
    w = np.exp(np.clip(lam * z, -3, 3))
    return w / w.mean()


def _adapt(cal: dict, adj: dict | None) -> dict:
    """Self-correction from the LIVE forward verification of this coin/timeframe (fctrack): if the real candles keep disagreeing with the
    projection, the projection becomes more cautious (smaller drift / direction confidence, wider cone) — the system learns from its misses."""
    notes: list[str] = []
    cal = dict(cal)
    if adj:
        n, hit = int(adj.get("n_dir") or 0), adj.get("hit")
        if n >= 20 and hit is not None and hit < 0.47:
            cal["ds"] = cal["ds"] * 0.5
            cal["dir_shrink"] = max(0.25, cal["dir_shrink"] * 0.6)
            notes.append(f"جهت کندل‌ها در {n} نمونهٔ زنده فقط {hit * 100:.0f}٪ درست بود؛ اطمینان جهت کم شد")
        nc, cov = int(adj.get("n_cov") or 0), adj.get("cov80")
        if nc >= 30 and cov is not None:
            if cov < 0.7:
                w = 1.0 + min(0.25, 0.8 - cov)
                cal["vs"], cal["vs3"] = cal["vs"] * w, cal.get("vs3", cal["vs"]) * w
                notes.append(f"قیمت واقعی بیش از حد از مخروط بیرون رفت (پوشش {cov * 100:.0f}٪)؛ مخروط {int((w - 1) * 100)}٪ پهن‌تر شد")
            elif cov > 0.92:
                cal["vs"], cal["vs3"] = cal["vs"] * 0.92, cal.get("vs3", cal["vs"]) * 0.92
                notes.append(f"مخروط بیش از حد پهن بود (پوشش {cov * 100:.0f}٪)؛ کمی باریک شد")
    cal["adapt"] = notes
    return cal


# ── main simulator ──────────────────────────────────────────────────────────
def simulate(df: pd.DataFrame, n_ahead: int = FORECAST_CANDLES, n_paths: int = MC_PATHS, seed_key: str = "", tf: str | None = None,
             live: float | None = None, forming: dict | None = None, view: float = 0.0, calibrated: bool = True, adj: dict | None = None) -> dict | None:
    """Frozen-per-bar wrapper: same closed bar -> same projected candles (unless the live price broke the cone, see FREEZE)."""
    if not FREEZE or df is None or len(df) < 40 or not seed_key:
        return _simulate_raw(df, n_ahead, n_paths, seed_key, tf, live, forming, view, calibrated, adj)
    ms_last = int(_open_ms(df)[-1])
    key = (seed_key, ms_last, int(n_ahead), int(n_paths), tf or "", bool(calibrated))
    now = time.time()
    with _SIM_LOCK:
        hit = _SIM.get(key)
    if hit:
        sim = hit["sim"]
        broke = False
        if live and live > 0 and hit["rev"] < REVISE_MAX and now - hit["made"] >= REVISE_GAP_S:
            lo0, hi0 = np.percentile(sim["closes"][:, 0], REVISE_BAND)
            broke = live < lo0 or live > hi0
        if not broke:
            out = dict(sim)
            if forming and sim.get("fm") and int(forming.get("t") or 0) == int(sim["fm"]["t"]):      # the real forming candle keeps its real extremes
                fm = dict(sim["fm"])
                fm["high"], fm["low"] = max(fm["high"], float(forming.get("high") or fm["high"])), min(fm["low"], float(forming.get("low") or fm["low"]))
                out["fm"] = fm
            out["frozen"] = {"origin": ms_last, "made": hit["made"], "revisions": hit["rev"], "age_s": int(now - hit["made"]), "revised_now": False}
            return out
        rev = hit["rev"] + 1
    else:
        rev = 0
    sim = _simulate_raw(df, n_ahead, n_paths, seed_key, tf, live, forming, view, calibrated, adj)
    if sim is None:
        return None
    sim["frozen"] = {"origin": ms_last, "made": now, "revisions": rev, "age_s": 0, "revised_now": rev > 0}
    with _SIM_LOCK:
        if len(_SIM) > _SIM_MAX:
            for k_ in sorted(_SIM, key=lambda q: _SIM[q]["made"])[:_SIM_MAX // 4]:
                _SIM.pop(k_, None)
        _SIM[key] = {"sim": sim, "made": now, "rev": rev}
    return sim


def _simulate_raw(df: pd.DataFrame, n_ahead: int = FORECAST_CANDLES, n_paths: int = MC_PATHS, seed_key: str = "", tf: str | None = None,
                  live: float | None = None, forming: dict | None = None, view: float = 0.0, calibrated: bool = True, adj: dict | None = None) -> dict | None:
    """Paths of the next `n_ahead` candles. `df` = CLOSED candles. `forming` = {t, open, high, low} of the candle forming now (optional)."""
    if df is None or len(df) < 40:
        return None
    ms = _open_ms(df)
    tf, tfms = _tf_ms(df, tf, ms)
    F = _features(df, tf, ms)
    n = F["n"]
    cal = calibrate(F, tf, tfms, seed_key) if (calibrated and n >= 120) else _default_cal(n)
    cal = _adapt(cal, adj)
    M = _build(F, n, tf)
    ms_last = int(ms[-1])
    last_close = float(F["c"][-1])
    fm, rem = None, None
    if forming and int(forming.get("t") or 0) == ms_last + tfms:
        el = (time.time() * 1000.0 - float(forming["t"])) / tfms
        rem = float(np.clip(1.0 - el, 0.03, 1.0))
        fm = {k: float(forming[k]) for k in ("open", "high", "low") if forming.get(k) is not None}
        fm["t"] = int(forming["t"])
        if len(fm) < 4 or fm["open"] <= 0:
            fm, rem = None, None
    start = float(live) if (fm and live and live > 0) else (float(forming.get("close")) if (fm and forming.get("close")) else last_close)
    ref = start if fm else last_close
    seed = zlib.crc32(f"{seed_key}|{ms_last}".encode()) & 0x7FFFFFFF
    rng = np.random.default_rng(seed)
    bk_f = _bucket(ms_last + tfms * (np.arange(n_ahead) + 1), tf)
    vcur = vs_curve(float(cal.get("vs3", cal["vs"])), float(cal["vs"]), n_ahead)
    pth = _paths(M, bk_f, n_ahead, n_paths, rng, vcur, cal["ds"], start=start, rem=rem)
    opens, highs, lows, closes, logp = pth["opens"], pth["highs"], pth["lows"], pth["closes"], pth["logp"]
    q = cal.get("quality")
    lam = float(np.clip(view, -1, 1)) * LAMBDA_MAX * (0.5 + 0.5 * (0.6 if q is None else q))
    w = _tilt_weights(logp[:, -1] - np.log(start), lam)
    steps = np.arange(n_ahead)
    sig_i = np.sqrt(M["var0"]) * vcur * M["prof"][bk_f]
    sig_i[0] *= np.sqrt(rem) if rem is not None else 1.0
    med = _wq(logp, w, [50])[0]
    cs = np.cumsum(sig_i ** 2)
    d = (((logp - med[None, :]) ** 2) / (cs[None, :] + 1e-18)).sum(axis=1)
    step_ret = np.diff(np.concatenate([np.full((n_paths, 1), np.log(start)), logp], axis=1), axis=1)
    rough = step_ret.std(axis=1) / (sig_i.mean() + 1e-12)
    rng_rel = ((highs - lows) / np.maximum(closes, 1e-12)).mean(axis=1)
    tex = rng_rel / (float(np.median(rng_rel)) + 1e-12)
    cand = np.argsort(d)[:max(12, n_paths // 8)]
    # per-candle direction of the calibrated distribution: the DISPLAYED typical path must agree with it wherever there is an edge
    prev_c = np.concatenate([np.full((n_paths, 1), ref), closes[:, :-1]], axis=1)
    p_up = np.array([_wm((closes[:, j] > prev_c[:, j]).astype(float), w) for j in range(n_ahead)])
    dv = p_up - 0.5
    wt = np.abs(dv) * (np.abs(dv) >= 0.012)
    if wt.sum() > 1e-9:
        match = ((closes[cand] > prev_c[cand]) == (dv > 0)[None, :])
        agree = (match * wt[None, :]).sum(axis=1) / wt.sum()
    else:
        agree = np.full(len(cand), 0.5)
    pick = int(cand[np.argmin(np.abs(rough[cand] - 1.0) + np.abs(tex[cand] - 1.0) + DIR_PICK_W * (1.0 - agree))])
    return {"last": ref, "last_close": last_close, "sigma": float(sig_i[min(1, n_ahead - 1)] if rem is not None else sig_i[0]), "n": n_ahead, "opens": opens, "highs": highs,
            "lows": lows, "closes": closes, "pick": pick, "atr": M["atr"], "mu": M["mu0"] * cal["ds"], "ema21": M["ema21"], "w": w, "cal": cal, "fm": fm, "rem": rem,
            "tf": tf, "lam": lam, "view": float(np.clip(view, -1, 1)), "tfms": tfms, "ms_last": ms_last, "prof_now": float(M["prof"][bk_f[min(1, n_ahead - 1)]])}


def _stage_sim(sim: dict, side: str, entry: float, stop: float, tps: tuple, fr=PARTIALS) -> dict:
    """Vectorised replay of the paper-exchange exit logic on every simulated path.
    Conservative: if stop and a target are inside the same candle, the stop is assumed first."""
    H, L, C = sim["highs"], sim["lows"], sim["closes"]
    w = sim.get("w")
    P, N = C.shape
    d = 1.0 if side == "LONG" else -1.0
    risk = abs(entry - stop)
    if risk <= 0:
        return {}
    r_of = [d * (tp - entry) / risk for tp in tps]
    alive = np.ones(P, bool)
    stage = np.zeros(P, int)
    R = np.zeros(P)
    first_tp1 = np.full(P, -1); first_tp2 = np.full(P, -1); first_tp3 = np.full(P, -1); first_stop = np.full(P, -1)
    hit1 = np.zeros(P, bool); hit2 = np.zeros(P, bool); hit3 = np.zeros(P, bool); stopped0 = np.zeros(P, bool)
    for i in range(N):
        if side == "LONG":
            adverse = np.where(stage >= 1, L[:, i] <= entry, L[:, i] <= stop)
            fav = [H[:, i] >= tp for tp in tps]
        else:
            adverse = np.where(stage >= 1, H[:, i] >= entry, H[:, i] >= stop)
            fav = [L[:, i] <= tp for tp in tps]
        hs = alive & adverse
        stopped0 |= hs & (stage == 0)
        first_stop = np.where(hs & (stage == 0) & (first_stop < 0), i, first_stop)
        R += np.where(hs & (stage == 0), -1.0, 0.0)
        alive &= ~hs
        m = alive & (stage == 0) & fav[0]
        R += np.where(m, fr[0] * r_of[0], 0.0); first_tp1 = np.where(m & (first_tp1 < 0), i, first_tp1)
        hit1 |= m; stage = np.where(m, 1, stage)
        m = alive & (stage == 1) & fav[1]
        R += np.where(m, fr[1] * r_of[1], 0.0); first_tp2 = np.where(m & (first_tp2 < 0), i, first_tp2); hit2 |= m; stage = np.where(m, 2, stage)
        m = alive & (stage == 2) & fav[2]
        R += np.where(m, fr[2] * r_of[2], 0.0); first_tp3 = np.where(m & (first_tp3 < 0), i, first_tp3); hit3 |= m; stage = np.where(m, 3, stage); alive &= ~m
    rem = np.where(stage == 0, 1.0, np.where(stage == 1, 1 - fr[0], np.where(stage == 2, 1 - fr[0] - fr[1], 0.0)))
    R += np.where(alive, rem * d * (C[:, -1] - entry) / risk, 0.0)
    ev = _wm(R, w)
    var = float(np.average((R - ev) ** 2, weights=w)) + 1e-9 if w is not None else float(R.var()) + 1e-9

    def _med(a):
        a = a[a >= 0]
        return int(np.median(a)) + 1 if len(a) else None
    t1 = first_tp1[first_tp1 >= 0]
    return {"t_tp2": _med(first_tp2), "t_tp3": _med(first_tp3), "t_stop": _med(first_stop), "horizon": int(N), "p_tp1": round(_wm(hit1.astype(float), w), 3),
            "p_tp2": round(_wm(hit2.astype(float), w), 3), "p_tp3": round(_wm(hit3.astype(float), w), 3), "p_stop": round(_wm(stopped0.astype(float), w), 3),
            "p_open": round(_wm((alive & (stage == 0)).astype(float), w), 3), "p_win": round(_wm((R > 0).astype(float), w), 3), "ev_r": round(ev, 3),
            "med_r": round(_wq1(R, w, 50), 3), "worst_r": round(_wq1(R, w, 5), 3), "best_r": round(_wq1(R, w, 95), 3),
            "kelly": round(float(np.clip(ev / var, 0, 1)), 3), "t_tp1": int(np.median(t1)) + 1 if len(t1) else None, "r_tp": [round(x, 2) for x in r_of]}


def _cut(sim: dict, h: int) -> dict:
    return dict(sim, n=h, opens=sim["opens"][:, :h], highs=sim["highs"][:, :h], lows=sim["lows"][:, :h], closes=sim["closes"][:, :h])


def level_probs(sim: dict | None, side: str, levels: dict | None) -> dict | None:
    if not sim or side not in ("LONG", "SHORT") or not levels:
        return None
    try:
        e, s = float(levels["entry"]), float(levels["stop"])
        tps = (float(levels["tp1"]), float(levels["tp2"]), float(levels["tp3"]))
    except (KeyError, TypeError, ValueError):
        return None
    h = max(4, min(int(sim["n"]), EDGE_HORIZON))
    return _stage_sim(_cut(sim, h), side, e, s, tps) or None


def level_check(edge: dict | None) -> dict | None:
    """Reality check of the signal's own levels against the simulated paths (what a trader needs to know before clicking)."""
    if not edge:
        return None
    notes: list[str] = []
    h = edge.get("horizon")
    if edge.get("p_tp1") is not None and edge["p_tp1"] < 0.35:
        notes.append(f"احتمال رسیدن به هدف ۱ در {h} کندل فقط {edge['p_tp1'] * 100:.0f}٪ است")
    if edge.get("p_stop", 0) > 0.6:
        notes.append(f"احتمال برخورد به حدضرر {edge['p_stop'] * 100:.0f}٪ است؛ حدضرر داخل نویز معمول قرار دارد")
    if edge.get("p_tp3", 1) < 0.08:
        notes.append("هدف ۳ در این افق عملاً دور از دسترس است؛ هدف‌های ۱ و ۲ واقع‌بینانه‌ترند")
    if edge.get("ev_r") is not None and edge["ev_r"] < 0:
        notes.append(f"امید ریاضی این طرح در شبیه‌سازی منفی است ({edge['ev_r']:+.2f}R)")
    ev, p1 = edge.get("ev_r") or 0.0, edge.get("p_tp1") or 0.0
    grade = "A" if ev > 0.25 and p1 >= 0.55 else "B" if ev > 0.1 else "C" if ev > 0 else "D"
    return {"grade": grade, "notes": notes}


def _plan_opt(sim: dict, side: str, plan_ctx: dict | None) -> dict | None:
    if not plan_ctx or side not in ("LONG", "SHORT"):
        return None
    try:
        from app.analysis import planner
        px = float(sim["last"])
        atr = float(plan_ctx.get("atr") or sim.get("atr") or 0)
        if atr <= 0:
            return None
        res = planner.run(_cut(sim, min(int(sim["n"]), 32)), side, px, atr, plan_ctx.get("ind") or {}, plan_ctx.get("ex") or {}, plan_ctx.get("zones") or [])
    except Exception:                                                     # noqa: BLE001
        return None
    keep = ("name", "mode", "p", "stop", "stop_name", "tp1", "tp2", "tp3", "p_fill", "p_tp1", "p_tp2", "p_tp3", "p_stop", "ev_r", "win", "t_fill", "t_tp1",
            "risk_pct", "dist_atr", "cost_r", "worst", "best")
    ren = {"worst": "r10", "best": "r90"}                                  # percentile outcomes in R (avoid a confusing nested "best")
    slim = lambda row: {ren.get(k, k): (float(row[k]) if isinstance(row.get(k), (np.floating,)) else row.get(k)) for k in keep if k in row}
    return {"side": side, "best": slim(res["best"]) if res.get("best") else None, "rows": [slim(r) for r in (res.get("rows") or [])[:4]], "note": res.get("note")}


def _pack(sim: dict) -> dict:
    C, H, L, O = sim["closes"], sim["highs"], sim["lows"], sim["opens"]
    last, n, w, fm = sim["last"], sim["n"], sim.get("w"), sim.get("fm")
    q = _wq(C, w, QS)
    pu_stat = float(np.mean(C[:, -1] > last))
    prob_up = _wm((C[:, -1] > last).astype(float), w)
    step_prob = np.array([_wm((C[:, j] > last).astype(float), w) for j in range(n)])
    prev = np.concatenate([np.full((C.shape[0], 1), last), C[:, :-1]], axis=1)          # per-candle direction: P(close_j > close_{j-1}), j=0 vs the live price
    step_dir = np.array([_wm((C[:, j] > prev[:, j]).astype(float), w) for j in range(n)])
    p = sim["pick"]
    candles = [{"step": i + 1, "open": _r(O[p, i]), "close": _r(C[p, i]), "high": _r(H[p, i]), "low": _r(L[p, i])} for i in range(n)]
    if fm:                                                                # candle 0 = the REAL forming candle completed by the simulated remainder
        c0 = candles[0]
        c0["open"] = _r(fm["open"]); c0["high"] = _r(max(fm["high"], c0["high"])); c0["low"] = _r(min(fm["low"], c0["low"]))
    ret = (C[:, -1] / last - 1) * 100
    lo_e, hi_e = _wq1(ret, w, 1), _wq1(ret, w, 99)
    if hi_e - lo_e < 1e-9:
        lo_e, hi_e = lo_e - 0.5, hi_e + 0.5
    edges = np.linspace(lo_e, hi_e, 26)
    counts, _ = np.histogram(np.clip(ret, lo_e, hi_e), bins=edges, weights=w)
    return {"candles": candles, "bands": {k: [_r(x) for x in row] for k, row in zip(QN, q)}, "prob_up": prob_up, "prob_up_stat": pu_stat, "step_dir": step_dir,
            "sigma_pct": sim["sigma"] * 100, "step_prob": step_prob, "hist": {"edges": [round(float(x), 3) for x in edges], "counts": [round(float(c), 2) for c in counts]},
            "range": {"hi": _r(np.median(H.max(axis=1))), "lo": _r(np.median(L.min(axis=1)))},
            "p_up10": round(_wm((ret > 1.0).astype(float), w), 3), "p_dn10": round(_wm((ret < -1.0).astype(float), w), 3)}


def monte_carlo(df: pd.DataFrame, n_ahead: int = FORECAST_CANDLES, n_paths: int = MC_PATHS, seed_key: str = "") -> dict | None:
    sim = simulate(df, n_ahead, n_paths, seed_key)
    return _pack(sim) if sim else None


def forecast_summary(df: pd.DataFrame, signal_side: str, n_ahead: int = FORECAST_CANDLES, seed_key: str = "", levels: dict | None = None, *,
                     tf: str | None = None, live: float | None = None, forming: dict | None = None, view: float = 0.0, plan_ctx: dict | None = None, adj: dict | None = None) -> dict[str, Any]:
    sim = simulate(df, n_ahead=n_ahead, seed_key=seed_key, tf=tf, live=live, forming=forming, view=view, adj=adj)
    if not sim:
        return {"direction": "neutral", "expected_move_pct": 0.0, "alignment": "neutral", "candles": [], "prob_up": 0.5, "prob_up_stat": 0.5,
                "confidence": 0.0, "bands": {}, "cone": {}, "n": n_ahead, "step_prob": [], "hist": {}, "range": {}, "edge": None, "engine": ENGINE}
    mc = _pack(sim)
    cal = sim["cal"]
    s = float(cal.get("dir_shrink") or 0.7)
    shr = lambda x: 0.5 + s * (float(x) - 0.5)
    last = sim["last"]
    b = mc["bands"]
    end = b["p50"][-1]
    move = (end - last) / last * 100
    pu, pu_stat = shr(mc["prob_up"]), shr(mc["prob_up_stat"])
    direction = "bullish" if pu >= 0.55 else "bearish" if pu <= 0.45 else "sideways"
    if signal_side == "LONG" and direction == "bullish": al = "aligned"
    elif signal_side == "SHORT" and direction == "bearish": al = "aligned"
    elif signal_side == "WAIT": al = "neutral"
    else: al = "divergent"
    edge = level_probs(sim, signal_side, levels)
    out = {"direction": direction, "expected_move_pct": round(move, 3), "prob_up": round(pu, 3), "prob_up_stat": round(pu_stat, 3), "prob_up_raw": round(mc["prob_up_stat"], 3),
           "confidence": round(min(1.0, abs(pu - 0.5) * 2.2), 3), "alignment": al, "sigma_pct": round(mc["sigma_pct"], 3),
           "candles": mc["candles"], "bands": b, "n": n_ahead, "step_prob": [round(shr(x), 3) for x in mc["step_prob"]], "step_dir": [round(shr(x), 3) for x in mc["step_dir"]], "hist": mc["hist"],
           "range": mc["range"], "p_up10": mc["p_up10"], "p_dn10": mc["p_dn10"], "cone": {"upper": max(b["p90"]), "lower": min(b["p10"]), "mid": end},
           "edge": edge, "level_check": level_check(edge), "engine": ENGINE, "ref_price": _r(last), "frozen": sim.get("frozen"),
           "cal": cal, "view": {"value": round(sim["view"], 3), "lambda": round(sim["lam"], 3), "src": "همسویی تایم‌فریم‌های بالاتر"},
           "model": {"vol_scale": cal["vs"], "drift_scale": cal["ds"], "dir_shrink": cal["dir_shrink"], "season_factor": round(sim["prof_now"], 3),
                     "garch": [GARCH_A, GARCH_B], "block_p": BLOCK_P, "paths": int(sim["closes"].shape[0]), "forming_anchored": bool(sim["fm"]),
                     "forming_remaining": None if sim["rem"] is None else round(sim["rem"], 3)}}
    po = _plan_opt(sim, signal_side, plan_ctx)
    if po:
        out["plan_opt"] = po
    return out


# ── time stamping (every future candle carries its own open/close time) ─────
def stamp_fc_times(fc: dict | None, last_open_ms: int | None, tf: str = "1h") -> dict | None:
    """Give each projected candle its open/close time.

    `last_open_ms` MUST be the open time of the LAST CLOSED candle that the projection was built on
    (the first projected candle is the one that opens right after it)."""
    if not fc or not isinstance(fc, dict):
        return fc
    ms = TF_MS.get(tf, 3_600_000)
    candles = fc.get("candles") or []
    if not candles:
        return fc
    base = int(last_open_ms or 0)
    if base <= 0:
        base = (int(time.time() * 1000) // ms - 1) * ms
    out = []
    for i, c in enumerate(candles):
        cc = dict(c) if isinstance(c, dict) else {"close": c}
        cc["t"] = base + ms * (i + 1)
        cc["t_close"] = cc["t"] + ms
        out.append(cc)
    fc = dict(fc)
    fc["candles"] = out
    fc["band_t"] = [c["t"] for c in out]
    return fc


def attach_validity(fc: dict | None, tf: str = "1h", n_ahead: int | None = None) -> dict | None:
    """Explicit validity window of a projection: it starts when the last closed candle ended and expires
    when the projected horizon is over. Also tells how far ahead the *trade* statistics reach."""
    if not fc or not isinstance(fc, dict):
        return fc
    ms = TF_MS.get(tf, 3_600_000)
    cs = fc.get("candles") or []
    n = int(n_ahead or len(cs) or 8)
    fc = dict(fc)
    fc["tf"] = tf
    cur = bool(cs and cs[0].get("current"))
    if cs and cs[0].get("t"):
        fc["valid_from"] = int(cs[1 if cur and len(cs) > 1 else 0]["t"])          # first FUTURE candle
        fc["valid_until"] = int(cs[-1]["t_close"])
    else:
        now = int(time.time() * 1000)
        fc["valid_from"], fc["valid_until"] = now, now + ms * n
    fc["valid_bars"] = n
    fc["bar_ms"] = ms
    trade_bars = min(n, EDGE_HORIZON)
    fc["edge_until"] = int((cs[0]["t"] if cs and cs[0].get("t") else fc["valid_from"]) + ms * trade_bars)
    fc["edge_bars"] = trade_bars
    fc["valid_label"] = f"پیش‌بینی {n} کندل {tf} آینده"
    return fc


def signal_timing(tf: str, last_open_ms: int | None, edge: dict | None = None) -> dict:
    """Time block of a signal: which candle it was computed on, when it becomes stale and when the levels are expected to be reached."""
    ms = TF_MS.get(tf, 3_600_000)
    if not last_open_ms:
        last_open_ms = (int(time.time() * 1000) // ms - 1) * ms
    as_of_close = int(last_open_ms) + ms                       # the moment the analysed candle closed
    bars = SIGNAL_VALID_BARS.get(tf, 4)
    out = {"tf": tf, "bar_ms": ms, "last_open": int(last_open_ms), "as_of": as_of_close, "next_close": as_of_close + ms,
           "valid_from": as_of_close, "valid_bars": bars, "valid_until": as_of_close + ms * bars}
    if edge:
        for k, key in (("tp1", "t_tp1"), ("tp2", "t_tp2"), ("tp3", "t_tp3"), ("stop", "t_stop")):
            b = edge.get(key)
            out[f"eta_{k}"] = int(as_of_close + ms * b) if b else None
        out["eta_basis"] = "میانهٔ شبیه‌سازی (مسیرهایی که به آن سطح رسیدند)"
    return out


def _last_open_ms(df) -> int | None:
    try:
        t = df["open_time"].iloc[-1]
        return int(t.timestamp() * 1000)
    except Exception:                                            # noqa: BLE001
        return None


def build_forecast(df: pd.DataFrame, side: str, tf: str, symbol: str, levels: dict | None = None, n_ahead: int = FORECAST_CANDLES, *,
                   live: float | None = None, forming: dict | None = None, view: float = 0.0, plan_ctx: dict | None = None, adj: dict | None = None) -> dict:
    """forecast_summary + exact candle times + validity window. `df` must hold CLOSED candles only."""
    _t0 = time.time()
    fc = forecast_summary(df, side, n_ahead=n_ahead + 1, seed_key=f"{symbol}{tf}", levels=levels, tf=tf, live=live, forming=forming, view=view, plan_ctx=plan_ctx, adj=adj)     # +1: the candle that is forming right now
    fc = stamp_fc_times(fc, _last_open_ms(df), tf)
    if fc.get("candles"):
        cs = [dict(c, step=i, current=(i == 0)) for i, c in enumerate(fc["candles"])]
        fc["candles"] = cs
    fc["n_future"] = n_ahead
    fc = attach_validity(fc, tf, n_ahead)
    fc["timing"] = signal_timing(tf, _last_open_ms(df), fc.get("edge"))
    try:
        from app import core
        core.record("forecast", (time.time() - _t0) * 1000, True)
    except Exception:                                            # noqa: BLE001
        pass
    return fc


# ── coherence with the central intelligence ─────────────────────────────────
def coherence(fcs: dict[str, dict], pub_side: str, ptf: str | None = None) -> dict:
    """How well do the statistical projections of ALL timeframes support the side the governor published?
    Each timeframe is weighted by its structural weight and by its own measured reliability."""
    num = den = 0.0
    agree: list[str] = []
    against: list[str] = []
    d = 1.0 if pub_side == "LONG" else -1.0 if pub_side == "SHORT" else 0.0
    for tf, f in (fcs or {}).items():
        if not f or not f.get("candles"):
            continue
        pu = f.get("prob_up_stat", f.get("prob_up"))
        if not isinstance(pu, (int, float)):
            continue
        q = ((f.get("cal") or {}).get("quality"))
        wt = TF_WEIGHT.get(tf, 0.2) * (0.5 + 0.5 * (0.6 if q is None else float(q)))
        lean = (float(pu) - 0.5) * 2.0
        num += wt * lean
        den += wt
        if d and abs(lean) >= 0.1:
            (agree if lean * d > 0 else against).append(tf)
    lean = num / den if den else 0.0
    score = d * lean if d else 0.0
    notes: list[str] = []
    if d:
        if score <= -0.15:
            notes.append("پیش‌بینی آماری چند تایم‌فریم برخلاف حکم منتشرشده است؛ اندازهٔ پوزیشن را کم کنید یا منتظر تأیید بمانید")
        elif score >= 0.15:
            notes.append("پیش‌بینی آماری با حکم منتشرشده هم‌جهت است")
        else:
            notes.append("پیش‌بینی آماری خنثی است؛ حکم بیشتر به تحلیل ساختاری تکیه دارد")
        if against and not agree:
            notes.append("تایم‌فریم‌های مخالف: " + "، ".join(against))
    label = "neutral" if not d else "aligned" if score >= 0.15 else "divergent" if score <= -0.15 else "neutral"
    return {"score": round(score, 3), "lean": round(lean, 3), "label": label, "agree": agree, "against": against, "notes": notes, "primary": ptf}
