"""Professional risk management engine.

What real prop desks / quant funds compute before publishing a trade:
  • Kelly Criterion position sizing (full + fractional Kelly with edge cap)
  • Risk of Ruin (Monte Carlo + analytical approximation)
  • Optimal f (Ralph Vince) for the strategy's R-distribution
  • Expectancy + system quality number (SQN, Van Tharp)
  • Portfolio heat (sum of open risk as % of equity)
  • Maximum adverse excursion (MAE) tolerance
  • Dynamic position sizing from ATR, account equity, correlation-adjusted
  • Drawdown-based size de-risking (anti-martingale)
  • Trade validity window (edge decay estimate)

Inputs: the strategy's historical R-multiples (from backtest), account equity,
        current risk per trade, ATR, and concurrent open positions.
"""
from __future__ import annotations
from typing import Any
import math
import numpy as np


# ── Kelly Criterion ──────────────────────────────────────────────────────────
def kelly_fraction(wins: np.ndarray, losses: np.ndarray) -> dict[str, Any]:
    """Full Kelly + fractional Kelly (quarter, eighth) with edge cap.

    Kelly f* = W - (1-W)/R  where W = win rate, R = avg win / avg loss.
    Real systems use fractional Kelly (typically 0.25-0.5) because:
      - parameter uncertainty
      - non-stationary edge
      - drawdown control
    """
    if len(wins) == 0 or len(losses) == 0:
        return {"full": 0.0, "quarter": 0.0, "eighth": 0.0, "win_rate": 0.0,
                "payoff_ratio": 0.0, "edge": 0.0, "note": "داده کافی نیست"}
    w = len(wins) / (len(wins) + len(losses))
    avg_win = float(np.mean(wins)) if len(wins) else 0.0
    avg_loss = float(np.mean(np.abs(losses))) if len(losses) else 0.0
    if avg_loss < 1e-9:
        return {"full": 0.0, "quarter": 0.0, "eighth": 0.0, "win_rate": w,
                "payoff_ratio": float("inf"), "edge": 0.0, "note": "ضرر نمونه نداریم"}
    R = avg_win / avg_loss
    f_full = w - (1 - w) / R
    f_full = max(0.0, min(0.25, f_full))  # cap at 25% — never risk more than a quarter per trade
    return {
        "full": round(f_full, 4),
        "half": round(f_full * 0.5, 4),
        "quarter": round(f_full * 0.25, 4),
        "eighth": round(f_full * 0.125, 4),
        "win_rate": round(w, 3),
        "payoff_ratio": round(R, 3),
        "avg_win_r": round(avg_win, 3),
        "avg_loss_r": round(avg_loss, 3),
        "edge": round(f_full, 4),
        "note": "Kelly کامل ریسک بالاست؛ quarter-Kelly توصیه‌شده" if f_full > 0.1 else "لبه مثبت ضعیف",
    }


# ── Risk of Ruin (analytical + Monte Carlo) ─────────────────────────────────
def risk_of_ruin(win_rate: float, payoff_ratio: float, risk_pct: float,
                 ruin_threshold: float = 0.5, n_sims: int = 5000) -> dict[str, Any]:
    """Probability of losing `ruin_threshold` of equity.
    Analytical (for even-R): RoR = ((1 - edge) / (1 + edge))^units
    Monte Carlo: simulate equity curve with the given win rate and payoff."""
    if win_rate <= 0 or win_rate >= 1 or payoff_ratio <= 0 or risk_pct <= 0:
        return {"analytical": 0.0, "monte_carlo": 0.0, "safe": True}
    # analytical (approximate)
    edge = win_rate * (1 + payoff_ratio) - 1
    if edge <= 0:
        analytical = 1.0  # negative-edge system → guaranteed ruin eventually
    else:
        # units of risk in the ruin buffer
        units = -math.log(ruin_threshold) / risk_pct
        analytical = float(((1 - edge) / (1 + edge)) ** units)
    analytical = min(1.0, max(0.0, analytical))
    # Monte Carlo
    rng = np.random.default_rng(42)
    n_trades = 200
    ruined = 0
    for _ in range(n_sims):
        eq = 1.0
        for _ in range(n_trades):
            r = risk_pct * (payoff_ratio if rng.random() < win_rate else -1.0)
            eq += r
            if eq <= 1 - ruin_threshold:
                ruined += 1
                break
    mc = ruined / n_sims
    return {
        "analytical": round(analytical, 4),
        "monte_carlo": round(mc, 4),
        "safe": bool(mc < 0.05),
        "edge": round(edge, 4),
        "note": "روین کم" if mc < 0.05 else "روین بالا — اندازه را کاهش دهید" if mc < 0.2 else "خطرناک — استراتژی متوقف شود",
    }


# ── System Quality Number (Van Tharp) ───────────────────────────────────────
def system_quality_number(r_multiples: np.ndarray) -> dict[str, Any]:
    """SQN = sqrt(n) * mean(R) / std(R). Van Tharp's grading:
       < 1.6 — poor, 1.6-1.9 below avg, 2.0-2.4 average, 2.5-2.9 good,
       3.0-5.0 excellent, 5.0+ superb."""
    n = len(r_multiples)
    if n < 10:
        return {"sqn": 0.0, "grade": "نامشخص", "n": n, "note": "نمونه کافی نیست"}
    mean_r = float(np.mean(r_multiples))
    std_r = float(np.std(r_multiples, ddof=1)) if n > 1 else 0.0
    if std_r < 1e-9:
        return {"sqn": 0.0, "grade": "نامشخص", "n": n, "expectancy_r": round(mean_r, 3)}
    sqn = math.sqrt(n) * mean_r / std_r
    if sqn < 1.6:
        grade = "ضعیف"
    elif sqn < 2.0:
        grade = "زیر متوسط"
    elif sqn < 2.5:
        grade = "متوسط"
    elif sqn < 3.0:
        grade = "خوب"
    elif sqn < 5.0:
        grade = "عالی"
    else:
        grade = "برتر"
    return {
        "sqn": round(sqn, 2), "grade": grade, "n": n,
        "expectancy_r": round(mean_r, 3), "std_r": round(std_r, 3),
    }


# ── Optimal f (Ralph Vince) ─────────────────────────────────────────────────
def optimal_f(r_multiples: np.ndarray) -> dict[str, Any]:
    """Find the fixed fraction that maximizes terminal wealth (TWR).
    Capped at 0.25 (25%) — going higher guarantees eventual ruin in practice."""
    if len(r_multiples) < 10:
        return {"f": 0.0, "twr": 1.0, "note": "نمونه کافی نیست"}
    rs = np.asarray(r_multiples, dtype=float)
    worst = float(rs.min())
    if worst >= 0:
        return {"f": 0.25, "twr": 1.0, "note": "هیچ ضرری در نمونه نیست"}
    # search 0..0.25 in 0.005 steps
    best_f, best_twr = 0.0, 1.0
    for f in np.arange(0.005, 0.255, 0.005):
        twr = 1.0
        for r in rs:
            twr *= (1 + f * (-r / worst))
        if twr > best_twr:
            best_twr, best_f = twr, float(f)
    return {"f": round(best_f, 4), "twr": round(best_twr, 3),
            "note": f"بهترین f = {best_f:.1%}" if best_f > 0 else "هیچ f سودمندی نیست"}


# ── Position sizing ──────────────────────────────────────────────────────────
def position_size(equity: float, entry: float, stop: float, atr: float,
                  kelly_f: float = 0.0, portfolio_heat_pct: float = 0.0,
                  max_risk_per_trade: float = 0.02, max_portfolio_heat: float = 0.06,
                  correlation_factor: float = 1.0) -> dict[str, Any]:
    """Compute position size from risk model.
    Inputs:
      equity: account equity (USDT)
      entry/stop: planned levels
      atr: current ATR (for vol-scaled sizing)
      kelly_f: Kelly fraction (0..0.25), 0 = flat risk
      portfolio_heat_pct: current open risk as % of equity
      max_risk_per_trade: hard cap on risk per trade (default 2%)
      max_portfolio_heat: hard cap on total open risk (default 6%)
      correlation_factor: 0.5-1.0 to reduce size when correlated positions open
    """
    if equity <= 0 or entry <= 0 or stop <= 0 or entry == stop:
        return {"size_usd": 0.0, "size_pct": 0.0, "risk_usd": 0.0, "note": "ورودی نامعتبر",
                "capped_by": "none"}
    risk_per_unit = abs(entry - stop)
    # base risk: max_risk_per_trade or Kelly-adjusted
    base_risk_pct = max_risk_per_trade
    if kelly_f > 0:
        # use Kelly as the guide but cap by max_risk_per_trade
        base_risk_pct = min(max_risk_per_trade, max(0.005, kelly_f * 0.5))
    # portfolio heat throttle
    remaining_heat = max(0.0, max_portfolio_heat - portfolio_heat_pct)
    capped_risk_pct = min(base_risk_pct, remaining_heat)
    capped_risk_pct *= correlation_factor
    if capped_risk_pct < 0.001:
        return {"size_usd": 0.0, "size_pct": 0.0, "risk_usd": 0.0,
                "note": "بافت پورتفولیو پر است — معامله جدید نباید", "capped_by": "portfolio_heat"}
    risk_usd = equity * capped_risk_pct
    # number of units
    n_units = risk_usd / risk_per_unit
    notional = n_units * entry
    size_pct = notional / equity
    capped_by = "kelly" if kelly_f > 0 and base_risk_pct < max_risk_per_trade else "max_risk"
    if remaining_heat < base_risk_pct:
        capped_by = "portfolio_heat"
    return {
        "size_usd": round(notional, 2),
        "size_pct": round(size_pct, 3),
        "risk_usd": round(risk_usd, 2),
        "risk_pct": round(capped_risk_pct, 4),
        "n_units": round(n_units, 6),
        "capped_by": capped_by,
        "portfolio_heat_after": round(portfolio_heat_pct + capped_risk_pct, 4),
        "note": f"ریسک {capped_risk_pct:.1%} از سرمایه" if capped_risk_pct >= 0.001 else "بدون ورود",
    }


# ── Drawdown-based de-risking (anti-martingale) ─────────────────────────────
def drawdown_scaler(current_drawdown_pct: float) -> float:
    """Reduce position size as drawdown deepens (anti-martingale).
    < 5% DD → full size (1.0)
    5-10% DD → 0.75x
    10-15% DD → 0.5x
    15-20% DD → 0.25x
    > 20% DD → 0 (stop trading)"""
    dd = current_drawdown_pct
    if dd < 5:
        return 1.0
    if dd < 10:
        return 0.75
    if dd < 15:
        return 0.5
    if dd < 20:
        return 0.25
    return 0.0


# ── Full risk assessment for a single trade ─────────────────────────────────
def assess(r_multiples: np.ndarray, equity: float, entry: float, stop: float,
           atr: float, current_drawdown_pct: float = 0.0,
           portfolio_heat_pct: float = 0.0, correlation_factor: float = 1.0) -> dict[str, Any]:
    """Full pre-trade risk assessment combining all models."""
    wins = np.array([r for r in r_multiples if r > 0]) if len(r_multiples) else np.array([])
    losses = np.array([r for r in r_multiples if r <= 0]) if len(r_multiples) else np.array([])
    kelly = kelly_fraction(wins, losses)
    sqn = system_quality_number(r_multiples)
    optf = optimal_f(r_multiples)
    # use kelly quarter as the position-sizing fraction
    kelly_f = kelly.get("quarter", 0.0) or 0.0
    # drawdown scaler
    dd_scale = drawdown_scaler(current_drawdown_pct)
    if dd_scale == 0:
        return {
            "kelly": kelly, "sqn": sqn, "optimal_f": optf,
            "position": {"size_usd": 0.0, "note": "دراو‌داون عمیق — معامله متوقف شد", "capped_by": "drawdown"},
            "risk_of_ruin": risk_of_ruin(kelly.get("win_rate", 0.5), kelly.get("payoff_ratio", 1.0), 0.02),
            "drawdown_scaler": 0.0,
            "verdict": "stop_trading",
        }
    # effective max risk scaled by drawdown
    max_risk = 0.02 * dd_scale
    pos = position_size(equity, entry, stop, atr, kelly_f=kelly_f,
                        portfolio_heat_pct=portfolio_heat_pct,
                        max_risk_per_trade=max_risk, correlation_factor=correlation_factor)
    ror = risk_of_ruin(kelly.get("win_rate", 0.5), kelly.get("payoff_ratio", 1.0),
                       pos.get("risk_pct", 0.02))
    # verdict
    if pos.get("size_usd", 0) <= 0:
        verdict = "no_trade"
    elif ror.get("monte_carlo", 0) > 0.1:
        verdict = "reduce_size"
    elif kelly.get("edge", 0) <= 0:
        verdict = "no_edge"
    else:
        verdict = "ok"
    return {
        "kelly": kelly, "sqn": sqn, "optimal_f": optf, "position": pos,
        "risk_of_ruin": ror, "drawdown_scaler": dd_scale,
        "max_risk_per_trade": round(max_risk, 4),
        "verdict": verdict,
    }
