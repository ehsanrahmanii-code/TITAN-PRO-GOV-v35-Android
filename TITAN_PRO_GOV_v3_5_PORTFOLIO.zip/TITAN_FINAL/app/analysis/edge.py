"""Statistical edge validation + multi-confluence grading.

This is the bridge between raw signals and a publishable trade. A pro desk
never publishes on "indicators look good" — it requires:
  • Statistical edge: t-stat on R-multiples, bootstrap confidence interval
  • Confluence count: how many INDEPENDENT factors agree
  • Edge confidence: Bayesian update from the historical hit rate
  • Expected value in R, with uncertainty band
  • Final edge score: a single calibrated number that the governor gates on

Inputs: signal scores per timeframe, SMC, order-flow, regime, forecast,
        backtest stats. Output: a calibrated edge + grade with full diagnostics.
"""
from __future__ import annotations
from typing import Any
import math
import numpy as np


# ── Bootstrap confidence interval on expectancy ─────────────────────────────
def bootstrap_expectancy(r_multiples: np.ndarray, n_boot: int = 2000, ci: float = 0.95) -> dict[str, Any]:
    """Bootstrap the mean R to get a confidence interval.
    If the lower bound is > 0, the edge is statistically significant."""
    if len(r_multiples) < 10:
        return {"mean": 0.0, "lower": 0.0, "upper": 0.0, "significant": False, "n": len(r_multiples)}
    rng = np.random.default_rng(123)
    n = len(r_multiples)
    boot_means = np.empty(n_boot)
    for i in range(n_boot):
        sample = rng.choice(r_multiples, size=n, replace=True)
        boot_means[i] = sample.mean()
    alpha = (1 - ci) / 2
    lo = float(np.percentile(boot_means, alpha * 100))
    hi = float(np.percentile(boot_means, (1 - alpha) * 100))
    mean = float(r_multiples.mean())
    return {
        "mean": round(mean, 4), "lower": round(lo, 4), "upper": round(hi, 4),
        "significant": bool(lo > 0), "ci": ci, "n": n,
        "note": "لبه معنادار" if lo > 0 else "لبه معنادار نیست" if hi < 0 else "نامشخص",
    }


# ── t-statistic on R-multiples ──────────────────────────────────────────────
def t_stat_edge(r_multiples: np.ndarray) -> dict[str, Any]:
    """One-sample t-test: is mean R significantly > 0?
    t = mean / (std / sqrt(n)). Critical t at 95% (one-sided) ≈ 1.645 for n>30."""
    n = len(r_multiples)
    if n < 5:
        return {"t": 0.0, "p_significant": False, "n": n, "df": 0}
    mean_r = float(np.mean(r_multiples))
    std_r = float(np.std(r_multiples, ddof=1)) if n > 1 else 0.0
    if std_r < 1e-9:
        return {"t": 0.0, "p_significant": False, "n": n, "df": n - 1}
    t = mean_r / (std_r / math.sqrt(n))
    df = n - 1
    # rough p-value via normal approx (good for df > 30)
    crit = 1.645 if df >= 30 else (2.0 if df >= 10 else 2.5)
    return {
        "t": round(t, 3), "p_significant": bool(t > crit), "n": n, "df": df,
        "critical_t": crit, "mean_r": round(mean_r, 3), "std_r": round(std_r, 3),
    }


# ── Confluence counting (independent factors) ───────────────────────────────
CONFLUENCE_FACTORS = [
    "htf_trend",        # 4h + 1d agreement
    "mtf_setup",        # 1h structure
    "ltf_trigger",      # 15m timing
    "momentum",         # RSI/MACD/ADX
    "structure",        # EMA stack, SMC structure
    "volume_flow",      # order flow / volume
    "smc_confluence",   # OB/FVG/sweep alignment
    "regime_fit",       # strategy matches regime
    "forecast",         # Monte-Carlo direction
    "derivatives",      # funding/OI
    "pattern",          # candlestick patterns
    "context",          # broader market
]


def count_confluence(ev: dict[str, float], side: str, threshold: float = 0.15) -> dict[str, Any]:
    """Count how many independent factors support the proposed side."""
    if side not in ("LONG", "SHORT"):
        return {"support": 0, "oppose": 0, "neutral": 0, "score": 0.0, "factors": []}
    support, oppose, neutral = 0, 0, 0
    factors = []
    for k in CONFLUENCE_FACTORS:
        v = float(ev.get(k, 0.0) or 0.0)
        if abs(v) < threshold:
            neutral += 1
            continue
        agrees = (v > 0 and side == "LONG") or (v < 0 and side == "SHORT")
        if agrees:
            support += 1
            factors.append({"k": k, "v": round(v, 3), "side": "support"})
        else:
            oppose += 1
            factors.append({"k": k, "v": round(v, 3), "side": "oppose"})
    total = support + oppose
    score = (support - oppose) / total if total > 0 else 0.0
    return {
        "support": support, "oppose": oppose, "neutral": neutral,
        "score": round(score, 3),
        "unanimity": round(support / total, 3) if total > 0 else 0.0,
        "factors": factors,
    }


# ── Bayesian edge update ────────────────────────────────────────────────────
def bayesian_edge(prior_hit_rate: float, observed_hits: int, observed_total: int,
                  prior_strength: int = 20) -> dict[str, Any]:
    """Beta-Binomial update: prior Beta(a, b) with a+b = prior_strength,
    updated with observed hits/total. Returns posterior mean + credible interval."""
    if observed_total <= 0:
        return {"posterior": prior_hit_rate, "lower": 0.0, "upper": 1.0, "n": 0}
    a = max(1, int(prior_strength * prior_hit_rate))
    b = max(1, prior_strength - a)
    a_post = a + observed_hits
    b_post = b + (observed_total - observed_hits)
    mean = a_post / (a_post + b_post)
    # approximate 95% credible interval via normal
    var = (a_post * b_post) / ((a_post + b_post) ** 2 * (a_post + b_post + 1))
    std = math.sqrt(var)
    lower = max(0.0, mean - 1.96 * std)
    upper = min(1.0, mean + 1.96 * std)
    return {
        "posterior": round(mean, 4), "lower": round(lower, 4), "upper": round(upper, 4),
        "prior": prior_hit_rate, "n": observed_total, "hits": observed_hits,
        "edge_above_50": bool(lower > 0.5),
    }


# ── Composite edge grade ────────────────────────────────────────────────────
def grade_edge(
    ev: dict[str, float],
    side: str,
    backtest_r: np.ndarray | None = None,
    regime_info: dict | None = None,
    forecast_prob: float = 0.5,
    min_support: int = 3,
    min_unanimity: float = 0.6,
) -> dict[str, Any]:
    """The final pre-publish grade combining:
      - confluence count (independent factors)
      - statistical edge (bootstrap CI on backtest R)
      - regime fit (does the strategy apply here?)
      - forecast agreement
      - Bayesian hit-rate posterior
    Returns a calibrated edge in [-1, +1] and a letter grade A+ to F.
    """
    if side not in ("LONG", "SHORT"):
        return {"grade": "—", "edge": 0.0, "publish": False, "reason": "خنثی", "diagnostics": {}}
    conf = count_confluence(ev, side)
    # base edge from confluence
    edge = conf["score"] * 0.5  # ±0.5 from confluence
    diagnostics = {"confluence": conf}
    # statistical edge from backtest
    stat_sig = False
    if backtest_r is not None and len(backtest_r) >= 10:
        bs = bootstrap_expectancy(backtest_r)
        ts = t_stat_edge(backtest_r)
        diagnostics["bootstrap"] = bs
        diagnostics["t_stat"] = ts
        stat_sig = bs["significant"] and ts["p_significant"]
        if stat_sig:
            edge += 0.2 * (1 if side == "LONG" else -1) * (1 if bs["mean"] > 0 else -1)
        else:
            edge -= 0.1  # unproven edge → shrink
    # regime fit
    if regime_info:
        r = regime_info.get("regime", "unknown")
        hint = regime_info.get("strategy_hint", "stay_out")
        applicable, note = True, ""
        if hint == "stay_out":
            edge *= 0.3
            applicable = False
            note = "رژیم نامناسب"
        diagnostics["regime"] = {"regime": r, "applicable": applicable, "note": note,
                                  "edge": regime_info.get("edge", 0.0)}
        # add regime's own directional lean
        edge += 0.15 * float(regime_info.get("edge", 0.0)) * (1 if side == "LONG" else -1)
    # forecast agreement
    fc_agree = (forecast_prob > 0.55 and side == "LONG") or (forecast_prob < 0.45 and side == "SHORT")
    if fc_agree:
        edge += 0.1
    else:
        edge -= 0.05
    diagnostics["forecast_agree"] = fc_agree
    edge = max(-1.0, min(1.0, edge))
    # publish gate: enough support + unanimity + edge above threshold
    publish = (conf["support"] >= min_support and conf["unanimity"] >= min_unanimity
               and abs(edge) >= 0.2 and (stat_sig or conf["support"] >= 5))
    # letter grade
    a = abs(edge)
    if a >= 0.6 and stat_sig:
        grade = "A+"
    elif a >= 0.5 and stat_sig:
        grade = "A"
    elif a >= 0.4:
        grade = "B"
    elif a >= 0.25:
        grade = "C"
    elif a >= 0.15:
        grade = "D"
    else:
        grade = "F"
    if not publish and grade in ("A", "A+", "B"):
        grade = "B-"  # downgrade if not publishable
    reason = []
    if conf["support"] < min_support:
        reason.append(f"پشتیبانی کم ({conf['support']}/{min_support})")
    if conf["unanimity"] < min_unanimity:
        reason.append(f"اجماع ضعیف ({conf['unanimity']:.0%})")
    if not stat_sig and backtest_r is not None and len(backtest_r) >= 10:
        reason.append("لبه آماری معنادار نیست")
    if regime_info and regime_info.get("strategy_hint") == "stay_out":
        reason.append("رژیم بازار نامناسب")
    return {
        "grade": grade, "edge": round(edge, 3), "publish": publish,
        "side": side,
        "support": conf["support"], "oppose": conf["oppose"], "unanimity": conf["unanimity"],
        "stat_significant": stat_sig,
        "reason": " · ".join(reason) if reason else "همه شرایط انتشار برقرار است",
        "diagnostics": diagnostics,
    }
