"""Derivatives & on-chain sentiment integration (Binance Futures).

Pulls real derivatives data from Binance's public Futures endpoints:
  • Funding rate (8h) — positive = longs pay shorts (crowded long)
  • Open Interest — rising OI + rising price = trend confirmation
  • Long/Short ratio (top trader accounts / positions / global)
  • Taker buy/sell volume ratio

All these are CORS-disabled on Binance Futures endpoints in-browser, so
this module runs server-side. It is called from the engine with graceful
degradation — if the network is down or the symbol isn't a perp, we return
neutral.

The composite `bias` is what the governor's `derivatives` evidence channel
reads: > 0 = bullish positioning, < 0 = bearish, but EXTREMES flip
(contrarian) — a funding rate above 0.05% is bearish (longs crowded),
below -0.03% is bullish (shorts crowded).
"""
from __future__ import annotations
from typing import Any
import time
import math

try:
    import requests
except ImportError:  # noqa: BLE001
    requests = None

_FBASE = "https://fapi.binance.com"
_CACHE: dict[str, dict] = {}
_CACHE_TTL = 120.0  # 2 min


def _get(path: str, params: dict | None = None, timeout: float = 4.0) -> dict | list | None:
    if requests is None:
        return None
    try:
        r = requests.get(_FBASE + path, params=params or {}, timeout=timeout)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:  # noqa: BLE001
        return None


# ── Funding rate ────────────────────────────────────────────────────────────
def funding_rate(symbol: str) -> dict[str, Any]:
    """Current funding rate (8h). Contrarian signal at extremes."""
    sym = _norm(symbol)
    cached = _CACHE.get(sym + "|fr")
    if cached and time.time() - cached["ts"] < _CACHE_TTL:
        return cached["v"]
    out = {"rate": 0.0, "next_time": 0, "bias": 0.0, "regime": "neutral"}
    data = _get("/fapi/v1/premiumIndex", {"symbol": sym})
    if isinstance(data, dict) and data.get("lastFundingRate"):
        try:
            rate = float(data["lastFundingRate"])
            out["rate"] = rate
            out["next_time"] = int(data.get("nextFundingTime", 0))
            # contrarian: extreme positive funding = longs crowded = bearish
            if rate > 0.0005:        # > 0.05% per 8h
                out["bias"] = -0.4
                out["regime"] = "longs_crowded"
            elif rate < -0.0003:     # < -0.03%
                out["bias"] = 0.4
                out["regime"] = "shorts_crowded"
            elif rate > 0.0001:
                out["bias"] = -0.1
                out["regime"] = "slight_long"
            elif rate < -0.0001:
                out["bias"] = 0.1
                out["regime"] = "slight_short"
        except (ValueError, KeyError):
            pass
    _CACHE[sym + "|fr"] = {"ts": time.time(), "v": out}
    return out


# ── Open Interest ───────────────────────────────────────────────────────────
def open_interest(symbol: str) -> dict[str, Any]:
    """Open interest (notional). Rising OI + rising price = trend confirm."""
    sym = _norm(symbol)
    cached = _CACHE.get(sym + "|oi")
    if cached and time.time() - cached["ts"] < _CACHE_TTL:
        return cached["v"]
    out = {"oi": 0.0, "bias": 0.0, "note": "n/a"}
    data = _get("/fapi/v1/openInterest", {"symbol": sym})
    if isinstance(data, dict) and data.get("openInterest"):
        try:
            out["oi"] = float(data["openInterest"])
            out["note"] = "OK"
        except (ValueError, KeyError):
            pass
    _CACHE[sym + "|oi"] = {"ts": time.time(), "v": out}
    return out


def open_interest_change(symbol: str, lookback_min: int = 60) -> dict[str, Any]:
    """OI change over the last hour (needs the 5-min OI history endpoint)."""
    sym = _norm(symbol)
    cached = _CACHE.get(sym + "|oich")
    if cached and time.time() - cached["ts"] < _CACHE_TTL:
        return cached["v"]
    out = {"change_pct": 0.0, "bias": 0.0, "note": "n/a"}
    # OI history (5-min bins)
    now_ms = int(time.time() * 1000)
    start = now_ms - lookback_min * 60 * 1000
    data = _get("/futures/data/openInterestHist", {"symbol": sym, "period": "5m",
              "startTime": start, "endTime": now_ms, "limit": 30})
    if isinstance(data, list) and len(data) >= 2:
        try:
            ois = [float(x.get("sumOpenInterest", 0)) for x in data]
            if ois[0] > 0:
                change = (ois[-1] - ois[0]) / ois[0]
                out["change_pct"] = round(change * 100, 2)
                out["bias"] = max(-0.3, min(0.3, change * 5))  # rising OI = bullish bias
                out["note"] = "OK"
        except (ValueError, KeyError, ZeroDivisionError):
            pass
    _CACHE[sym + "|oich"] = {"ts": time.time(), "v": out}
    return out


# ── Long/Short ratio ────────────────────────────────────────────────────────
def long_short_ratio(symbol: str) -> dict[str, Any]:
    """Top trader account long/short ratio. > 1 = more longs."""
    sym = _norm(symbol)
    cached = _CACHE.get(sym + "|ls")
    if cached and time.time() - cached["ts"] < _CACHE_TTL:
        return cached["v"]
    out = {"ratio": 1.0, "long_pct": 50.0, "short_pct": 50.0, "bias": 0.0, "note": "n/a"}
    data = _get("/futures/data/topLongShortAccountRatio", {"symbol": sym, "period": "5m", "limit": 1})
    if isinstance(data, list) and data:
        try:
            ratio = float(data[0].get("longShortRatio", 1.0))
            long_pct = float(data[0].get("longAccount", 0.5)) * 100
            short_pct = float(data[0].get("shortAccount", 0.5)) * 100
            out["ratio"] = round(ratio, 3)
            out["long_pct"] = round(long_pct, 1)
            out["short_pct"] = round(short_pct, 1)
            # contrarian: very long-heavy = bearish, very short-heavy = bullish
            if ratio > 2.5:
                out["bias"] = -0.3
                out["note"] = "long_crowded"
            elif ratio < 0.5:
                out["bias"] = 0.3
                out["note"] = "short_crowded"
            else:
                out["bias"] = max(-0.15, min(0.15, (1.0 - ratio) * 0.2))
                out["note"] = "balanced"
        except (ValueError, KeyError):
            pass
    _CACHE[sym + "|ls"] = {"ts": time.time(), "v": out}
    return out


# ── Taker buy/sell ratio ────────────────────────────────────────────────────
def taker_buy_sell(symbol: str, period: str = "5m", limit: int = 12) -> dict[str, Any]:
    """Recent taker buy vs sell volume ratio."""
    sym = _norm(symbol)
    cached = _CACHE.get(sym + "|tbs")
    if cached and time.time() - cached["ts"] < _CACHE_TTL:
        return cached["v"]
    out = {"ratio": 1.0, "bias": 0.0, "note": "n/a"}
    data = _get("/futures/data/takerlongshortRatio", {"symbol": sym, "period": period, "limit": limit})
    if isinstance(data, list) and data:
        try:
            ratios = [float(x.get("buySellRatio", 1.0)) for x in data]
            avg = sum(ratios) / len(ratios) if ratios else 1.0
            out["ratio"] = round(avg, 3)
            out["bias"] = max(-0.3, min(0.3, (avg - 1.0) * 0.5))
            out["note"] = "buy_pressure" if avg > 1.1 else "sell_pressure" if avg < 0.9 else "balanced"
        except (ValueError, KeyError):
            pass
    _CACHE[sym + "|tbs"] = {"ts": time.time(), "v": out}
    return out


# ── Composite derivatives bias ──────────────────────────────────────────────
def _norm(symbol: str) -> str:
    s = str(symbol or "").upper().replace("/", "").replace("-", "")
    if not s.endswith("USDT"):
        if s.endswith("USD"):
            s = s[:-3] + "USDT"
        else:
            s = s + "USDT"
    return s


def derivatives_context(symbol: str, price_change_pct: float = 0.0) -> dict[str, Any]:
    """All derivatives signals combined into a single bias for the governor.
    `price_change_pct` is the recent price change — used to interpret OI:
    rising OI + rising price = bullish trend confirm.
    rising OI + falling price = bearish trend confirm."""
    fr = funding_rate(symbol)
    oi = open_interest(symbol)
    oich = open_interest_change(symbol)
    ls = long_short_ratio(symbol)
    tbs = taker_buy_sell(symbol)
    parts = []
    bias = 0.0
    if fr["bias"] != 0:
        bias += fr["bias"] * 0.3
        parts.append({"k": "funding", "v": fr["bias"], "t": f"فاندینگ {fr['rate']*100:.4f}٪ ({fr['regime']})"})
    if oich["bias"] != 0:
        # OI change interpreted with price direction
        oi_bias = oich["bias"]
        if price_change_pct < 0:
            oi_bias = -oi_bias  # rising OI + falling price = bearish
        bias += oi_bias * 0.3
        parts.append({"k": "oi", "v": oi_bias, "t": f"OI {oich['change_pct']:+.2f}٪"})
    if ls["bias"] != 0:
        bias += ls["bias"] * 0.25
        parts.append({"k": "ls", "v": ls["bias"], "t": f"L/S {ls['ratio']:.2f} ({ls['note']})"})
    if tbs["bias"] != 0:
        bias += tbs["bias"] * 0.25
        parts.append({"k": "taker", "v": tbs["bias"], "t": f"Taker {tbs['ratio']:.2f} ({tbs['note']})"})
    bias = max(-1.0, min(1.0, bias))
    return {
        "bias": round(bias, 3), "parts": parts,
        "funding": fr, "oi": oi, "oi_change": oich,
        "long_short": ls, "taker": tbs,
        "available": bool(parts),
    }


def clear_cache() -> None:
    _CACHE.clear()
