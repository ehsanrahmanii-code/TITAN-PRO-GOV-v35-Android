"""Market regime detection — statistical, not threshold-based.

Pro desks don't just use "ADX > 25 = trend". They use:
  • Hurst exponent (R/S) — persistence: H>0.5 trending, H<0.5 mean-reverting, H=0.5 random
  • Efficiency Ratio (Kaufman) — directional movement / total path
  • Volatility regime (ATR percentile, GARCH-style vol clustering)
  • Fractal dimension (box-count) — complexity of the series
  • Choppiness index — confirms range vs trend
  • Composite regime label: trend-up / trend-down / range / chop / breakout

These decide which strategy applies: trend-following in trend regimes,
mean-reversion in range regimes, and STAY OUT in chop/random regimes.
"""
from __future__ import annotations
from typing import Any
import numpy as np
import pandas as pd


# ── Hurst exponent (R/S analysis) ───────────────────────────────────────────
def hurst_exponent(series: np.ndarray, max_lag: int = 50) -> float:
    """Estimate Hurst exponent via rescaled range (R/S) analysis.
    H > 0.5 = persistent (trending), H < 0.5 = anti-persistent (mean-reverting),
    H ≈ 0.5 = random walk.
    """
    if len(series) < 30:
        return 0.5
    series = np.asarray(series, dtype=float)
    lags = range(2, min(max_lag, len(series) // 2))
    rs_list = []
    lag_list = []
    for lag in lags:
        chunks = [series[i:i + lag] for i in range(0, len(series) - lag, lag)]
        if not chunks:
            continue
        rs_vals = []
        for chunk in chunks:
            if len(chunk) < 2:
                continue
            mean = chunk.mean()
            dev = chunk - mean
            cumdev = np.cumsum(dev)
            r = float(cumdev.max() - cumdev.min())
            s = float(chunk.std(ddof=1)) if len(chunk) > 1 else 0.0
            if s > 1e-12:
                rs_vals.append(r / s)
        if rs_vals:
            rs_list.append(np.mean(rs_vals))
            lag_list.append(lag)
    if len(lag_list) < 4:
        return 0.5
    log_lags = np.log(lag_list)
    log_rs = np.log(rs_list)
    # slope of log(R/S) vs log(lag) = Hurst
    slope, _ = np.polyfit(log_lags, log_rs, 1)
    return float(np.clip(slope, 0.0, 1.0))


# ── Efficiency Ratio (Kaufman) ──────────────────────────────────────────────
def efficiency_ratio(close: np.ndarray, period: int = 20) -> float:
    """ER = |net change| / sum of |bar-to-bar changes|.
    1.0 = perfectly directional (trend), 0.0 = no net movement (chop).
    """
    if len(close) < period + 1:
        return 0.0
    window = close[-period - 1:]
    net = abs(float(window[-1] - window[0]))
    path = float(np.sum(np.abs(np.diff(window))))
    if path < 1e-12:
        return 0.0
    return float(net / path)


# ── Fractal dimension (box-counting) ────────────────────────────────────────
def fractal_dimension(series: np.ndarray) -> float:
    """Box-counting fractal dimension. D ≈ 1.5 = random, D < 1.5 = trend, D > 1.5 = chop."""
    if len(series) < 30:
        return 1.5
    s = np.asarray(series, dtype=float)
    # normalize
    s = (s - s.min()) / (s.max() - s.min() + 1e-12)
    n = len(s)
    dims = []
    for box in (2, 4, 8, 16, 32):
        if box > n // 2:
            continue
        n_boxes = 0
        for i in range(0, n, box):
            chunk = s[i:i + box]
            if len(chunk) == 0:
                continue
            # how many y-boxes does this chunk span?
            y_span = chunk.max() - chunk.min()
            n_boxes += max(1, int(y_span * box) + 1)
        dims.append((np.log(n_boxes), np.log(n / box)))
    if len(dims) < 3:
        return 1.5
    xs = np.array([d[1] for d in dims])
    ys = np.array([d[0] for d in dims])
    slope, _ = np.polyfit(xs, ys, 1)
    return float(np.clip(slope, 1.0, 2.0))


# ── Choppiness index ────────────────────────────────────────────────────────
def choppiness_index(df: pd.DataFrame, period: int = 14) -> float:
    """CI = 100 * log10(sum(ATR) / (highest_high - lowest_low)) / log10(period).
    > 61.8 = choppy/range, < 38.2 = trending."""
    if len(df) < period + 1:
        return 50.0
    d = df.tail(period).reset_index(drop=True)
    atr_sum = float((d["high"] - d["low"]).sum())
    hh = float(d["high"].max())
    ll = float(d["low"].min())
    rng = hh - ll
    if rng < 1e-12:
        return 50.0
    import math
    return float(100 * math.log10(atr_sum / rng) / math.log10(period))


# ── Volatility regime ───────────────────────────────────────────────────────
def volatility_regime(df: pd.DataFrame, atr_period: int = 14, lookback: int = 100) -> dict[str, Any]:
    """ATR percentile + vol-clustering detection.
    Returns {percentile, regime: low/normal/high/extreme, expanding: bool}."""
    if len(df) < atr_period + 5:
        return {"percentile": 50, "regime": "normal", "expanding": False}
    h, l, c = df["high"], df["low"], df["close"]
    tr = pd.concat([(h - l), (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(atr_period).mean()
    atr_pct = (atr / c) * 100
    recent = atr_pct.tail(lookback).dropna()
    if len(recent) < 10:
        return {"percentile": 50, "regime": "normal", "expanding": False}
    now = float(atr_pct.iloc[-1])
    pct = float((recent < now).mean() * 100)
    regime = "low" if pct < 25 else "normal" if pct < 65 else "high" if pct < 90 else "extreme"
    # expanding = recent ATR rising
    expanding = bool(atr_pct.iloc[-1] > atr_pct.iloc[-5] * 1.15)
    return {"percentile": round(pct, 1), "regime": regime, "expanding": expanding,
            "atr_pct": round(now, 3)}


# ── Composite regime ────────────────────────────────────────────────────────
def detect_regime(df: pd.DataFrame) -> dict[str, Any]:
    """Composite market regime classification.
    Returns:
      regime: 'trend_up' | 'trend_down' | 'range' | 'chop' | 'breakout' | 'random'
      confidence: 0..1
      hurst, efficiency, fractal_dim, choppiness, vol_regime
      strategy_hint: which approach works in this regime
      edge: signed lean (+ bullish, - bearish, 0 neutral)
    """
    if df is None or len(df) < 50:
        return _empty_regime()
    close = df["close"].astype(float).values
    h = hurst_exponent(close[-200:] if len(close) >= 200 else close)
    er = efficiency_ratio(close, 20)
    fd = fractal_dimension(close[-100:] if len(close) >= 100 else close)
    ci = choppiness_index(df, 14)
    vreg = volatility_regime(df)
    # directional lean from ER sign
    window = close[-21:]
    direction = 1.0 if window[-1] > window[0] else -1.0
    er_signed = er * direction
    # classify
    if h > 0.55 and er > 0.3 and ci < 45:
        regime = "trend_up" if direction > 0 else "trend_down"
        confidence = min(1.0, (h - 0.5) * 2 + er)
        strategy = "trend_following"
        edge = 0.5 * er_signed
    elif h < 0.45 and ci > 61.8:
        regime = "chop"
        confidence = min(1.0, (0.5 - h) * 2 + (ci - 61.8) / 38.2)
        strategy = "stay_out"
        edge = 0.0
    elif fd > 1.55 and er < 0.2:
        regime = "random"
        confidence = min(1.0, (fd - 1.5) * 2)
        strategy = "stay_out"
        edge = 0.0
    elif er < 0.25 and ci >= 45 and ci <= 61.8:
        regime = "range"
        confidence = min(1.0, (0.25 - er) * 4 + (1 - abs(ci - 50) / 12))
        strategy = "mean_reversion"
        # range edge = lean toward mean (fade extremes)
        price = float(close[-1])
        window_lo, window_hi = float(df["low"].tail(50).min()), float(df["high"].tail(50).max())
        pos = (price - window_lo) / (window_hi - window_lo + 1e-12)
        edge = (0.5 - pos) * 0.6  # above mid → short, below mid → long
    elif vreg["expanding"] and er > 0.35:
        regime = "breakout"
        confidence = min(1.0, er + (vreg["percentile"] / 200))
        strategy = "breakout"
        edge = 0.4 * er_signed
    else:
        regime = "range"
        confidence = 0.4
        strategy = "mean_reversion"
        edge = 0.0
    return {
        "regime": regime, "confidence": round(confidence, 3),
        "hurst": round(h, 3), "efficiency": round(er, 3),
        "efficiency_signed": round(er_signed, 3),
        "fractal_dim": round(fd, 3), "choppiness": round(ci, 1),
        "vol_regime": vreg, "strategy_hint": strategy, "edge": round(edge, 3),
        "direction": "up" if direction > 0 else "down",
    }


def _empty_regime() -> dict[str, Any]:
    return {"regime": "unknown", "confidence": 0.0, "hurst": 0.5,
            "efficiency": 0.0, "efficiency_signed": 0.0, "fractal_dim": 1.5,
            "choppiness": 50.0, "vol_regime": {"percentile": 50, "regime": "normal", "expanding": False},
            "strategy_hint": "stay_out", "edge": 0.0, "direction": "flat"}


# ── Strategy-applicability check ────────────────────────────────────────────
def strategy_applicable(regime_info: dict, signal_side: str) -> tuple[bool, str]:
    """Should this side's signal be trusted in this regime?
    Trend signals need a trend regime; mean-reversion signals need range/chop.
    """
    r = regime_info.get("regime", "unknown")
    hint = regime_info.get("strategy_hint", "stay_out")
    if hint == "stay_out":
        return False, "رژیم بازار نامناسب (chop/random) — سیگنال‌ها در این رژیم قابل اعتماد نیستند"
    if signal_side in ("LONG", "SHORT"):
        if hint == "trend_following":
            return True, "رژیم روندی — سیگنال روندی قابل اعتماد"
        if hint == "mean_reversion":
            return True, "رژیم رنج — سیگنال برگشتی قابل اعتماد"
        if hint == "breakout":
            return True, "رژیم شکست — سیگنال جهت‌دار قابل اعتماد"
    return True, "رژیم قابل‌قبول"
