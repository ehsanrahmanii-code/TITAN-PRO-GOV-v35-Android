"""Advisor: turns the central brain's numbers into (1) an explicit action plan for ONE coin / ONE timeframe and
(2) a written critique of the evidence families (who supports, who opposes, where the weak link is).

Nothing here invents data. Every sentence is built from fields the engines already computed (levels, simulation edge, planner
laboratory, governor components, projection coherence, data trust)."""
from __future__ import annotations

from app.config import PARTIALS, RISK_PER_TRADE_PCT

FAM_FA = {"htf_trend": "روند تایم‌فریم بالا", "mtf_setup": "ستاپ میان‌مدت", "ltf_trigger": "ماشهٔ تایم‌فریم پایین", "momentum": "مومنتوم", "structure": "ساختار بازار",
          "volume_flow": "جریان حجم", "derivatives": "مشتقات (فاندینگ/OI)", "pattern": "الگوها", "forecast": "پیش‌بینی آماری", "context": "بافت بازار (BTC/نقدینگی)",
          "x_layer": "لایهٔ تکمیلی", "data_trust": "اعتماد به داده"}
SIDE_FA = {"LONG": "خرید (لانگ)", "SHORT": "فروش (شورت)", "WAIT": "صبر"}


def _p(x) -> str:
    try:
        return f"{float(x):.8g}"
    except (TypeError, ValueError):
        return "—"


def _pct(a: float, b: float) -> float:
    return (a - b) / b * 100 if b else 0.0


def critique(gov: dict | None, sigs: dict, coh: dict | None, pub_side: str, ptf: str) -> dict:
    """Evidence audit: which engine families back the published side, which oppose it, and what is the weakest link."""
    gov = gov or {}
    comp = gov.get("components") or {}
    d = 1.0 if pub_side == "LONG" else -1.0 if pub_side == "SHORT" else 0.0
    rows = [{"k": k, "name": FAM_FA.get(k, k), "v": round(float(v), 2)} for k, v in comp.items() if isinstance(v, (int, float)) and k != "data_trust"]
    if d:
        sup = sorted((r for r in rows if r["v"] * d >= 0.15), key=lambda r: -abs(r["v"]))
        opp = sorted((r for r in rows if r["v"] * d <= -0.15), key=lambda r: -abs(r["v"]))
    else:
        sup = sorted((r for r in rows if r["v"] >= 0.3), key=lambda r: -r["v"])
        opp = sorted((r for r in rows if r["v"] <= -0.3), key=lambda r: r["v"])
    neu = [r for r in rows if r not in sup and r not in opp]
    notes: list[str] = []
    if d:
        if opp:
            top = opp[0]
            notes.append(f"قوی‌ترین مخالف: «{top['name']}» ({top['v']:+.2f}) — تا وقتی این خانواده برنگشته، اندازهٔ پوزیشن را کوچک نگه دارید")
        if len(sup) >= 5 and not opp:
            notes.append(f"{len(sup)} خانوادهٔ مستقل از هم‌جهتی حکم پشتیبانی می‌کنند و مخالفی وجود ندارد")
        against_tf = [t for t, s in sigs.items() if (s.get("side") if isinstance(s, dict) else getattr(s, "side", "WAIT")) in ("LONG", "SHORT") and
                      (s.get("side") if isinstance(s, dict) else s.side) != pub_side]
        if against_tf:
            notes.append("تایم‌فریم‌های مخالف: " + "، ".join(against_tf))
    trust = comp.get("data_trust")
    if isinstance(trust, (int, float)) and trust < 0.5:
        notes.append(f"اعتماد به داده پایین است ({trust:.2f}) — نتیجه را با احتیاط بخوانید")
    if coh and coh.get("label") == "divergent":
        notes.append("پیش‌بینی آماری همهٔ تایم‌فریم‌ها با حکم هم‌جهت نیست")
    contr = float(gov.get("contradiction") or 0.0)
    weak = (opp[0]["name"] if opp else (min(rows, key=lambda r: abs(r["v"]))["name"] if rows else None))
    strength = "قوی" if d and len(sup) >= 5 and contr < 0.2 and not opp else "متوسط" if d and len(sup) >= 3 else "ضعیف" if d else "بدون حکم"
    return {"strength": strength, "support": sup[:6], "oppose": opp[:6], "neutral": neu[:6], "contradiction": round(contr, 2), "weakest": weak,
            "trust": trust, "notes": notes}


def action_plan(symbol: str, tf: str, verdict: str, plan: dict | None, price: float | None, fc: dict | None, gov: dict | None, grade: dict | None,
                triggers: dict | None, conviction: float) -> dict:
    """Plain, ordered instructions for this coin and timeframe: what to do now, where to enter, where to exit, what cancels the idea."""
    fc = fc or {}
    plan = plan or {}
    edge, po = fc.get("edge") or {}, ((fc.get("plan_opt") or {}).get("best")) or None
    g = (grade or {}).get("grade", "—") if isinstance(grade, dict) else "—"
    px = float(price or plan.get("entry") or 0)
    probe = (gov or {}).get("tier") == "probe"
    base = {"symbol": symbol, "tf": tf, "verdict": verdict, "grade": g, "conviction": conviction, "price": px, "tier": (gov or {}).get("tier", "none"), "size_mult": 0.5 if probe else 1.0}
    if verdict not in ("LONG", "SHORT") or not plan.get("entry"):
        tr = triggers or {}
        up, dn = ((tr.get("LONG") or {}).get("above")), ((tr.get("SHORT") or {}).get("below"))
        veto = list((gov or {}).get("vetoes") or [])[:2] or list((gov or {}).get("reasons") or [])[:2]
        do = ["اکنون پوزیشن جدید باز نکنید؛ سیستم لبهٔ کافی نمی‌بیند."]
        if up:
            do.append(f"فقط اگر کندل {tf} بالای {_p(up)} بسته شد، تحلیل خرید را دوباره بررسی کنید.")
        if dn:
            do.append(f"فقط اگر کندل {tf} پایین {_p(dn)} بسته شد، تحلیل فروش را دوباره بررسی کنید.")
        if veto:
            do.append("دلیل صبر: " + " · ".join(veto))
        return {**base, "mode": "wait", "headline": f"صبر کنید — {symbol} در {tf}", "steps": do, "levels": None, "invalidation": None}
    d = 1 if verdict == "LONG" else -1
    if px:                                                                       # live validity: the plan is re-checked against the price every scan
        if (px - float(plan["stop"])) * d <= 0:
            return {**base, "mode": "stale", "headline": f"سطوح قبلی باطل شد — {symbol} در {tf}", "levels": None, "invalidation": None,
                    "steps": [f"قیمت ({_p(px)}) از حدضرر ({_p(plan['stop'])}) گذشته؛ این ایده دیگر معتبر نیست. وارد نشوید و منتظر تحلیل جدید بمانید."]}
        if (px - float(plan["tp1"])) * d >= 0 and not (po and (po.get("p") or 0)):
            return {**base, "mode": "stale", "headline": f"فرصت ورود از دست رفت — {symbol} در {tf}", "levels": None, "invalidation": None,
                    "steps": [f"قیمت ({_p(px)}) از TP1 ({_p(plan['tp1'])}) عبور کرده؛ ورود دیرهنگام نسبت سود به ضرر را خراب می‌کند. منتظر پولبک یا تحلیل جدید بمانید."]}
    locked = bool(plan.get("locked"))                                            # a live, persistent signal keeps ITS levels; the simulator's optimum is only shown next to them
    use_opt = bool(not locked and po and (po.get("ev_r") or 0) > 0 and (po.get("p_fill") or 0) >= 0.3)
    e = float(po["p"]) if use_opt else float(plan["entry"])
    s = float(po["stop"]) if use_opt else float(plan["stop"])
    t1, t2, t3 = ((float(po["tp1"]), float(po["tp2"]), float(po["tp3"])) if use_opt else (float(plan["tp1"]), float(plan["tp2"]), float(plan["tp3"])))
    risk = abs(e - s)
    dist = _pct(e, px) if px else 0.0
    immediate = (not px) or abs(dist) <= 0.12 or (use_opt and po.get("mode") == "market")
    mode = "enter_now" if immediate else "limit"
    verb = "خرید" if d > 0 else "فروش"
    steps = []
    if immediate:
        steps.append(f"۱) ورود {verb} با سفارش بازار نزدیک {_p(e)} (قیمت فعلی {_p(px)}).")
    else:
        way = "پایین‌تر" if (e < px) else "بالاتر"
        steps.append(f"۱) سفارش لیمیت {verb} را در {_p(e)} بگذارید ({abs(dist):.2f}٪ {way} از قیمت فعلی). با قیمت فعلی وارد نشوید"
                     + (f"؛ احتمال پر‌شدن حدود {round(float(po['p_fill']) * 100)}٪ است." if use_opt and po.get("p_fill") is not None else "."))
    rk = RISK_PER_TRADE_PCT * (0.5 if probe else 1.0)
    steps.append(f"۲) حدضرر را همان لحظه در {_p(s)} بگذارید ({risk / e * 100:.2f}٪ از ورود). حجم را طوری بگیرید که ضرر در حدضرر ≤ {rk:g}٪ سرمایه شود"
                 + (" (نیمهٔ حجم عادی، چون این یک فرصت احتمالی است)." if probe else "."))
    steps.append(f"۳) TP1 در {_p(t1)}: {round(PARTIALS[0] * 100)}٪ پوزیشن را ببندید و حدضرر را روی ورود ({_p(e)}) ببرید (بدون ریسک).")
    steps.append(f"۴) TP2 در {_p(t2)}: {round(PARTIALS[1] * 100)}٪ دیگر را ببندید و حدضرر را روی TP1 ببرید.")
    steps.append(f"۵) باقی‌مانده تا TP3 در {_p(t3)} بماند و حدضرر متحرک را همیشه به فاصلهٔ ۱R ({_p(risk)}) پشت بهترین قیمت نگه دارید (فقط در جهت سود جابه‌جا شود، هرگز عقب نرود).")
    h = edge.get("horizon")
    inval = f"اگر کندل {tf} پشت {_p(s)} بسته شد یا ({h} کندل) هنوز به TP1 نرسید و ساختار خراب شد، ایده باطل است" if h else f"اگر کندل {tf} پشت {_p(s)} بسته شد، ایده باطل است"
    steps.append("۶) ابطال: " + inval + ("؛ سفارش لیمیت اجرا‌نشده را هم لغو کنید." if not immediate else "."))
    ev = (po or {}).get("ev_r") if use_opt else edge.get("ev_r")
    stats = {"p_tp1": edge.get("p_tp1"), "p_tp2": edge.get("p_tp2"), "p_tp3": edge.get("p_tp3"), "p_stop": edge.get("p_stop"), "ev_r": ev,
             "rr_tp2": round(abs(t2 - e) / risk, 2) if risk else None, "level_grade": (fc.get("level_check") or {}).get("grade")}
    warn = list((fc.get("level_check") or {}).get("notes") or [])
    head = ("فرصت احتمالی · " if probe else "") + f"{SIDE_FA[verdict]} {symbol} در {tf} — " + ("همین حالا وارد شوید" if immediate else "منتظر قیمت ورود بمانید")
    return {**base, "mode": mode, "headline": head, "steps": steps, "levels": {"entry": e, "stop": s, "tp1": t1, "tp2": t2, "tp3": t3, "source": "simulator" if use_opt else ("locked" if locked else "signal")},
            "stats": stats, "warnings": warn, "invalidation": inval,
            "optimal": ({"p": po.get("p"), "mode": po.get("mode"), "p_fill": po.get("p_fill"), "ev_r": po.get("ev_r"), "name": po.get("name")} if (locked and po and po.get("p")) else None),
            "persist": {"state": plan.get("persist_state"), "since": plan.get("since"), "valid_until": plan.get("valid_until_ts")} if locked else None}
