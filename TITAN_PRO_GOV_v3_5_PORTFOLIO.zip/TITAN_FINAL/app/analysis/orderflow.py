"""Volume Profile & Order Flow analytics.

Computes what institutional auction-market tools show:
  • Volume Profile (time-based) — POC, Value Area (70%), VAH/VAL, High/Low Volume Nodes
  • Session Volume Profile (Asian/London/NY)
  • Cumulative Volume Delta (CVD) from taker buy/sell estimate
  • Delta divergence (price up but CVD down = absorption)
  • Volume-weighted support/resistance from HVNs/LVNs
  • Order-flow imbalance per candle

All computed from OHLCV — no order-book data needed (works on Binance klines).
"""
from __future__ import annotations
from typing import Any
import numpy as np
import pandas as pd


def _ticks_for_candle(o: float, h: float, l: float, c: float, v: float, n: int = 10) -> np.ndarray:
    """Approximate intra-candle price distribution (triangular weighting toward close)."""
    rng = np.linspace(0, 1, n)
    # path from open to close, bounded by high/low
    path = o + (c - o) * rng
    # blend with high/low envelope
    hi_env = l + (h - l) * np.sin(rng * np.pi)
    path = 0.5 * path + 0.5 * hi_env
    vol_per = v / n
    return np.column_stack([path, np.full(n, vol_per)])


def volume_profile(df: pd.DataFrame, bins: int = 50, lookback: int = 200) -> dict[str, Any]:
    """Build a volume profile over `lookback` candles.

    Returns: poc, vah, val, value_area_pct, hvns (high-volume nodes),
    lvns (low-volume nodes), nodes (price, volume bins), total_volume.
    """
    if df is None or len(df) < 30:
        return _empty_profile()
    d = df.tail(lookback).reset_index(drop=True)
    o = d["open"].astype(float).values
    h = d["high"].astype(float).values
    l = d["low"].astype(float).values
    c = d["close"].astype(float).values
    v = d["volume"].astype(float).values
    lo, hi = float(l.min()), float(h.max())
    if hi <= lo:
        return _empty_profile()
    edges = np.linspace(lo, hi, bins + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    vol_by_price = np.zeros(bins)
    for i in range(len(d)):
        # distribute candle volume across its high-low range, weighted toward close
        c_lo, c_hi = l[i], h[i]
        if c_hi <= c_lo:
            continue
        # which bins does this candle touch?
        mask = (centers >= c_lo) & (centers <= c_hi)
        if not mask.any():
            continue
        # triangular weight: peak near the close
        dist = np.abs(centers[mask] - c[i]) / (c_hi - c_lo + 1e-12)
        w = np.maximum(0, 1 - dist)
        w_sum = w.sum()
        if w_sum > 0:
            vol_by_price[mask] += v[i] * (w / w_sum)
    total = float(vol_by_price.sum())
    if total <= 0:
        return _empty_profile()
    # POC = bin with max volume
    poc_idx = int(np.argmax(vol_by_price))
    poc = float(centers[poc_idx])
    # Value Area (70%) — expand outward from POC until 70% of volume captured
    target = 0.70 * total
    captured = vol_by_price[poc_idx]
    va_lo, va_hi = poc_idx, poc_idx
    while captured < target and (va_lo > 0 or va_hi < bins - 1):
        down = vol_by_price[va_lo - 1] if va_lo > 0 else -1
        up = vol_by_price[va_hi + 1] if va_hi < bins - 1 else -1
        if up >= down and up > 0:
            va_hi += 1; captured += vol_by_price[va_hi]
        elif down > 0:
            va_lo -= 1; captured += vol_by_price[va_lo]
        else:
            break
    vah = float(centers[va_hi])
    val = float(centers[va_lo])
    value_area_pct = round(captured / total, 3)
    # HVN/LVN: bins above/below mean+std
    mean_v = float(vol_by_price.mean())
    std_v = float(vol_by_price.std()) if bins > 1 else 0.0
    hvn_mask = vol_by_price > mean_v + 0.5 * std_v
    lvn_mask = vol_by_price < mean_v - 0.3 * std_v
    hvns = [{"price": float(centers[i]), "vol": float(vol_by_price[i])} for i in range(bins) if hvn_mask[i]]
    lvns = [{"price": float(centers[i]), "vol": float(vol_by_price[i])} for i in range(bins) if lvn_mask[i]]
    hvns.sort(key=lambda x: -x["vol"])
    return {
        "poc": round(poc, 8), "vah": round(vah, 8), "val": round(val, 8),
        "value_area_pct": value_area_pct, "hvns": hvns[:5], "lvns": lvns[:3],
        "nodes": [{"price": float(centers[i]), "vol": float(vol_by_price[i])} for i in range(bins)],
        "total_volume": total, "range_high": hi, "range_low": lo,
    }


def _empty_profile() -> dict[str, Any]:
    return {"poc": 0.0, "vah": 0.0, "val": 0.0, "value_area_pct": 0.0,
            "hvns": [], "lvns": [], "nodes": [], "total_volume": 0.0,
            "range_high": 0.0, "range_low": 0.0}


# ── Cumulative Volume Delta ─────────────────────────────────────────────────
def cumulative_volume_delta(df: pd.DataFrame, lookback: int = 100) -> dict[str, Any]:
    """Estimate taker buy vs sell volume per candle using the intrabar approximation
    (close > open → buy pressure; close < open → sell pressure; weight by volume).

    CVD = cumulative (buy_vol - sell_vol).
    Delta divergence: price makes higher high but CVD makes lower high → bearish absorption.
    """
    if df is None or len(df) < 20:
        return {"cvd": 0.0, "cvd_series": [], "delta": [], "divergence": "none", "bias": 0.0}
    d = df.tail(lookback).reset_index(drop=True)
    o, h, l, c, v = (d[k].astype(float).values for k in ("open", "high", "low", "close", "volume"))
    # Buying pressure estimate: fraction of candle range above open
    rng = h - l + 1e-12
    buy_frac = np.where(rng > 0, (c - l) / rng, 0.5)
    buy_frac = np.clip(buy_frac, 0.1, 0.9)
    buy_vol = buy_frac * v
    sell_vol = (1 - buy_frac) * v
    delta = buy_vol - sell_vol
    cvd = np.cumsum(delta)
    cvd_now = float(cvd[-1])
    cvd_prev = float(cvd[-2]) if len(cvd) > 1 else cvd_now
    # divergence: compare last 20 bars price vs CVD slope
    n = min(20, len(c))
    price_slope = (c[-1] - c[-n]) / (c[-n] + 1e-12)
    cvd_slope = (cvd[-1] - cvd[-n]) / (abs(cvd[-n]) + 1e-9)
    divergence = "none"
    bias = 0.0
    if price_slope > 0.01 and cvd_slope < -0.1:
        divergence = "bearish"  # price up, CVD down = absorption / distribution
        bias = -0.4
    elif price_slope < -0.01 and cvd_slope > 0.1:
        divergence = "bullish"  # price down, CVD up = accumulation
        bias = 0.4
    elif abs(price_slope) > 0.005 and np.sign(price_slope) == np.sign(cvd_slope):
        bias = 0.2 * np.sign(price_slope)
    return {
        "cvd": round(cvd_now, 3), "cvd_prev": round(cvd_prev, 3),
        "cvd_change": round(cvd_now - cvd_prev, 3),
        "cvd_series": [round(float(x), 2) for x in cvd[-30:]],
        "delta": [round(float(x), 2) for x in delta[-20:]],
        "divergence": divergence, "bias": round(bias, 3),
        "buy_vol_last": round(float(buy_vol[-1]), 3),
        "sell_vol_last": round(float(sell_vol[-1]), 3),
    }


# ── Order-flow imbalance (per-candle) ───────────────────────────────────────
def order_flow_imbalance(df: pd.DataFrame, lookback: int = 14) -> dict[str, Any]:
    """Recent order-flow imbalance: ratio of buy vs sell pressure over last N candles."""
    if df is None or len(df) < lookback:
        return {"imbalance": 0.0, "bias": 0.0, "regime": "balanced"}
    d = df.tail(lookback).reset_index(drop=True)
    o, h, l, c, v = (d[k].astype(float).values for k in ("open", "high", "low", "close", "volume"))
    rng = h - l + 1e-12
    buy_frac = np.clip((c - l) / rng, 0.1, 0.9)
    buy_vol = (buy_frac * v).sum()
    sell_vol = ((1 - buy_frac) * v).sum()
    total = buy_vol + sell_vol
    if total <= 0:
        return {"imbalance": 0.0, "bias": 0.0, "regime": "balanced"}
    imbalance = (buy_vol - sell_vol) / total  # -1..+1
    regime = "buy_pressure" if imbalance > 0.2 else "sell_pressure" if imbalance < -0.2 else "balanced"
    return {
        "imbalance": round(float(imbalance), 3), "buy_vol": round(float(buy_vol), 3),
        "sell_vol": round(float(sell_vol), 3), "bias": round(float(imbalance), 3),
        "regime": regime,
    }


# ── Combined order-flow score for the governor ──────────────────────────────
def order_flow_score(df: pd.DataFrame) -> dict[str, Any]:
    """Composite order-flow read: blend CVD divergence + imbalance + volume profile position.
    Returns a signed score in [-1, +1] plus diagnostics."""
    if df is None or len(df) < 30:
        return {"score": 0.0, "bias": "neutral", "notes": [], "cvd": {}, "vp": {}, "ofi": {}}
    cvd = cumulative_volume_delta(df)
    ofi = order_flow_imbalance(df)
    vp = volume_profile(df, bins=40, lookback=150)
    score = 0.0
    notes = []
    # CVD divergence is strongest signal
    if cvd["divergence"] == "bullish":
        score += 0.4
        notes.append("واگرایی صعودی CVD (انباشت)")
    elif cvd["divergence"] == "bearish":
        score -= 0.4
        notes.append("واگرایی نزولی CVD (توزیع)")
    # OFI
    score += 0.3 * ofi["imbalance"]
    if ofi["regime"] == "buy_pressure":
        notes.append("فشار خرید در دفتر سفارش")
    elif ofi["regime"] == "sell_pressure":
        notes.append("فشار فروش در دفتر سفارش")
    # position vs POC
    price = float(df["close"].iloc[-1])
    if vp["poc"] > 0:
        if price < vp["val"]:
            score += 0.15
            notes.append("قیمت زیر Value Area (ناحیه ارزش پایین)")
        elif price > vp["vah"]:
            score -= 0.15
            notes.append("قیمت بالای Value Area (ناحیه ارزش بالا)")
        # distance from POC
        dist_pct = abs(price - vp["poc"]) / price
        if dist_pct < 0.005:
            notes.append("قیمت روی POC (تعادل)")
    score = max(-1.0, min(1.0, score))
    bias = "bullish" if score > 0.15 else "bearish" if score < -0.15 else "neutral"
    return {"score": round(score, 3), "bias": bias, "notes": notes,
            "cvd": cvd, "vp": {"poc": vp["poc"], "vah": vp["vah"], "val": vp["val"],
                               "value_area_pct": vp["value_area_pct"]},
            "ofi": ofi}
