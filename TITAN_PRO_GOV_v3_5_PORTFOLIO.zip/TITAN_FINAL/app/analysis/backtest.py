"""Walk-forward check of the signal engine on the coin's own history.
At every step only candles up to that bar are visible; the trade is entered at the NEXT candle's open,
exits replay the paper-exchange rules (staged 40/35/25 targets, break-even stop after TP1, stop-first
when stop and target share a candle) and costs (fees + slippage) are charged in R."""
from __future__ import annotations
import math
import numpy as np
import pandas as pd

from app.config import PARTIALS, FEE_TAKER, SLIPPAGE
from app.analysis.technicals import analyze


def sortino(r: np.ndarray) -> float:
    """Sortino ratio of a per-trade R stream: mean / target-downside deviation sqrt(mean(min(r,0)^2)) over ALL trades."""
    r = np.asarray(r, dtype=float)
    if not len(r):
        return 0.0
    dd_dev = float(np.sqrt(np.mean(np.minimum(r, 0.0) ** 2)))
    return float(r.mean() / dd_dev) if dd_dev > 1e-12 else (float("inf") if r.mean() > 0 else 0.0)


def block_bootstrap(r: np.ndarray, n_paths: int, rng: np.random.Generator, block: int | None = None) -> np.ndarray:
    """(n_paths, len(r)) resampled trade sequences built from consecutive blocks (circular) of the original order. Plain i.i.d. resampling
    destroys streaks and makes drawdown look milder than it was; block length ~ n^(1/3) keeps the short-range dependence."""
    r = np.asarray(r, dtype=float)
    n = len(r)
    if n == 0:
        return np.zeros((n_paths, 0))
    b = int(block or max(2, round(n ** (1.0 / 3.0))))
    b = max(1, min(b, n))
    n_blocks = -(-n // b)
    starts = rng.integers(0, n, size=(n_paths, n_blocks))
    idx = (starts[:, :, None] + np.arange(b)[None, None, :]) % n
    return r[idx.reshape(n_paths, -1)[:, :n]]


def _replay(df: pd.DataFrame, j0: int, side: str, entry: float, stop: float, tps: tuple, horizon: int) -> dict:
    d = 1.0 if side == "LONG" else -1.0
    risk = abs(entry - stop)
    H, L, C = df["high"].values, df["low"].values, df["close"].values
    end = min(len(df), j0 + horizon)
    stage, R, rem_used = 0, 0.0, 0.0
    mfe = mae = 0.0
    out, bars = "open", end - j0
    for j in range(j0, end):
        hi, lo = (H[j], L[j]) if side == "LONG" else (-L[j], -H[j])           # work in "long" space
        e, s, t = d * entry, d * stop, [d * x for x in tps]
        mfe = max(mfe, (hi - e) / risk); mae = min(mae, (lo - e) / risk)
        cur_stop = e if stage >= 1 else s
        # Conservative same-bar rule: if both stop and a target are tagged in
        # one candle, assume stop was hit first (path inside the bar unknown).
        stop_hit = lo <= cur_stop
        tp_hit = any(stage == k and hi >= t[k] for k in range(3))
        if stop_hit and tp_hit:
            if stage == 0:
                R += -1.0; out = "stop"
            else:
                out = f"BE بعد از TP{stage}"
            bars, stage = j - j0 + 1, 9
            break
        if stop_hit:
            if stage == 0:
                R += -1.0; out = "stop"
            else:
                out = f"BE بعد از TP{stage}"
            bars, stage = j - j0 + 1, 9
            break
        for k in range(3):
            if stage == k and hi >= t[k]:
                R += PARTIALS[k] * (t[k] - e) / risk
                rem_used += PARTIALS[k]; stage = k + 1
        if stage == 3:
            out, bars = "TP3", j - j0 + 1
            break
    if stage < 9 and stage != 3:                                          # horizon reached -> mark to market
        R += (1 - rem_used) * d * (C[end - 1] - entry) / risk
        out = f"زمان‌پایان" if stage == 0 else f"زمان‌پایان بعد از TP{stage}"
    if stage == 3 or (stage not in (0, 9) and out.startswith("TP")):
        out = "TP3"
    cost = 2 * (FEE_TAKER + SLIPPAGE) * entry / risk
    return {"r": R - cost, "gross": R, "out": out, "bars": bars, "mfe": mfe, "mae": mae}


def run(df: pd.DataFrame, symbol: str, tf: str, start: int = 150, step: int = 3, horizon: int = 32) -> dict:
    n = len(df)
    if n < start + 40:
        return {"error": "تاریخچه برای بک‌تست کافی نیست", "n": 0}
    trades, busy = [], -1
    for i in range(start, n - 2, step):
        if i <= busy:
            continue
        sub = df.iloc[:i + 1]
        sig = analyze(sub, symbol, tf, price=float(sub["close"].iloc[-1]))
        if sig.side == "WAIT":
            continue
        entry = float(df["open"].iloc[i + 1])
        dx = entry - sig.entry
        stop, tps = sig.stop + dx, tuple(x + dx for x in (sig.tp1, sig.tp2, sig.tp3))
        if abs(entry - stop) <= entry * 1e-5:
            continue
        res = _replay(df, i + 1, sig.side, entry, stop, tps, horizon)
        busy = i + res["bars"]
        trades.append({"t": int(df["open_time"].iloc[i + 1].timestamp() * 1000), "side": sig.side, "score": sig.score,
                       "conf": sig.confidence, "entry": float(f"{entry:.8g}"), "r": round(res["r"], 3), "out": res["out"],
                       "bars": int(res["bars"]), "mfe": round(res["mfe"], 2), "mae": round(res["mae"], 2)})
    first_px, last_px = float(df["close"].iloc[start]), float(df["close"].iloc[-1])
    bh = (last_px / first_px - 1) * 100
    if not trades:
        return {"n": 0, "trades": [], "equity": [], "buy_hold_pct": round(bh, 2), "bars_tested": n - start,
                "note": "در این بازه سیگنال معتبری صادر نشد"}
    r = np.array([t["r"] for t in trades])
    wins, losses = r[r > 0], r[r <= 0]
    pf = float(wins.sum() / abs(losses.sum())) if len(losses) and losses.sum() != 0 else float("inf") if len(wins) else 0.0
    eq = np.cumsum(r)
    peak = np.maximum.accumulate(np.r_[0.0, eq])[1:]
    dd = float((peak - eq).max()) if len(eq) else 0.0
    streak = cur = 0
    for x in r:
        cur = cur + 1 if x <= 0 else 0
        streak = max(streak, cur)
    t_stat = float(r.mean() / (r.std(ddof=1) / np.sqrt(len(r)))) if len(r) > 2 and r.std(ddof=1) > 0 else 0.0

    # ── Equity-curve statistics (pro desk metrics) ────────────────────────
    # Sharpe-like ratio of R-stream (per-trade, annualization not needed for grading)
    sharpe_r = float(r.mean() / (r.std(ddof=1) + 1e-9)) if len(r) > 1 else 0.0
    # Sortino: mean over the target-downside deviation sqrt(mean(min(r,0)^2)) taken over ALL trades (the old code used the std of the losing
    # trades only, which ignores how often losses happen and is undefined for a single loss)
    sortino_r = sortino(r)
    # R-multiples expectancy
    expectancy_r = float(r.mean()) if len(r) else 0.0
    # System Quality Number (Van Tharp): SQN = sqrt(n) * mean / std
    sqn = float(math.sqrt(len(r)) * r.mean() / r.std(ddof=1)) if len(r) > 1 and r.std(ddof=1) > 0 else 0.0
    # Calmar-like: total R / max DD R
    calmar_r = float(r.sum() / dd) if dd > 0 else 0.0
    # Profit factor
    # (already computed as `pf`)

    # ── Monte Carlo trade resampling ─────────────────────────────────────
    # Resample the trade sequence with replacement to estimate the distribution
    # of max drawdown and final equity. Gives a confidence band on the backtest.
    mc_n = 1000
    rng = np.random.default_rng(42)
    samples = block_bootstrap(r, mc_n, rng)                      # circular BLOCK bootstrap: loss streaks / clustering of the real sequence survive resampling
    eq_s = np.cumsum(samples, axis=1)
    peak = np.maximum.accumulate(np.concatenate([np.zeros((mc_n, 1)), eq_s], axis=1), axis=1)[:, 1:]
    mc_dds = (peak - eq_s).max(axis=1)
    mc_finals = eq_s[:, -1]
    mc_dd_p05 = float(np.percentile(mc_dds, 5))    # best-case 5%
    mc_dd_p50 = float(np.percentile(mc_dds, 50))   # median
    mc_dd_p95 = float(np.percentile(mc_dds, 95))   # worst-case 95%
    mc_final_p05 = float(np.percentile(mc_finals, 5))
    mc_final_p50 = float(np.percentile(mc_finals, 50))
    mc_final_p95 = float(np.percentile(mc_finals, 95))
    # Probability of profit (resampled final > 0)
    prob_profit = float((mc_finals > 0).mean())
    # Probability of ruin (drawdown > 10R during resampled run)
    prob_deep_dd = float((mc_dds > 10.0).mean())

    # ── Walk-forward split: first half vs second half ────────────────────
    half = len(r) // 2
    wf_first = r[:half] if half >= 5 else r
    wf_second = r[half:] if half >= 5 else r
    wf_first_avg = float(wf_first.mean()) if len(wf_first) else 0.0
    wf_second_avg = float(wf_second.mean()) if len(wf_second) else 0.0
    # walk-forward stability: ratio of second-half to first-half expectancy
    wf_stable = bool(wf_first_avg > 0 and 0.5 < (wf_second_avg / wf_first_avg) < 2.0)
    wf_note = ("پایدار" if wf_stable else "ناپایدار" if wf_first_avg > 0 else "نمونه کافی نیست")

    def agg(sel):
        x = np.array([t["r"] for t in sel])
        return {"n": len(x), "win": round(float((x > 0).mean() * 100), 1) if len(x) else 0, "avg_r": round(float(x.mean()), 3) if len(x) else 0}
    buckets = {"36-50": [t for t in trades if abs(t["score"]) < 50], "50-70": [t for t in trades if 50 <= abs(t["score"]) < 70],
               "70+": [t for t in trades if abs(t["score"]) >= 70]}
    return {"n": len(trades), "win_rate": round(float((r > 0).mean() * 100), 1), "avg_r": round(float(r.mean()), 3),
            "total_r": round(float(r.sum()), 2), "pf": round(pf, 2) if np.isfinite(pf) else 99.0, "max_dd_r": round(dd, 2),
            "worst_streak": int(streak), "t_stat": round(t_stat, 2), "significant": bool(len(r) >= 20 and t_stat >= 1.64),
            "sharpe_r": round(sharpe_r, 3), "sortino_r": round(sortino_r, 3) if np.isfinite(sortino_r) else 99.0,
            "expectancy_r": round(expectancy_r, 4), "sqn": round(sqn, 2),
            "calmar_r": round(calmar_r, 3) if np.isfinite(calmar_r) else 0.0,
            "monte_carlo": {
                "dd_p05": round(mc_dd_p05, 2), "dd_p50": round(mc_dd_p50, 2), "dd_p95": round(mc_dd_p95, 2),
                "final_p05": round(mc_final_p05, 2), "final_p50": round(mc_final_p50, 2), "final_p95": round(mc_final_p95, 2),
                "prob_profit": round(prob_profit, 3), "prob_deep_dd": round(prob_deep_dd, 3),
            },
            "walk_forward": {
                "first_half_avg_r": round(wf_first_avg, 3), "second_half_avg_r": round(wf_second_avg, 3),
                "stable": wf_stable, "note": wf_note,
            },
            "avg_bars": round(float(np.mean([t["bars"] for t in trades])), 1), "buy_hold_pct": round(bh, 2),
            "bars_tested": n - start, "equity": [round(float(x), 3) for x in eq],
            "by_side": {"LONG": agg([t for t in trades if t["side"] == "LONG"]), "SHORT": agg([t for t in trades if t["side"] == "SHORT"])},
            "by_score": {k: agg(v) for k, v in buckets.items()}, "trades": trades[-40:]}
