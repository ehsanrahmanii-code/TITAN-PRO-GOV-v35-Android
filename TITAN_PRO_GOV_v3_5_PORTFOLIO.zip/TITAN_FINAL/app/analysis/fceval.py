"""Walk-forward EVALUATION of the projection and of the entry/exit levels on a coin's own real history (no look-ahead).

At every origin only candles up to that bar exist for the engine; what happens afterwards is read from the real candles:

* per-candle direction: the projected P(close > previous close) against what the next candles really did — reliability table by
  confidence bucket (a calibrated engine must be right about as often as it claims) and a z-score against coin-flipping;
* cone: real coverage of the 10-90 % / 25-75 % band at 3 and 12 candles and the median-path error;
* levels: the signal's own entry/stop/targets versus the simulator's optimised entry, both replayed on the REAL following candles with the
  exchange's exit rules, fees and slippage (R after costs, win rate, t-stat).

It tells the truth, including "no edge here": use it to decide whether to trust a coin/timeframe. Output goes to ZZZ/fceval.json.
"""
from __future__ import annotations
import json
import math
import os
import threading
import time

import numpy as np
import pandas as pd

from app.config import DATA_DIR
from app.analysis.technicals import analyze
from app.analysis.forecast import build_forecast
from app.analysis import backtest as bt

_FILE = DATA_DIR / "fceval.json"
_LOCK = threading.Lock()
_JOB = {"running": False, "started": 0.0, "done": 0, "total": 0, "error": None}
BUCKETS = ((0.0, 0.03), (0.03, 0.06), (0.06, 0.10), (0.10, 0.5))


def _rstats(rs: list[float]) -> dict:
    if not rs:
        return {"n": 0}
    r = np.array(rs)
    t = float(r.mean() / (r.std(ddof=1) / math.sqrt(len(r)))) if len(r) > 2 and r.std(ddof=1) > 0 else 0.0
    return {"n": len(r), "avg_r": round(float(r.mean()), 3), "win": round(float((r > 0).mean() * 100), 1), "total_r": round(float(r.sum()), 2), "t": round(t, 2)}


def _fill(df: pd.DataFrame, t: int, side: str, mode: str, price: float, bars: int = 10) -> int | None:
    """First bar in [t, t+bars) where a resting limit / breakout order at `price` would have been filled."""
    H, L = df["high"].values, df["low"].values
    for j in range(t, min(len(df), t + bars)):
        if mode == "limit" and ((side == "LONG" and L[j] <= price) or (side == "SHORT" and H[j] >= price)):
            return j
        if mode == "stop" and ((side == "LONG" and H[j] >= price) or (side == "SHORT" and L[j] <= price)):
            return j
    return None


def evaluate(df: pd.DataFrame, symbol: str, tf: str, start: int = 150, step: int = 5, horizon: int = 12, lvl_h: int = 32, max_origins: int = 70) -> dict:
    n = len(df)
    if n < start + lvl_h + 10:
        return {"error": "تاریخچه کافی نیست", "n": 0}
    C = df["close"].values
    origins = list(range(start, n - lvl_h - 2, step))[-max_origins:]
    pairs: list[tuple[float, bool]] = []
    cov = {"h3": [], "h12": [], "h12_50": []}
    err = []
    sig_r, opt_r, mkt_r, unfilled = [], [], [], 0
    for t in origins:
        hist = df.iloc[:t]
        sig = analyze(hist, symbol, tf, price=float(hist["close"].iloc[-1]))
        lv = {"entry": sig.entry, "stop": sig.stop, "tp1": sig.tp1, "tp2": sig.tp2, "tp3": sig.tp3} if sig.side != "WAIT" else None
        pctx = {"atr": (sig.indicators or {}).get("atr"), "ind": sig.indicators, "ex": sig.extras, "zones": (sig.levels or {}).get("zones", [])} if lv else None
        fc = build_forecast(hist, sig.side, tf, symbol, lv, plan_ctx=pctx)
        sd, b = fc.get("step_dir") or [], fc.get("bands") or {}
        for j in range(min(horizon, len(sd))):
            pairs.append((float(sd[j]), bool(C[t + j] > C[t + j - 1])))
        if b.get("p10"):
            a3, a12 = C[t + 2], C[t + horizon - 1]
            cov["h3"].append(b["p10"][2] <= a3 <= b["p90"][2])
            cov["h12"].append(b["p10"][horizon - 1] <= a12 <= b["p90"][horizon - 1])
            cov["h12_50"].append(b["p25"][horizon - 1] <= a12 <= b["p75"][horizon - 1])
            err.append(abs(a12 - b["p50"][horizon - 1]) / C[t - 1] * 100)
        if not lv:
            continue
        entry = float(df["open"].iloc[t])
        dx = entry - sig.entry
        stop0, tps0 = sig.stop + dx, tuple(x + dx for x in (sig.tp1, sig.tp2, sig.tp3))
        if abs(entry - stop0) > entry * 1e-5:
            sig_r.append(bt._replay(df, t, sig.side, entry, stop0, tps0, lvl_h)["r"])
        po = ((fc.get("plan_opt") or {}).get("best")) or None
        if po and po.get("p") and (po.get("ev_r") or 0) > 0:
            if po.get("mode") == "market":
                e2 = entry
                dx2 = e2 - po["p"]
                mkt_r.append(bt._replay(df, t, sig.side, e2, po["stop"] + dx2, (po["tp1"] + dx2, po["tp2"] + dx2, po["tp3"] + dx2), lvl_h)["r"])
                opt_r.append(mkt_r[-1])
            else:
                j = _fill(df, t, sig.side, po.get("mode", "limit"), float(po["p"]))
                if j is None or j + 2 >= n:
                    unfilled += 1
                else:
                    opt_r.append(bt._replay(df, j + 1, sig.side, float(po["p"]), float(po["stop"]), (po["tp1"], po["tp2"], po["tp3"]), max(4, lvl_h - (j - t)))["r"])
    rel = []
    for lo, hi in BUCKETS:
        sel = [(p, up) for p, up in pairs if lo <= abs(p - 0.5) < hi]
        if sel:
            called = [(p > 0.5) == up for p, up in sel]
            rel.append({"edge": f"{lo:.2f}-{hi:.2f}", "n": len(sel), "claimed": round(float(np.mean([max(p, 1 - p) for p, _ in sel])), 3), "hit": round(float(np.mean(called)), 3)})
    strong = [(p, up) for p, up in pairs if abs(p - 0.5) >= 0.03]
    hit = float(np.mean([(p > 0.5) == up for p, up in strong])) if strong else None
    z = ((hit - 0.5) / math.sqrt(0.25 / len(strong))) if strong else None
    pm = lambda x: round(float(np.mean(x)), 3) if x else None
    out = {"symbol": symbol, "tf": tf, "origins": len(origins), "bars": n, "t": int(time.time()),
           "direction": {"n_all": len(pairs), "n_strong": len(strong), "hit_strong": None if hit is None else round(hit, 3), "z_vs_coinflip": None if z is None else round(z, 2),
                         "reliability": rel, "has_edge": bool(z is not None and z > 1.64)},
           "cone": {"cov80_h3": pm(cov["h3"]), "cov80_h12": pm(cov["h12"]), "cov50_h12": pm(cov["h12_50"]), "median_err_pct_h12": None if not err else round(float(np.mean(err)), 3)},
           "levels": {"signal": _rstats(sig_r), "optimised": _rstats(opt_r), "optimised_unfilled": unfilled, "optimised_market_only": _rstats(mkt_r)}}
    return out


def _save(key: str, res: dict) -> None:
    with _LOCK:
        try:
            cur = json.loads(_FILE.read_text(encoding="utf-8")) if _FILE.exists() else {}
        except (OSError, ValueError):
            cur = {}
        cur[key] = res
        tmp = _FILE.with_name(_FILE.name + f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(cur, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _FILE)


def results() -> dict:
    with _LOCK:
        try:
            return {"job": dict(_JOB), "results": json.loads(_FILE.read_text(encoding="utf-8")) if _FILE.exists() else {}}
        except (OSError, ValueError):
            return {"job": dict(_JOB), "results": {}}


def run_async(symbols: list[str], tf: str, fetch) -> dict:
    """Evaluate several coins in a background thread; `fetch(symbol, tf)` returns closed candles."""
    with _LOCK:
        if _JOB["running"]:
            return {"status": "busy", **_JOB}
        _JOB.update(running=True, started=time.time(), done=0, total=len(symbols), error=None)

    def work():
        try:
            for s in symbols:
                try:
                    res = evaluate(fetch(s, tf), s, tf)
                except Exception as e:                                   # noqa: BLE001
                    res = {"error": str(e)[:120]}
                _save(f"{s}:{tf}", res)
                with _LOCK:
                    _JOB["done"] += 1
        finally:
            with _LOCK:
                _JOB["running"] = False
    threading.Thread(target=work, daemon=True, name="titan-fceval").start()
    return {"status": "started", "total": len(symbols)}
