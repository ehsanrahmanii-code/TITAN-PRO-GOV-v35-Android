"""Pattern recognition + empirical expectations.

* Candlestick patterns (1-3 candles) are detected vectorised over the WHOLE history, so the same code gives
  (a) markers for recent candles and (b) a pooled sample of every past occurrence on every watched coin.
* Structural patterns (double top/bottom, head & shoulders, triangles, wedges, channels, ranges) come from swing
  pivots and carry drawable trend-lines, breakout levels and a measured-move target.
* "What to expect" = textbook meaning + what actually followed the pattern on these coins (forward returns,
  win-rate, excursion, t-stat, sample size). Samples are de-clustered; small samples are labelled as such.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from app.config import TF_MS

HORIZONS = (3, 8, 16, 32)
BIAS = {"rev_bull": 1, "cont_bull": 1, "breakout_bull": 1, "rev_bear": -1, "cont_bear": -1, "breakout_bear": -1, "indecision": 0, "volatility": 0}

# name: (persian name, kind, meaning, textbook expectation, confirmation / invalidation)
INFO: dict[str, tuple] = {
    "doji": ("دوجی", "indecision", "تعادل خریدار و فروشنده؛ بازار مردد است.", "اهمیت آن به محل ظهورش بستگی دارد: بعد از روند قوی هشدار توقف است.", "کندل بعد جهت را مشخص می‌کند؛ تایید = بسته‌شدن فراتر از سقف/کف دوجی."),
    "dragonfly": ("دوجی سنجاقک", "rev_bull", "فروشندگان قیمت را پایین بردند ولی خریداران کامل برش گرداندند.", "در کف روند نزولی: احتمال بازگشت صعودی.", "تایید = بسته‌شدن کندل بعد بالای سقف الگو؛ شکست کف الگو = ابطال."),
    "gravestone": ("دوجی سنگ‌قبر", "rev_bear", "خریداران قیمت را بالا بردند ولی فروشندگان کامل پس زدند.", "در سقف روند صعودی: احتمال بازگشت نزولی.", "تایید = بسته‌شدن کندل بعد زیر کف الگو؛ شکست سقف الگو = ابطال."),
    "longleg": ("دوجی پا‌بلند", "indecision", "نوسان شدید در هر دو جهت و بسته‌شدن نزدیک باز شدن.", "عدم‌قطعیت بالا؛ معمولاً قبل از حرکت جهت‌دار.", "منتظر شکست یکی از دو سایه بمانید."),
    "hammer": ("چکش", "rev_bull", "بعد از نزول، فروشندگان رد شدند و قیمت از کف بالا آمد.", "احتمال پایان نزول یا یک بازگشت کوتاه‌مدت.", "تایید = کندل صعودی بعدی؛ شکست کف چکش = ابطال."),
    "hanging": ("مرد آویزان", "rev_bear", "شکل چکش اما در سقف روند صعودی؛ نشانه خستگی خریداران.", "هشدار برگشت نزولی؛ بدون تایید ضعیف است.", "تایید = بسته‌شدن زیر بدنه کندل؛ شکست سقف = ابطال."),
    "invhammer": ("چکش وارونه", "rev_bull", "بعد از نزول، خریداران امتحان صعود کردند.", "احتمال بازگشت صعودی در صورت تایید.", "تایید = کندل بعد بالای بدنه بسته شود."),
    "shooting": ("ستاره دنباله‌دار", "rev_bear", "بعد از صعود، فروشندگان از سقف قیمت را پایین کشیدند.", "احتمال برگشت یا اصلاح نزولی.", "تایید = کندل بعد زیر کف بدنه؛ شکست سقف = ابطال."),
    "marubozu_bull": ("ماروبوزو صعودی", "cont_bull", "کندل پرقدرت بدون سایه؛ خریدار کل جلسه مسلط بود.", "ادامه صعود یا شتاب؛ ولی بعد از صعود طولانی ممکن است اوج خریدار باشد.", "اگر کندل بعد بالای نیمه بدنه بماند، قدرت تایید می‌شود."),
    "marubozu_bear": ("ماروبوزو نزولی", "cont_bear", "کندل پرقدرت بدون سایه؛ فروشنده کل جلسه مسلط بود.", "ادامه نزول یا شتاب؛ بعد از نزول طولانی ممکن است اوج فروشنده باشد.", "اگر کندل بعد زیر نیمه بدنه بماند، قدرت تایید می‌شود."),
    "spinning": ("فرفره", "indecision", "بدنه کوچک با سایه‌های بلند؛ تعادل موقت.", "کاهش شتاب روند فعلی.", "جهت شکست سایه‌ها را دنبال کنید."),
    "engulf_bull": ("پوشای صعودی", "rev_bull", "کندل صعودی کل بدنه کندل نزولی قبل را می‌پوشاند.", "تغییر کنترل به خریداران؛ از معتبرترین الگوهای بازگشتی دو‌کندلی.", "ابطال = شکست کف کندل پوشا."),
    "engulf_bear": ("پوشای نزولی", "rev_bear", "کندل نزولی کل بدنه کندل صعودی قبل را می‌پوشاند.", "تغییر کنترل به فروشندگان.", "ابطال = شکست سقف کندل پوشا."),
    "piercing": ("نفوذی (خط شکافنده)", "rev_bull", "بعد از کندل نزولی بزرگ، صعود تا بالای نیمه بدنه قبلی.", "احتمال بازگشت صعودی؛ ضعیف‌تر از پوشا.", "تایید = بسته‌شدن بعدی بالای سقف الگو."),
    "darkcloud": ("ابر تیره", "rev_bear", "بعد از کندل صعودی بزرگ، نزول تا زیر نیمه بدنه قبلی.", "احتمال بازگشت نزولی؛ ضعیف‌تر از پوشا.", "تایید = بسته‌شدن بعدی زیر کف الگو."),
    "harami_bull": ("هارامی صعودی", "rev_bull", "کندل کوچک داخل بدنه کندل نزولی بزرگ؛ شتاب نزول کم شد.", "هشدار توقف نزول، نه سیگنال قطعی.", "تایید = شکست سقف کندل بزرگ."),
    "harami_bear": ("هارامی نزولی", "rev_bear", "کندل کوچک داخل بدنه کندل صعودی بزرگ؛ شتاب صعود کم شد.", "هشدار توقف صعود، نه سیگنال قطعی.", "تایید = شکست کف کندل بزرگ."),
    "tweezer_bottom": ("انبرک کف", "rev_bull", "دو کندل با کف تقریباً برابر؛ حمایت دو بار حفظ شد.", "احتمال برگشت صعودی از همان کف.", "ابطال = شکست کف مشترک."),
    "tweezer_top": ("انبرک سقف", "rev_bear", "دو کندل با سقف تقریباً برابر؛ مقاومت دو بار حفظ شد.", "احتمال برگشت نزولی از همان سقف.", "ابطال = شکست سقف مشترک."),
    "morning_star": ("ستاره صبحگاهی", "rev_bull", "سه‌کندلی: نزول قوی، مکث، صعود قوی.", "از قوی‌ترین الگوهای بازگشت صعودی در کف.", "ابطال = شکست کف کندل وسط."),
    "evening_star": ("ستاره عصرگاهی", "rev_bear", "سه‌کندلی: صعود قوی، مکث، نزول قوی.", "از قوی‌ترین الگوهای بازگشت نزولی در سقف.", "ابطال = شکست سقف کندل وسط."),
    "soldiers": ("سه سرباز سفید", "cont_bull", "سه کندل صعودی پیاپی با بسته‌شدن‌های بالاتر.", "شروع/ادامه روند صعودی؛ بعد از صعود زیاد خطر خستگی.", "ابطال = بسته‌شدن زیر کف کندل اول."),
    "crows": ("سه کلاغ سیاه", "cont_bear", "سه کندل نزولی پیاپی با بسته‌شدن‌های پایین‌تر.", "شروع/ادامه روند نزولی؛ بعد از نزول زیاد خطر خستگی.", "ابطال = بسته‌شدن بالای سقف کندل اول."),
    "three_in_up": ("سه‌داخلی صعودی", "rev_bull", "هارامی صعودی که با کندل سوم تایید شده است.", "بازگشت صعودی تاییدشده.", "ابطال = شکست کف الگو."),
    "three_in_dn": ("سه‌داخلی نزولی", "rev_bear", "هارامی نزولی که با کندل سوم تایید شده است.", "بازگشت نزولی تاییدشده.", "ابطال = شکست سقف الگو."),
    "inside": ("کندل داخلی", "indecision", "دامنه کندل کاملاً داخل کندل قبل؛ فشردگی.", "معمولاً پیش‌درآمد شکست؛ جهت شکست را دنبال کنید.", "ورود در شکست سقف/کف کندل مادر."),
    "outside": ("کندل خارجی", "volatility", "دامنه کندل کل کندل قبل را می‌پوشاند؛ نوسان و رد شدن نقدینگی.", "جهت بسته‌شدن مهم است؛ بسته‌شدن بالا = قدرت، پایین = ضعف.", "تایید با کندل بعدی."),
    "rising3": ("سه‌روش صعودی", "cont_bull", "کندل صعودی بزرگ، سه اصلاح کوچک در محدوده آن، سپس صعود تازه.", "ادامه روند صعودی.", "ابطال = شکست کف کندل اول."),
    "falling3": ("سه‌روش نزولی", "cont_bear", "کندل نزولی بزرگ، سه جهش کوچک در محدوده آن، سپس نزول تازه.", "ادامه روند نزولی.", "ابطال = شکست سقف کندل اول."),
    "absorb_bull": ("جذب خرید با حجم", "rev_bull", "حجم بسیار بالا با سایه پایینی بلند؛ فروش بزرگ جذب شد.", "نشانه ورود نقدینگی خریدار در کف؛ احتمال بازگشت.", "ابطال = شکست کف کندل."),
    "absorb_bear": ("جذب فروش با حجم", "rev_bear", "حجم بسیار بالا با سایه بالایی بلند؛ خرید بزرگ جذب شد.", "نشانه توزیع/فروش در سقف؛ احتمال بازگشت نزولی.", "ابطال = شکست سقف کندل."),
}
STRUCT_INFO = {
    "double_top": ("سقف دوقلو", -1, "دو سقف هم‌سطح؛ مقاومت دو بار رد شد.", "شکست خط گردن (کف میانی) هدف = ارتفاع الگو به سمت پایین."),
    "double_bottom": ("کف دوقلو", 1, "دو کف هم‌سطح؛ حمایت دو بار حفظ شد.", "شکست خط گردن (سقف میانی) هدف = ارتفاع الگو به سمت بالا."),
    "hs": ("سر و شانه", -1, "سه سقف که میانی بلندتر است؛ بازگشت نزولی کلاسیک.", "شکست خط گردن، هدف = فاصله سر تا گردن."),
    "ihs": ("سر و شانه معکوس", 1, "سه کف که میانی عمیق‌تر است؛ بازگشت صعودی کلاسیک.", "شکست خط گردن، هدف = فاصله سر تا گردن."),
    "asc_tri": ("مثلث صعودی", 1, "سقف صاف و کف‌های بالارونده؛ فشار خرید روی مقاومت.", "شکست رو به بالا محتمل‌تر است؛ هدف = ارتفاع مثلث."),
    "desc_tri": ("مثلث نزولی", -1, "کف صاف و سقف‌های پایین‌رونده؛ فشار فروش روی حمایت.", "شکست رو به پایین محتمل‌تر است؛ هدف = ارتفاع مثلث."),
    "sym_tri": ("مثلث متقارن", 0, "سقف‌های پایین‌رونده و کف‌های بالارونده؛ فشردگی.", "جهت شکست نامشخص است؛ بعد از شکست در همان جهت ادامه می‌دهد."),
    "rising_wedge": ("گوه صعودی", -1, "هر دو خط بالا می‌روند ولی همگرا؛ صعود بی‌رمق.", "اغلب با شکست رو به پایین تمام می‌شود."),
    "falling_wedge": ("گوه نزولی", 1, "هر دو خط پایین می‌روند ولی همگرا؛ نزول بی‌رمق.", "اغلب با شکست رو به بالا تمام می‌شود."),
    "asc_channel": ("کانال صعودی", 1, "حرکت بین دو خط موازی رو به بالا.", "خرید در کف کانال، خروج در سقف؛ شکست کف کانال = هشدار."),
    "desc_channel": ("کانال نزولی", -1, "حرکت بین دو خط موازی رو به پایین.", "فروش در سقف کانال؛ شکست سقف کانال = هشدار."),
    "range": ("رنج (محدوده)", 0, "نوسان بین سقف و کف تقریباً افقی.", "خرید نزدیک کف/فروش نزدیک سقف تا زمان شکست؛ شکست با حجم معتبرتر است."),
}


# ───────────────────────── candlestick patterns (vectorised) ─────────────────────────
def _sh(a: np.ndarray, k: int) -> np.ndarray:
    out = np.full_like(a, np.nan, dtype=float)
    if k < len(a):
        out[k:] = a[:-k] if k else a
    return out


def _arrays(df: pd.DataFrame) -> dict:
    o, h, l, c, v = (df[k].values.astype(float) for k in ("open", "high", "low", "close", "volume"))
    pc = _sh(c, 1)
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    tr[0] = h[0] - l[0]
    atr = pd.Series(tr).rolling(14, min_periods=5).mean().values
    rng = np.maximum(h - l, 1e-12)
    body = np.abs(c - o)
    vavg = pd.Series(v).rolling(20, min_periods=5).mean().values
    ctx = (_sh(c, 1) - _sh(c, 6)) / np.where(atr > 0, atr, np.nan)           # trend going INTO the candle (in ATRs)
    return dict(o=o, h=h, l=l, c=c, v=v, atr=atr, rng=rng, body=body, up=h - np.maximum(o, c), lo=np.minimum(o, c) - l, vavg=vavg, ctx=ctx)


def candle_flags(df: pd.DataFrame) -> dict[str, np.ndarray]:
    A = _arrays(df)
    o, h, l, c, v, atr, rng, body, up, lo, ctx = (A[k] for k in ("o", "h", "l", "c", "v", "atr", "rng", "body", "up", "lo", "ctx"))
    bull, bear = c > o, c < o
    big = (body >= 0.6 * rng) & (body >= 0.8 * atr)
    down, upt = ctx < -0.8, ctx > 0.8
    o1, h1, l1, c1, b1 = _sh(o, 1), _sh(h, 1), _sh(l, 1), _sh(c, 1), _sh(body, 1)
    o2, h2, l2, c2, b2 = _sh(o, 2), _sh(h, 2), _sh(l, 2), _sh(c, 2), _sh(body, 2)
    big1, big2 = _sh(big.astype(float), 1) > 0, _sh(big.astype(float), 2) > 0
    bull1, bear1, bull2, bear2 = c1 > o1, c1 < o1, c2 > o2, c2 < o2
    F: dict[str, np.ndarray] = {}
    doji = (body <= 0.1 * rng) & (rng >= 0.5 * atr)
    F["dragonfly"] = doji & (lo >= 0.6 * rng) & (up <= 0.1 * rng)
    F["gravestone"] = doji & (up >= 0.6 * rng) & (lo <= 0.1 * rng)
    F["longleg"] = doji & (up >= 0.3 * rng) & (lo >= 0.3 * rng)
    F["doji"] = doji & ~F["dragonfly"] & ~F["gravestone"] & ~F["longleg"]
    hs = (lo >= 2 * body) & (up <= 0.35 * body + 0.05 * rng) & (body > 0.05 * rng)
    F["hammer"] = hs & down
    F["hanging"] = hs & upt
    ih = (up >= 2 * body) & (lo <= 0.35 * body + 0.05 * rng) & (body > 0.05 * rng)
    F["invhammer"] = ih & down
    F["shooting"] = ih & upt
    mar = (body >= 0.9 * rng) & (rng >= 1.0 * atr)
    F["marubozu_bull"], F["marubozu_bear"] = mar & bull, mar & bear
    F["spinning"] = (body <= 0.3 * rng) & (body > 0.1 * rng) & (up >= 0.25 * rng) & (lo >= 0.25 * rng)
    F["engulf_bull"] = bear1 & bull & (o <= c1) & (c >= o1) & (body > b1) & (ctx < -0.4)
    F["engulf_bear"] = bull1 & bear & (o >= c1) & (c <= o1) & (body > b1) & (ctx > 0.4)
    F["piercing"] = bear1 & big1 & bull & (o < l1 + 0.1 * (h1 - l1)) & (c > (o1 + c1) / 2) & (c < o1) & (ctx < -0.4)
    F["darkcloud"] = bull1 & big1 & bear & (o > h1 - 0.1 * (h1 - l1)) & (c < (o1 + c1) / 2) & (c > o1) & (ctx > 0.4)
    inside_body = (np.maximum(o, c) <= np.maximum(o1, c1)) & (np.minimum(o, c) >= np.minimum(o1, c1))
    F["harami_bull"] = bear1 & big1 & inside_body & (body <= 0.5 * b1) & (c >= o) & (ctx < -0.4)
    F["harami_bear"] = bull1 & big1 & inside_body & (body <= 0.5 * b1) & (c <= o) & (ctx > 0.4)
    tol = 0.12 * atr
    F["tweezer_bottom"] = (np.abs(l - l1) <= tol) & bear1 & bull & (ctx < -0.4)
    F["tweezer_top"] = (np.abs(h - h1) <= tol) & bull1 & bear & (ctx > 0.4)
    small1 = b1 <= 0.35 * b2
    F["morning_star"] = bear2 & big2 & small1 & bull & (c > (o2 + c2) / 2) & (_sh(ctx, 2) < -0.4)
    F["evening_star"] = bull2 & big2 & small1 & bear & (c < (o2 + c2) / 2) & (_sh(ctx, 2) > 0.4)
    F["soldiers"] = bull & bull1 & bull2 & (c > c1) & (c1 > c2) & (o > o1) & (o1 > o2) & (up <= 0.3 * body) & (_sh(up, 1) <= 0.3 * b1) & (body >= 0.5 * atr)
    F["crows"] = bear & bear1 & bear2 & (c < c1) & (c1 < c2) & (o < o1) & (o1 < o2) & (lo <= 0.3 * body) & (_sh(lo, 1) <= 0.3 * b1) & (body >= 0.5 * atr)
    h_up = bear2 & big2 & (np.maximum(o1, c1) <= np.maximum(o2, c2)) & (np.minimum(o1, c1) >= np.minimum(o2, c2)) & bull1
    h_dn = bull2 & big2 & (np.maximum(o1, c1) <= np.maximum(o2, c2)) & (np.minimum(o1, c1) >= np.minimum(o2, c2)) & bear1
    F["three_in_up"] = h_up & bull & (c > o2)
    F["three_in_dn"] = h_dn & bear & (c < o2)
    F["inside"] = (h <= h1) & (l >= l1)
    F["outside"] = (h > h1) & (l < l1) & (rng >= 1.1 * atr)
    o4, c4, h4, l4, b4 = _sh(o, 4), _sh(c, 4), _sh(h, 4), _sh(l, 4), _sh(body, 4)
    mid3 = all_inside = np.ones(len(c), bool)
    for k in (1, 2, 3):
        mid3 = mid3 & (_sh(h, k) <= h4 + 1e-12) & (_sh(l, k) >= l4 - 1e-12)
    big4 = _sh(big.astype(float), 4) > 0
    F["rising3"] = (c4 > o4) & big4 & mid3 & bull & big & (c > c4) & (_sh(c, 1) < c4 + 1e-9)
    F["falling3"] = (c4 < o4) & big4 & mid3 & bear & big & (c < c4) & (_sh(c, 1) > c4 - 1e-9)
    spike = v >= 2.5 * A["vavg"]
    F["absorb_bull"] = spike & (lo >= 0.5 * rng) & (c >= (h + l) / 2) & (ctx < -0.4)
    F["absorb_bear"] = spike & (up >= 0.5 * rng) & (c <= (h + l) / 2) & (ctx > 0.4)
    for k in F:
        F[k] = np.nan_to_num(F[k].astype(float)).astype(bool)
        F[k][:8] = False
    return F


def _decluster(idx: np.ndarray, gap: int = 3) -> np.ndarray:
    out, last = [], -10 ** 9
    for i in idx:
        if i - last > gap:
            out.append(i); last = i
    return np.array(out, dtype=int)


def forward_arrays(df: pd.DataFrame) -> dict:
    c, h, l = (df[k].values.astype(float) for k in ("close", "high", "low"))
    n = len(c); out = {}
    for H in HORIZONS:
        r = np.full(n, np.nan); r[:n - H] = c[H:] / c[:n - H] - 1; out[f"r{H}"] = r
    mfe = np.full(n, np.nan); mae = np.full(n, np.nan)
    for i in range(n - 16):
        mfe[i] = h[i + 1:i + 17].max() / c[i] - 1; mae[i] = l[i + 1:i + 17].min() / c[i] - 1
    out["mfe"], out["mae"] = mfe, mae
    return out


def pooled_stats(frames: list[pd.DataFrame]) -> dict:
    """Forward behaviour after each candlestick pattern, pooled over the supplied frames (one per coin)."""
    acc: dict[str, dict[str, list]] = {}
    base = {f"r{H}": [] for H in HORIZONS}
    for df in frames:
        if df is None or len(df) < 80:
            continue
        F, fw = candle_flags(df), forward_arrays(df)
        for H in HORIZONS:
            base[f"r{H}"].append(fw[f"r{H}"][~np.isnan(fw[f"r{H}"])])
        for name, flag in F.items():
            idx = _decluster(np.where(flag)[0])
            if not len(idx):
                continue
            a = acc.setdefault(name, {k: [] for k in list(fw)})
            for k in fw:
                a[k].append(fw[k][idx])
    bm = {k: (float(np.nanmean(np.concatenate(v))) if v and sum(len(x) for x in v) else 0.0) for k, v in base.items()}
    bu = {k: (float(np.mean(np.concatenate(v) > 0)) if v and sum(len(x) for x in v) else 0.5) for k, v in base.items()}
    out = {"_base": {"mean": bm, "up": bu}}
    for name, a in acc.items():
        bias = BIAS[INFO[name][1]]
        row = {"n": 0, "h": {}}
        for H in HORIZONS:
            x = np.concatenate(a[f"r{H}"]); x = x[~np.isnan(x)]
            if len(x) < 3:
                continue
            m, sd = float(x.mean()), float(x.std(ddof=1)) + 1e-12
            win = float(np.mean(x > 0)) if bias >= 0 else float(np.mean(x < 0))
            if bias == 0:
                win = float(np.mean(np.abs(x) > np.abs(x).mean()))
            row["h"][str(H)] = {"n": int(len(x)), "mean": round(m * 100, 3), "median": round(float(np.median(x)) * 100, 3), "win": round(win * 100, 1),
                                "t": round((m - bm[f"r{H}"]) / (sd / np.sqrt(len(x))), 2), "excess": round((m - bm[f"r{H}"]) * 100, 3)}
            row["n"] = max(row["n"], int(len(x)))
        mf, ma = np.concatenate(a["mfe"]), np.concatenate(a["mae"])
        mf, ma = mf[~np.isnan(mf)], ma[~np.isnan(ma)]
        if len(mf):
            row["mfe16"], row["mae16"] = round(float(mf.mean() * 100), 2), round(float(ma.mean() * 100), 2)
        if row["h"]:
            out[name] = row
    return out


def verdict(stat: dict | None, bias: int) -> dict:
    """Plain-language reading of the empirical sample (bias: +1 bullish, -1 bearish, 0 neutral)."""
    if not stat or not stat.get("h"):
        return {"level": "none", "text": "نمونه تاریخی کافی نیست؛ فقط معنای کلاسیک الگو را ببینید."}
    h = stat["h"].get("8") or next(iter(stat["h"].values()))
    n = h["n"]
    if bias == 0:
        return {"level": "info", "text": f"روی {n} نمونه، بعد از ۸ کندل میانگین حرکت {h['mean']:+.2f}٪ بوده؛ این الگو جهت‌دار نیست و بیشتر خبر از تغییر نوسان می‌دهد."}
    edge = h["excess"] * bias
    good = h["win"] >= 54 and edge > 0
    sig = n >= 30 and abs(h["t"]) >= 1.65
    if sig and good:
        return {"level": "good", "text": f"روی {n} نمونه، بعد از ۸ کندل در {h['win']:.0f}٪ موارد جهت الگو درست بوده و میانگین {h['mean']:+.2f}٪ (برتری {edge:+.2f}٪ نسبت به حالت عادی)."}
    if sig and edge < 0:
        return {"level": "bad", "text": f"روی {n} نمونه، این الگو در عمل خلاف انتظار کلاسیک رفتار کرده (برد {h['win']:.0f}٪، میانگین {h['mean']:+.2f}٪)؛ به آن اعتماد نکنید."}
    return {"level": "weak", "text": f"روی {n} نمونه، برد {h['win']:.0f}٪ و میانگین {h['mean']:+.2f}٪ بعد از ۸ کندل؛ " + ("نمونه کم است." if n < 30 else "برتری از نظر آماری معنادار نیست.")}


def detect_recent(df: pd.DataFrame, look: int = 60, zones: list | None = None) -> list[dict]:
    F = candle_flags(df)
    A = _arrays(df)
    n = len(df)
    t = df["open_time"]
    out = []
    zp = [z["p"] for z in (zones or [])]
    for name, flag in F.items():
        for i in np.where(flag[-look:])[0] + (n - min(look, n)):
            kind = INFO[name][1]
            atr = A["atr"][i] if A["atr"][i] > 0 else A["rng"][i]
            s = 0.35 + min(0.25, A["rng"][i] / (2 * atr) * 0.15) + min(0.2, abs(A["ctx"][i]) / 8)
            if A["vavg"][i] > 0:
                s += min(0.15, max(0.0, A["v"][i] / A["vavg"][i] - 1) * 0.07)
            near = bool(zp and min(abs(A["c"][i] - p) for p in zp) <= 0.6 * atr)
            if near:
                s += 0.1
            out.append({"i": int(i), "ago": int(n - 1 - i), "t": int(t.iloc[i].timestamp() * 1000), "k": name, "fa": INFO[name][0], "kind": kind,
                        "bias": BIAS[kind], "strength": round(float(min(1.0, s)), 2), "at_level": near,
                        "hi": float(A["h"][i]), "lo": float(A["l"][i])})
    out.sort(key=lambda d: (d["ago"], -d["strength"]))
    return out


# ───────────────────────── structural patterns ─────────────────────────
def pivots(df: pd.DataFrame, k: int = 3):
    h, l = df["high"].values.astype(float), df["low"].values.astype(float)
    ph, pl = [], []
    for i in range(k, len(df) - k):
        if h[i] == h[i - k:i + k + 1].max() and h[i] > h[i - 1]:
            ph.append(i)
        if l[i] == l[i - k:i + k + 1].min() and l[i] < l[i - 1]:
            pl.append(i)
    return ph, pl


def _line(xs, ys):
    xs, ys = np.array(xs, float), np.array(ys, float)
    if len(xs) < 2 or np.ptp(xs) == 0:
        return None
    m, b = np.polyfit(xs, ys, 1)
    pred = m * xs + b
    ss = ((ys - ys.mean()) ** 2).sum()
    r2 = 1 - ((ys - pred) ** 2).sum() / ss if ss > 0 else 1.0
    return float(m), float(b), float(r2)


def structures(df: pd.DataFrame, look: int = 110) -> list[dict]:
    d = df.tail(look).reset_index(drop=True)
    n = len(d)
    if n < 50:
        return []
    off = len(df) - n
    c = d["close"].values.astype(float)
    h, l = d["high"].values.astype(float), d["low"].values.astype(float)
    atr = float(np.mean(np.maximum(h - l, 1e-12)[-14:]))
    px = c[-1]
    ph, pl = pivots(d, 3)
    res: list[dict] = []

    def add(k, conf, lines, brk_up=None, brk_dn=None, target=None, note=""):
        fa, bias, meaning, expect = STRUCT_INFO[k]
        lo_i = min(min(a, c_) for a, _b, c_, _e in lines)
        pts = [[int(i + off), float(h[i]), "H"] for i in ph if i >= lo_i] + [[int(i + off), float(l[i]), "L"] for i in pl if i >= lo_i]
        pts.sort()
        res.append({"k": k, "fa": fa, "bias": bias, "conf": round(float(min(1, max(0, conf))), 2), "meaning": meaning, "expect": expect, "points": pts,
                    "lines": [[int(a + off), float(b), int(c_ + off), float(e)] for a, b, c_, e in lines], "break_up": brk_up, "break_dn": brk_dn, "target": target, "note": note})
    if len(ph) >= 2:
        a, b = ph[-2], ph[-1]
        if b - a >= 6 and abs(h[a] - h[b]) <= max(0.5 * atr, 0.004 * px) and (n - 1 - b) <= 25:
            neck = float(l[a:b + 1].min())
            if h[a:b + 1].max() <= max(h[a], h[b]) + 1e-9 and (max(h[a], h[b]) - neck) >= 1.2 * atr:
                add("double_top", 0.55 + 0.15 * (px < neck + 0.5 * atr), [(a, h[a], b, h[b]), (a, neck, n - 1, neck)], None, neck, neck - (max(h[a], h[b]) - neck), f"خط گردن {neck:.6g}")
    if len(pl) >= 2:
        a, b = pl[-2], pl[-1]
        if b - a >= 6 and abs(l[a] - l[b]) <= max(0.5 * atr, 0.004 * px) and (n - 1 - b) <= 25:
            neck = float(h[a:b + 1].max())
            if (neck - min(l[a], l[b])) >= 1.2 * atr:
                add("double_bottom", 0.55 + 0.15 * (px > neck - 0.5 * atr), [(a, l[a], b, l[b]), (a, neck, n - 1, neck)], neck, None, neck + (neck - min(l[a], l[b])), f"خط گردن {neck:.6g}")
    if len(ph) >= 3:
        a, b, c3 = ph[-3:]
        if h[b] > h[a] + 0.5 * atr and h[b] > h[c3] + 0.5 * atr and abs(h[a] - h[c3]) <= 1.2 * atr and (n - 1 - c3) <= 25:
            t1, t2 = float(l[a:b + 1].min()), float(l[b:c3 + 1].min()); neck = (t1 + t2) / 2
            add("hs", 0.6, [(a, h[a], b, h[b]), (b, h[b], c3, h[c3]), (a, t1, c3, t2)], None, neck, neck - (h[b] - neck), "سر در میانه")
    if len(pl) >= 3:
        a, b, c3 = pl[-3:]
        if l[b] < l[a] - 0.5 * atr and l[b] < l[c3] - 0.5 * atr and abs(l[a] - l[c3]) <= 1.2 * atr and (n - 1 - c3) <= 25:
            t1, t2 = float(h[a:b + 1].max()), float(h[b:c3 + 1].max()); neck = (t1 + t2) / 2
            add("ihs", 0.6, [(a, l[a], b, l[b]), (b, l[b], c3, l[c3]), (a, t1, c3, t2)], neck, None, neck + (neck - l[b]), "سر در میانه")
    hp, lp = [i for i in ph if i >= n - 85][-5:], [i for i in pl if i >= n - 85][-5:]
    if len(hp) >= 3 and len(lp) >= 3:
        U, Lw = _line(hp, h[hp]), _line(lp, l[lp])
        if U and Lw and U[2] >= 0.55 and Lw[2] >= 0.55:
            su, sl = U[0] / px * 100, Lw[0] / px * 100                       # %/bar
            x0, x1 = min(hp[0], lp[0]), n - 1
            up0, up1, lo0, lo1 = U[0] * x0 + U[1], U[0] * x1 + U[1], Lw[0] * x0 + Lw[1], Lw[0] * x1 + Lw[1]
            w0, w1 = up0 - lo0, up1 - lo1
            if w1 > 0 and w0 > 0 and lo1 < px < up1 * 1.01 and px > lo1 * 0.99:
                flat = 0.03
                lines = [(x0, up0, x1, up1), (x0, lo0, x1, lo1)]
                q = min(U[2], Lw[2])
                converge = w1 < 0.8 * w0
                if abs(su) < flat and abs(sl) < flat: k = "range"
                elif abs(su) < flat and sl > flat and converge: k = "asc_tri"
                elif abs(sl) < flat and su < -flat and converge: k = "desc_tri"
                elif su < -flat and sl > flat and converge: k = "sym_tri"
                elif su > flat and sl > flat and converge: k = "rising_wedge"
                elif su < -flat and sl < -flat and converge: k = "falling_wedge"
                elif su > flat and sl > flat and abs(su - sl) < 0.5 * max(su, sl): k = "asc_channel"
                elif su < -flat and sl < -flat and abs(su - sl) < 0.5 * abs(min(su, sl)): k = "desc_channel"
                else: k = None
                if k:
                    add(k, 0.35 + 0.4 * q, lines, up1, lo1, (up1 + w0) if STRUCT_INFO[k][1] > 0 else (lo1 - w0) if STRUCT_INFO[k][1] < 0 else None,
                        f"سقف {up1:.6g} · کف {lo1:.6g}")
    res.sort(key=lambda r: -r["conf"])
    return res[:4]


def summarize(recent: list[dict], structs: list[dict], pooled: dict, ptf: str = "") -> dict:
    """Net bias from the last 3 candles' patterns, weighted by strength and (if known) the empirical edge."""
    score, items = 0.0, []
    for r in recent:
        if r["ago"] > 2 or r["bias"] == 0:
            continue
        st = (pooled or {}).get(r["k"])
        v = verdict(st, r["bias"])
        wgt = r["strength"] * (1.0 if v["level"] in ("good", "weak", "none") else 0.3 if v["level"] == "bad" else 1.0) * (0.5 ** r["ago"])
        if v["level"] == "bad":
            wgt *= -1
        score += r["bias"] * wgt
        items.append(r["fa"])
    for s in structs:
        score += s["bias"] * s["conf"] * 0.6
    return {"score": round(float(np.clip(score, -2, 2)) / 2 * 100, 1), "items": items[:4]}


# ───────────────────────── time, validity and state of every pattern ─────────────────────────
# how many candles a pattern is built from
N_CANDLES = {"morning_star": 3, "evening_star": 3, "soldiers": 3, "crows": 3, "three_in_up": 3, "three_in_dn": 3, "rising3": 5, "falling3": 5,
             "engulf_bull": 2, "engulf_bear": 2, "piercing": 2, "darkcloud": 2, "harami_bull": 2, "harami_bear": 2,
             "tweezer_bottom": 2, "tweezer_top": 2, "inside": 2, "outside": 2}
# how many candles AFTER the pattern closes it stays actionable (by kind)
VALID_BARS = {"rev_bull": 5, "rev_bear": 5, "cont_bull": 7, "cont_bear": 7, "breakout_bull": 6, "breakout_bear": 6, "indecision": 3, "volatility": 3}
STATE_FA = {"active": "فعال", "confirmed": "تایید‌شده", "invalidated": "باطل‌شده", "expired": "منقضی", "triggered": "شکست خورده (فعال)", "forming": "در حال شکل‌گیری"}


def _t_at(df: pd.DataFrame, i: int, ms: int) -> int:
    """Open time (ms) of bar index i, extrapolated beyond the last bar."""
    n = len(df)
    last = int(df["open_time"].iloc[-1].timestamp() * 1000)
    if 0 <= i < n:
        return int(df["open_time"].iloc[i].timestamp() * 1000)
    return last + (i - (n - 1)) * ms


def enrich_recent(df: pd.DataFrame, recent: list[dict], tf: str = "1h") -> list[dict]:
    """Add the full time story to every candlestick pattern: start, end, how long it stays valid, the level that
    cancels it, the level that confirms it, and what has actually happened since (state)."""
    ms = TF_MS.get(tf, 3_600_000)
    n = len(df)
    now_close = int(df["open_time"].iloc[-1].timestamp() * 1000) + ms          # close of the newest closed candle
    h, l, c = df["high"].values.astype(float), df["low"].values.astype(float), df["close"].values.astype(float)
    out = []
    for r in recent:
        i, k = r["i"], r["k"]
        nc = N_CANDLES.get(k, 1)
        a = max(0, i - nc + 1)
        bias = r["bias"]
        kind = r["kind"]
        vb = VALID_BARS.get(kind, 4)
        t_start = _t_at(df, a, ms)
        t_end = _t_at(df, i, ms) + ms
        valid_until = t_end + vb * ms
        hi, lo = float(h[a:i + 1].max()), float(l[a:i + 1].min())
        inval = lo if bias > 0 else hi if bias < 0 else None
        conf = hi if bias > 0 else lo if bias < 0 else None
        state, t_event = "active", None
        for j in range(i + 1, n):
            if inval is not None and ((bias > 0 and c[j] < inval) or (bias < 0 and c[j] > inval)):
                state, t_event = "invalidated", _t_at(df, j, ms) + ms
                break
            if conf is not None and state == "active" and ((bias > 0 and c[j] > conf) or (bias < 0 and c[j] < conf)):
                state, t_event = "confirmed", _t_at(df, j, ms) + ms
        alive = state in ("active", "confirmed") and now_close < valid_until
        if state in ("active", "confirmed") and not alive:
            state = "expired" if state == "active" else "confirmed"
        left = max(0.0, (valid_until - now_close) / ms)
        q = dict(r)
        q.update(t_start=t_start, t_end=t_end, n_candles=nc, valid_from=t_end, valid_until=valid_until, valid_bars=vb, bars_left=round(left, 1),
                 alive=bool(alive), state=state, state_fa=STATE_FA.get(state, state), t_event=t_event, invalid_level=inval, confirm_level=conf,
                 pat_hi=hi, pat_lo=lo, tf=tf)
        out.append(q)
    return out


def enrich_structs(df: pd.DataFrame, structs: list[dict], tf: str = "1h") -> list[dict]:
    """Add time axes to structural patterns: first/last touch, projected apex or expiry, state and ETA of the measured move."""
    ms = TF_MS.get(tf, 3_600_000)
    n = len(df)
    c = df["close"].values.astype(float)
    px = float(c[-1])
    now_close = int(df["open_time"].iloc[-1].timestamp() * 1000) + ms
    tr = np.maximum(df["high"].values - df["low"].values, 1e-12)
    atr = float(np.mean(tr[-14:]))
    out = []
    for s_ in structs:
        q = dict(s_)
        lines = s_.get("lines") or []
        idx = [x for ln in lines for x in (ln[0], ln[2])]
        a_i, b_i = (min(idx), max(idx)) if idx else (n - 30, n - 1)
        dur = max(1, b_i - a_i)
        q["t_start"] = _t_at(df, a_i, ms)
        q["t_end"] = now_close
        q["duration_bars"] = dur
        q["lines_t"] = [[_t_at(df, ln[0], ms), ln[1], _t_at(df, ln[2], ms), ln[3]] for ln in lines]
        q["points_t"] = [[_t_at(df, p_[0], ms), p_[1], p_[2]] for p_ in (s_.get("points") or [])]
        # converging patterns: the apex is where the two trend-lines meet, the pattern must resolve before it
        apex_i = None
        if s_["k"] in ("asc_tri", "desc_tri", "sym_tri", "rising_wedge", "falling_wedge") and len(lines) >= 2:
            (x0, y0, x1, y1), (u0, v0, u1, v1) = lines[0], lines[1]
            m1 = (y1 - y0) / (x1 - x0) if x1 != x0 else 0.0
            m2 = (v1 - v0) / (u1 - u0) if u1 != u0 else 0.0
            if abs(m1 - m2) > 1e-12:
                xa = (v0 - y0 + m1 * x0 - m2 * u0) / (m1 - m2)
                if n - 1 <= xa <= n - 1 + 60:
                    apex_i = int(round(xa))
        if apex_i is not None:
            q["valid_until"] = _t_at(df, apex_i, ms) + ms
            q["valid_basis"] = "تا رأس مثلث/گوه (نقطهٔ برخورد دو خط)؛ بعد از آن الگو معنا ندارد"
            q["apex_t"] = _t_at(df, apex_i, ms)
        else:
            vb = int(min(40, max(8, dur * 0.6)))
            q["valid_until"] = now_close + vb * ms
            q["valid_basis"] = f"حدود {vb} کندل بعد از آخرین لمس (۶۰٪ طول الگو)"
        q["valid_bars"] = int(round((q["valid_until"] - now_close) / ms))
        # state
        bu, bd = s_.get("break_up"), s_.get("break_dn")
        state = "forming"
        if s_["k"] in ("double_bottom", "ihs", "double_top", "hs"):
            state = "forming"
        if bu is not None and px > bu:
            state = "triggered"
        if bd is not None and px < bd:
            state = "triggered"
        if now_close >= q["valid_until"]:
            state = "expired"
        q["state"], q["state_fa"] = state, STATE_FA.get(state, state)
        q["alive"] = state in ("forming", "triggered")
        tg = s_.get("target")
        if tg is not None and atr > 0:
            bars = int(min(60, max(4, round(abs(tg - px) / atr * 1.6))))
            q["target_eta_t"] = now_close + bars * ms
            q["target_bars"] = bars
        q["tf"] = tf
        out.append(q)
    return out


def auto_lines(df: pd.DataFrame, tf: str = "1h") -> dict:
    """Automatic trend-lines (through the last swing lows / highs, extended forward) and Fibonacci levels of the last major swing,
    every point carrying its candle time. These are the lines a trader would draw by hand."""
    ms = TF_MS.get(tf, 3_600_000)
    d = df.tail(160).reset_index(drop=True)
    n = len(d)
    if n < 40:
        return {"lines": [], "fib": None}
    off = len(df) - n
    h, l, c = d["high"].values.astype(float), d["low"].values.astype(float), d["close"].values.astype(float)
    ph, pl = pivots(d, 4)
    out = []

    def mk(kind, idx, arr, bias):
        if len(idx) < 2:
            return
        for a_, b_ in [(idx[-2], idx[-1])] + ([(idx[-3], idx[-1])] if len(idx) >= 3 else []):
            if b_ - a_ < 5:
                continue
            m = (arr[b_] - arr[a_]) / (b_ - a_)
            touches = sum(1 for i in idx if i >= a_ and abs(arr[a_] + m * (i - a_) - arr[i]) <= 0.35 * float(np.mean(h[-20:] - l[-20:])))
            # a line is only worth drawing when price has not already sliced through it
            seg = np.arange(a_, n)
            line = arr[a_] + m * (seg - a_)
            broken = (kind == "res" and np.any(c[seg][-6:] > line[-6:] * 1.002)) or (kind == "sup" and np.any(c[seg][-6:] < line[-6:] * 0.998))
            out.append({"kind": kind, "bias": bias, "t0": _t_at(df, a_ + off, ms), "p0": float(arr[a_]), "t1": _t_at(df, b_ + off, ms), "p1": float(arr[b_]),
                        "slope_pct_bar": round(m / c[-1] * 100, 4), "touches": int(touches), "broken": bool(broken), "bars": int(b_ - a_),
                        "now_price": float(arr[a_] + m * (n - 1 - a_)), "t_now": _t_at(df, n - 1 + off, ms) + ms})
    mk("sup", pl, l, 1)
    mk("res", ph, h, -1)
    out = [o for o in out if not o["broken"]][:4]
    fib = None
    if ph and pl:
        i_h, i_l = ph[-1], pl[-1]
        hi_p, lo_p = float(h[i_h]), float(l[i_l])
        if abs(hi_p - lo_p) > 0:
            up_leg = i_l < i_h
            lv = {r: (hi_p - (hi_p - lo_p) * r) if up_leg else (lo_p + (hi_p - lo_p) * r) for r in (0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)}
            fib = {"up": bool(up_leg), "t0": _t_at(df, min(i_h, i_l) + off, ms), "t1": _t_at(df, max(i_h, i_l) + off, ms), "hi": hi_p, "lo": lo_p,
                   "levels": [{"r": r, "p": float(v)} for r, v in lv.items()]}
    return {"lines": out, "fib": fib}


def clock(df: pd.DataFrame, tf: str = "1h", look: int = 80, zones: list | None = None) -> dict:
    """Everything the UI needs for the pattern timeline of one (coin, timeframe)."""
    recent = enrich_recent(df, detect_recent(df, look, zones), tf)
    structs = enrich_structs(df, structures(df), tf)
    return {"recent": recent, "structs": structs, "tf": tf, "bar_ms": TF_MS.get(tf, 3_600_000), "auto": auto_lines(df, tf),
            "now": int(df["open_time"].iloc[-1].timestamp() * 1000) + TF_MS.get(tf, 3_600_000)}
